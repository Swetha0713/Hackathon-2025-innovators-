def stable_matching(applicants, jobs, preferences):
  unmatched_applicants = list(applicants)
  proposals = {applicant: [] for applicant in applicants}
  job_matches = {job: None for job in jobs}

  while unmatched_applicants:
      applicant = unmatched_applicants.pop(0)
      applicant_prefs = preferences[applicant]

      for job in applicant_prefs:
          if job not in proposals[applicant]:
              proposals[applicant].append(job)

              if job_matches[job] is None:
                  job_matches[job] = applicant
                  break
              else:
                  current = job_matches[job]
                  job_prefs = preferences[job]

                  if job_prefs.index(applicant) < job_prefs.index(current):
                      job_matches[job] = applicant
                      unmatched_applicants.append(current)
                      break
                  else:
                      continue

  return job_matches


if __name__ == "__main__":
  applicants = ["Alice", "Bob", "Charlie"]
  jobs = ["Backend", "Frontend", "Data"]

  preferences = {
      "Alice": ["Data", "Frontend", "Backend"],
      "Bob": ["Backend", "Data", "Frontend"],
      "Charlie": ["Frontend", "Backend", "Data"],
      "Backend": ["Alice", "Bob", "Charlie"],
      "Frontend": ["Charlie", "Alice", "Bob"],
      "Data": ["Bob", "Charlie", "Alice"]
  }

  matches = stable_matching(applicants, jobs, preferences)
  print("Final Matches:", matches)
