import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface PersonalizedJobDescriptionProps {
  jobId: number;
}

interface PersonalizedDescriptionResponse {
  description: string;
}

export default function PersonalizedJobDescription({ jobId }: PersonalizedJobDescriptionProps) {
  const { 
    data: personalizedData,
    isLoading,
    error
  } = useQuery<PersonalizedDescriptionResponse>({
    queryKey: ["/api/jobs", jobId, "personalized"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-5 w-full" />
        <Skeleton className="h-5 w-full" />
        <Skeleton className="h-5 w-3/4" />
        <Skeleton className="h-5 w-5/6" />
        <Skeleton className="h-5 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4 mr-2" />
        <AlertDescription>
          We couldn't personalize this job description. You may need to complete your profile with more information.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div 
      className="prose prose-sm max-w-none"
      dangerouslySetInnerHTML={{ __html: personalizedData?.description || "" }}
    />
  );
}