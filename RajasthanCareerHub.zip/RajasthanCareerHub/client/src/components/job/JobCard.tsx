import { useState } from "react";
import { Link } from "wouter";
import { MapPin, GraduationCap, Briefcase } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Job } from "@shared/schema";

interface JobCardProps {
  job: Job;
}

const formatSalary = (min?: number, max?: number) => {
  if (!min && !max) return 'Not specified';
  if (!max) return `₹${min} LPA`;
  if (!min) return `Up to ₹${max} LPA`;
  return `₹${min}-${max} LPA`;
};

const JobCard = ({ job }: JobCardProps) => {
  const formatJobType = (type: string) => {
    return type.replace('_', ' ').toLowerCase()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const formatExperience = (level: string) => {
    switch(level) {
      case 'ENTRY_LEVEL': return 'Entry Level';
      case 'JUNIOR': return '1-3 years';
      case 'MID_LEVEL': return '3-5 years';
      case 'SENIOR': return '5+ years';
      default: return level;
    }
  };

  const getJobTypeColor = (type: string) => {
    switch(type) {
      case 'PERMANENT': return 'blue';
      case 'CONTRACT': return 'indigo';
      case 'INTERNSHIP': return 'rose';
      case 'PART_TIME': return 'amber';
      default: return 'slate';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 mb-4 hover:shadow-lg transition-shadow">
      <div className="p-6">
        <div className="flex flex-col md:flex-row justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold text-gray-800 mb-1">{job.title}</h3>
            <p className="text-gray-600 mb-2">{job.departmentName}, {job.location}</p>
            <div className="flex flex-wrap gap-2 mb-2">
              <Badge variant="outline" className={`bg-${getJobTypeColor(job.jobType)}-100 text-${getJobTypeColor(job.jobType)}-800 border-${getJobTypeColor(job.jobType)}-200`}>
                {formatJobType(job.jobType)}
              </Badge>
              {job.isRemote && (
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                  Remote
                </Badge>
              )}
            </div>
          </div>
          <div className="mt-3 md:mt-0 text-right">
            <p className="text-green-600 font-semibold">{formatSalary(job.salaryMin, job.salaryMax)}</p>
            <p className="text-sm text-gray-500">
              Posted: {formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })}
            </p>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between pt-4 border-t border-gray-200">
          <div className="flex flex-wrap gap-4 mb-4 md:mb-0">
            <div className="flex items-center">
              <MapPin className="text-gray-400 mr-2 h-4 w-4" />
              <span className="text-sm text-gray-600">{job.location}</span>
            </div>
            <div className="flex items-center">
              <GraduationCap className="text-gray-400 mr-2 h-4 w-4" />
              <span className="text-sm text-gray-600">{job.qualifications.split(',')[0]}</span>
            </div>
            <div className="flex items-center">
              <Briefcase className="text-gray-400 mr-2 h-4 w-4" />
              <span className="text-sm text-gray-600">{formatExperience(job.experience)}</span>
            </div>
          </div>
          <Link href={`/jobs/${job.id}`}>
            <Button className="bg-primary hover:bg-primary-dark text-white">View & Apply</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
