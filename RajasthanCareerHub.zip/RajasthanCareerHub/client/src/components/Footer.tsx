import { Link } from "wouter";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Facebook,
  Twitter,
  Linkedin,
  Instagram 
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <img 
                src="https://cdn-icons-png.flaticon.com/512/4406/4406172.png" 
                alt="Rajasthan Govt Logo" 
                className="h-12 mr-3" 
              />
              <div>
                <h3 className="font-heading font-bold text-lg">Rajasthan Government</h3>
                <p className="text-gray-400 text-sm">Job & Internship Portal</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Official portal for government jobs and internships in technical and educational departments of Rajasthan.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-amber-500 transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-amber-500 transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-amber-500 transition">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-amber-500 transition">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-gray-300 hover:text-white transition">Home</a>
                </Link>
              </li>
              <li>
                <Link href="/jobs">
                  <a className="text-gray-300 hover:text-white transition">Browse Jobs</a>
                </Link>
              </li>
              <li>
                <Link href="/internships">
                  <a className="text-gray-300 hover:text-white transition">Internships</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Departments</a>
                </Link>
              </li>
              <li>
                <Link href="/applications">
                  <a className="text-gray-300 hover:text-white transition">Application Status</a>
                </Link>
              </li>
              <li>
                <Link href="/profile">
                  <a className="text-gray-300 hover:text-white transition">Profile</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Departments</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Information Technology</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Higher Education</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">School Education</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Technical Education</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Public Works</a>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <a className="text-gray-300 hover:text-white transition">Science & Technology</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mt-1 mr-3 text-gray-400" />
                <span className="text-gray-300">Secretariat, Jaipur, Rajasthan 302005</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-3 text-gray-400" />
                <span className="text-gray-300">+91-141-2227000</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-3 text-gray-400" />
                <span className="text-gray-300">careers@rajasthan.gov.in</span>
              </li>
              <li className="flex items-center">
                <Clock className="h-5 w-5 mr-3 text-gray-400" />
                <span className="text-gray-300">Mon - Fri: 9:30 AM - 6:00 PM</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-6 border-t border-gray-700 mt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Government of Rajasthan. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition">
                Terms & Conditions
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition">
                Accessibility
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
