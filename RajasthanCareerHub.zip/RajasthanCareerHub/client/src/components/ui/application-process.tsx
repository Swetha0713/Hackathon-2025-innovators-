import { Code, FileText, CalendarCheck, LandPlot } from "lucide-react";

const ApplicationProcess = () => {
  return (
    <div className="bg-white rounded-lg p-5 shadow-md">
      <h3 className="text-xl font-bold text-primary mb-4">Application Process</h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="text-center">
          <div className="bg-primary/10 p-3 rounded-full inline-block mb-3 relative">
            <Code className="h-6 w-6 text-primary" />
            <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center font-bold">1</span>
          </div>
          <h4 className="text-base font-semibold text-gray-800 mb-2">Find Opportunities</h4>
          <p className="text-gray-600 text-sm">
            Search and filter jobs that match your skills and preferences.
          </p>
        </div>
        
        <div className="text-center">
          <div className="bg-primary/10 p-3 rounded-full inline-block mb-3 relative">
            <FileText className="h-6 w-6 text-primary" />
            <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center font-bold">2</span>
          </div>
          <h4 className="text-base font-semibold text-gray-800 mb-2">Submit Application</h4>
          <p className="text-gray-600 text-sm">
            Fill application form and upload required documents.
          </p>
        </div>
        
        <div className="text-center">
          <div className="bg-primary/10 p-3 rounded-full inline-block mb-3 relative">
            <CalendarCheck className="h-6 w-6 text-primary" />
            <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center font-bold">3</span>
          </div>
          <h4 className="text-base font-semibold text-gray-800 mb-2">Selection Process</h4>
          <p className="text-gray-600 text-sm">
            Shortlisting, interviews, and verification of documents.
          </p>
        </div>
        
        <div className="text-center">
          <div className="bg-primary/10 p-3 rounded-full inline-block mb-3 relative">
            <LandPlot className="h-6 w-6 text-primary" />
            <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center font-bold">4</span>
          </div>
          <h4 className="text-base font-semibold text-gray-800 mb-2">Join Government Service</h4>
          <p className="text-gray-600 text-sm">
            Receive offer letter and onboarding instructions.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ApplicationProcess;
