import { Link } from "wouter";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Column 1: About */}
          <div>
            <h3 className="text-lg font-semibold mb-4">About Us</h3>
            <p className="text-gray-400 text-sm">
              The Technical & Education Department of the Government of Rajasthan
              is committed to providing quality education and technical training
              opportunities across the state.
            </p>
          </div>
          
          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/">
                  <span className="hover:text-white transition cursor-pointer">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/jobs">
                  <span className="hover:text-white transition cursor-pointer">Jobs</span>
                </Link>
              </li>
              <li>
                <Link href="/internships">
                  <span className="hover:text-white transition cursor-pointer">Internships</span>
                </Link>
              </li>
              <li>
                <Link href="/departments">
                  <span className="hover:text-white transition cursor-pointer">Departments</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Column 3: Resources */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <a href="https://rajasthan.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-white transition">
                  Government of Rajasthan
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Education Department
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Technical Board
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Training Programs
                </a>
              </li>
            </ul>
          </div>
          
          {/* Column 4: Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <address className="text-sm text-gray-400 not-italic">
              <p>Technical & Education Department</p>
              <p>Government of Rajasthan</p>
              <p>Civil Secretariat, Jaipur</p>
              <p>Rajasthan, India - 302005</p>
              <p className="mt-2">Email: info@techedu-raj.gov.in</p>
              <p>Phone: +91-1412227654</p>
            </address>
          </div>
        </div>
        
        {/* Bottom Section */}
        <div className="mt-8 pt-6 border-t border-gray-800 text-center text-sm text-gray-500">
          <p>
            © {currentYear} Technical & Education Department, Government of Rajasthan. All rights reserved.
          </p>
          <div className="mt-2 space-x-4">
            <Link href="/privacy-policy">
              <span className="hover:text-white transition cursor-pointer">Privacy Policy</span>
            </Link>
            <Link href="/terms-of-service">
              <span className="hover:text-white transition cursor-pointer">Terms of Service</span>
            </Link>
            <Link href="/accessibility">
              <span className="hover:text-white transition cursor-pointer">Accessibility</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;