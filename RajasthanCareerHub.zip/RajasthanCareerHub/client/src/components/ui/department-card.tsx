import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Code, Building, GraduationCap, LandPlot } from "lucide-react";

interface DepartmentCardProps {
  department: {
    id: number;
    name: string;
    description: string;
    icon: string;
  };
  jobCount: number;
}

const DepartmentCard = ({ department, jobCount }: DepartmentCardProps) => {
  const getIcon = () => {
    switch (department.icon) {
      case "ri-code-s-slash-line":
        return <Code className="h-8 w-8 text-primary" />;
      case "ri-building-line":
        return <Building className="h-8 w-8 text-primary" />;
      case "ri-graduation-cap-line":
        return <GraduationCap className="h-8 w-8 text-primary" />;
      default:
        return <LandPlot className="h-8 w-8 text-primary" />;
    }
  };

  return (
    <Link href={`/jobs?departmentId=${department.id}`}>
      <div className="border border-gray-200 rounded-lg p-4 text-center hover:shadow-md transition duration-300 cursor-pointer h-full flex flex-col">
        <div className="bg-primary/10 p-3 rounded-full inline-block mb-3 mx-auto">
          {getIcon()}
        </div>
        <h4 className="text-lg font-semibold text-gray-800 mb-2">{department.name}</h4>
        <p className="text-gray-600 text-sm mb-3 flex-grow">
          {department.description}
        </p>
        <Badge variant="outline" className="text-primary mx-auto mt-auto">
          {jobCount} open position{jobCount !== 1 ? 's' : ''}
        </Badge>
      </div>
    </Link>
  );
};

export default DepartmentCard;
