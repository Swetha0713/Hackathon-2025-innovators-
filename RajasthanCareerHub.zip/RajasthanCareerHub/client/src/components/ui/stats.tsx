import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

const Stats = () => {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch stats");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <section className="bg-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-center py-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-white py-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4">
            <h3 className="text-3xl font-bold text-primary">
              {stats?.openPositions || 0}
            </h3>
            <p className="text-gray-600">Open Positions</p>
          </div>
          <div className="text-center p-4">
            <h3 className="text-3xl font-bold text-primary">
              {stats?.departments || 0}
            </h3>
            <p className="text-gray-600">Departments</p>
          </div>
          <div className="text-center p-4">
            <h3 className="text-3xl font-bold text-primary">
              {stats?.applicantsHired || 0}
            </h3>
            <p className="text-gray-600">Applicants Hired</p>
          </div>
          <div className="text-center p-4">
            <h3 className="text-3xl font-bold text-primary">
              {stats?.internships || 0}
            </h3>
            <p className="text-gray-600">Internship Programs</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Stats;
