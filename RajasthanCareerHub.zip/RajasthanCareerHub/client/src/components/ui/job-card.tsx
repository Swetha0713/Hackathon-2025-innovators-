import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Briefcase, 
  MapPin, 
  Calendar,
  IndianRupee,
  Clock,
  Bookmark 
} from "lucide-react";
import { formatSalaryRange, getDeadlineStatus, getFormattedJobType } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

interface JobCardProps {
  job: {
    id: number;
    title: string;
    departmentId: number;
    departmentName?: string;
    location: string;
    type: string;
    salaryMin?: number;
    salaryMax?: number;
    description: string;
    skills: string;
    postedAt: Date | string;
    deadline: Date | string;
  };
  departmentName: string;
}

const JobCard = ({ job, departmentName }: JobCardProps) => {
  const deadlineStatus = getDeadlineStatus(job.deadline);
  const postedTime = formatDistanceToNow(new Date(job.postedAt), { addSuffix: true });
  
  // Split skills by comma and trim
  const skillsList = job.skills.split(",").map(skill => skill.trim());
  
  return (
    <div className="border border-gray-200 rounded-lg p-4 mb-4 hover:shadow-md transition duration-300">
      <div className="flex flex-col md:flex-row md:items-center">
        <div className="md:w-3/4">
          <div className="flex items-start">
            <div className="bg-primary/10 p-2 rounded mr-4 hidden md:flex items-center justify-center">
              <Briefcase className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{job.title}</h3>
              <p className="text-gray-600 mb-2">
                {departmentName} | {job.location}
              </p>
              
              <div className="flex flex-wrap items-center gap-3 mb-3 text-sm">
                <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full flex items-center">
                  <Briefcase className="h-3 w-3 mr-1" />
                  {getFormattedJobType(job.type)}
                </span>
                <span className="bg-primary/10 text-primary px-2 py-1 rounded-full">
                  {departmentName}
                </span>
                <span className="flex items-center text-gray-700">
                  <IndianRupee className="h-3 w-3 mr-1" />
                  {formatSalaryRange(job.salaryMin, job.salaryMax)}
                </span>
              </div>
              
              <p className="text-gray-600 text-sm mb-3">
                {job.description.length > 150 
                  ? `${job.description.substring(0, 150)}...` 
                  : job.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-3">
                {skillsList.slice(0, 4).map((skill, index) => (
                  <span key={index} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                    {skill}
                  </span>
                ))}
                {skillsList.length > 4 && (
                  <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                    +{skillsList.length - 4} more
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:w-1/4 flex flex-col items-start md:items-end mt-4 md:mt-0">
          <span className={`${deadlineStatus.className} px-2 py-1 rounded text-sm mb-2 flex items-center`}>
            <Clock className="h-3 w-3 mr-1" />
            {deadlineStatus.text}
          </span>
          
          <div className="flex gap-2 w-full md:justify-end">
            <Button asChild>
              <Link href={`/jobs/${job.id}`}>View Details</Link>
            </Button>
            <Button variant="outline" size="icon">
              <Bookmark className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex items-center mt-2 text-xs text-gray-500">
            <Calendar className="h-3 w-3 mr-1" />
            <span>Posted {postedTime}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
