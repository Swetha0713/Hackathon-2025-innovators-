import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { PhoneCall, Mail, HelpCircle } from "lucide-react";

interface JobFiltersProps {
  onFilterChange: (filters: any) => void;
  initialFilters?: any;
}

const JobFilters = ({ onFilterChange, initialFilters = {} }: JobFiltersProps) => {
  const [filters, setFilters] = useState({
    jobTypes: initialFilters.jobTypes || [],
    departments: initialFilters.departments || [],
    experienceLevels: initialFilters.experienceLevels || [],
    locations: initialFilters.locations || [],
    salaryRange: initialFilters.salaryRange || [10000, 100000],
  });

  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
  });

  const { data: jobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
  });

  // Extract unique locations from jobs
  const locations = jobs 
    ? [...new Set(jobs.map((job: any) => job.location.split(", ")).flat())]
    : [];

  const jobTypes = [
    { id: "FULL_TIME", label: "Full Time" },
    { id: "PART_TIME", label: "Part Time" },
    { id: "CONTRACT", label: "Contract" },
    { id: "INTERNSHIP", label: "Internship" },
  ];

  const experienceLevels = [
    { id: "entry", label: "Entry Level" },
    { id: "mid", label: "Mid Level" },
    { id: "senior", label: "Senior Level" },
  ];

  const handleCheckboxChange = (category: string, value: string) => {
    setFilters((prev) => {
      const updatedCategory = prev[category].includes(value)
        ? prev[category].filter((item: string) => item !== value)
        : [...prev[category], value];
      
      return {
        ...prev,
        [category]: updatedCategory,
      };
    });
  };

  const handleSalaryChange = (value: number[]) => {
    setFilters((prev) => ({
      ...prev,
      salaryRange: value,
    }));
  };

  const handleApplyFilters = () => {
    onFilterChange(filters);
  };

  const handleResetFilters = () => {
    const resetFilters = {
      jobTypes: [],
      departments: [],
      experienceLevels: [],
      locations: [],
      salaryRange: [10000, 100000],
    };
    setFilters(resetFilters);
    onFilterChange(resetFilters);
  };

  useEffect(() => {
    if (initialFilters && Object.keys(initialFilters).length > 0) {
      setFilters({
        ...filters,
        ...initialFilters,
      });
    }
  }, [initialFilters]);

  return (
    <div className="bg-white rounded-lg p-5 shadow-md mb-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4">Filters</h3>
      
      <Accordion type="multiple" defaultValue={["job-type", "department"]}>
        <AccordionItem value="job-type">
          <AccordionTrigger className="text-gray-800 font-semibold">Job Type</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {jobTypes.map((type) => (
                <div key={type.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`job-type-${type.id}`} 
                    checked={filters.jobTypes.includes(type.id)}
                    onCheckedChange={() => handleCheckboxChange("jobTypes", type.id)}
                  />
                  <Label htmlFor={`job-type-${type.id}`} className="text-gray-700">
                    {type.label}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="department">
          <AccordionTrigger className="text-gray-800 font-semibold">Department</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {departments?.map((dept: any) => (
                <div key={dept.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`dept-${dept.id}`} 
                    checked={filters.departments.includes(dept.id.toString())}
                    onCheckedChange={() => handleCheckboxChange("departments", dept.id.toString())}
                  />
                  <Label htmlFor={`dept-${dept.id}`} className="text-gray-700">
                    {dept.name}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="experience">
          <AccordionTrigger className="text-gray-800 font-semibold">Experience Level</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {experienceLevels.map((level) => (
                <div key={level.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`exp-${level.id}`} 
                    checked={filters.experienceLevels.includes(level.id)}
                    onCheckedChange={() => handleCheckboxChange("experienceLevels", level.id)}
                  />
                  <Label htmlFor={`exp-${level.id}`} className="text-gray-700">
                    {level.label}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="location">
          <AccordionTrigger className="text-gray-800 font-semibold">Location</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {locations.map((location: string) => (
                <div key={location} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`loc-${location}`} 
                    checked={filters.locations.includes(location)}
                    onCheckedChange={() => handleCheckboxChange("locations", location)}
                  />
                  <Label htmlFor={`loc-${location}`} className="text-gray-700">
                    {location}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="salary">
          <AccordionTrigger className="text-gray-800 font-semibold">Salary Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider
                defaultValue={[10000, 100000]}
                value={filters.salaryRange}
                min={10000}
                max={100000}
                step={5000}
                onValueChange={handleSalaryChange}
              />
              <div className="flex justify-between text-xs text-gray-600 mt-1">
                <span>₹{filters.salaryRange[0].toLocaleString()}</span>
                <span>₹{filters.salaryRange[1].toLocaleString()}+</span>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      <div className="pt-4 flex justify-between border-t border-gray-200 mt-4">
        <Button
          variant="outline"
          onClick={handleResetFilters}
          className="text-gray-700"
        >
          Reset All
        </Button>
        <Button onClick={handleApplyFilters}>
          Apply Filters
        </Button>
      </div>

      <div className="border-t border-gray-200 mt-6 pt-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Need Help?</h3>
        <p className="text-gray-600 mb-4">
          Contact our support team for any queries regarding job applications or portal usage.
        </p>
        <div className="space-y-3">
          <div className="flex items-center">
            <PhoneCall className="h-4 w-4 text-primary mr-2" />
            <span className="text-gray-700">Helpline: 1800-XXX-XXXX</span>
          </div>
          <div className="flex items-center">
            <Mail className="h-4 w-4 text-primary mr-2" />
            <span className="text-gray-700">Email: support@rajasthan.gov.in</span>
          </div>
          <div className="flex items-center">
            <HelpCircle className="h-4 w-4 text-primary mr-2" />
            <a href="#" className="text-primary hover:underline">View FAQs</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobFilters;
