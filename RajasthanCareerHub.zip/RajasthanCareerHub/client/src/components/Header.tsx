import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  
  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok && res.status !== 401) throw new Error('Failed to fetch user');
      if (res.status === 401) return null;
      return res.json();
    }),
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: false,
  });

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <img 
              src="https://cdn-icons-png.flaticon.com/512/4406/4406172.png" 
              alt="Rajasthan Govt Logo" 
              className="h-16 mr-3" 
            />
            <div>
              <h1 className="text-white font-heading font-bold text-xl sm:text-2xl">Rajasthan Government</h1>
              <p className="text-blue-200 text-sm sm:text-base">Technical & Education Department</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-1">
            <Link href="/">
              <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/' ? 'bg-primary-800' : ''} cursor-pointer`}>
                Home
              </div>
            </Link>
            <Link href="/jobs">
              <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/jobs' ? 'bg-primary-800' : ''} cursor-pointer`}>
                Jobs
              </div>
            </Link>
            <Link href="/internships">
              <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/internships' ? 'bg-primary-800' : ''} cursor-pointer`}>
                Internships
              </div>
            </Link>
            <Link href="/departments">
              <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/departments' ? 'bg-primary-800' : ''} cursor-pointer`}>
                Departments
              </div>
            </Link>
            
            {user ? (
              <>
                <Link href="/applications">
                  <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/applications' ? 'bg-primary-800' : ''} cursor-pointer`}>
                    My Applications
                  </div>
                </Link>
                <Link href="/profile">
                  <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/profile' ? 'bg-primary-800' : ''} cursor-pointer`}>
                    Profile
                  </div>
                </Link>
                {user.isAdmin && (
                  <Link href="/admin">
                    <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location.startsWith('/admin') ? 'bg-primary-800' : ''} cursor-pointer`}>
                      Admin
                    </div>
                  </Link>
                )}
                <form 
                  action="/api/auth/logout" 
                  method="POST"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    await fetch('/api/auth/logout', {
                      method: 'POST',
                      credentials: 'include'
                    });
                    queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
                  }}
                >
                  <Button 
                    type="submit" 
                    variant="outline"
                    className="text-white border-white hover:bg-primary-700 px-3 py-2 font-medium"
                  >
                    Logout
                  </Button>
                </form>
              </>
            ) : (
              <div className="flex space-x-2">
                <Link href="/auth/register">
                  <div className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded font-medium transition cursor-pointer">
                    Register
                  </div>
                </Link>
                <Link href="/auth/login">
                  <div className="bg-primary-700 hover:bg-primary-600 text-white px-4 py-2 rounded font-medium transition cursor-pointer">
                    Login
                  </div>
                </Link>
              </div>
            )}
          </nav>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Button
              variant="ghost"
              className="text-white hover:bg-primary-700 p-2 rounded focus:outline-none"
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2">
            <nav className="flex flex-col space-y-2">
              <Link href="/">
                <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/' ? 'bg-primary-800' : ''} cursor-pointer`}>
                  Home
                </div>
              </Link>
              <Link href="/jobs">
                <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/jobs' ? 'bg-primary-800' : ''} cursor-pointer`}>
                  Jobs
                </div>
              </Link>
              <Link href="/internships">
                <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/internships' ? 'bg-primary-800' : ''} cursor-pointer`}>
                  Internships
                </div>
              </Link>
              <Link href="/departments">
                <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/departments' ? 'bg-primary-800' : ''} cursor-pointer`}>
                  Departments
                </div>
              </Link>
              
              {user ? (
                <>
                  <Link href="/applications">
                    <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/applications' ? 'bg-primary-800' : ''} cursor-pointer`}>
                      My Applications
                    </div>
                  </Link>
                  <Link href="/profile">
                    <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location === '/profile' ? 'bg-primary-800' : ''} cursor-pointer`}>
                      Profile
                    </div>
                  </Link>
                  {user.isAdmin && (
                    <Link href="/admin">
                      <div className={`text-white hover:bg-primary-700 px-3 py-2 rounded font-medium transition ${location.startsWith('/admin') ? 'bg-primary-800' : ''} cursor-pointer`}>
                        Admin
                      </div>
                    </Link>
                  )}
                  <form 
                    action="/api/auth/logout" 
                    method="POST"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      await fetch('/api/auth/logout', {
                        method: 'POST',
                        credentials: 'include'
                      });
                      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
                    }}
                  >
                    <Button 
                      type="submit" 
                      variant="outline"
                      className="w-full text-white border-white hover:bg-primary-700 px-3 py-2 font-medium"
                    >
                      Logout
                    </Button>
                  </form>
                </>
              ) : (
                <div className="flex flex-col space-y-2 mt-2">
                  <Link href="/auth/register">
                    <div className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded font-medium transition text-center cursor-pointer">
                      Register
                    </div>
                  </Link>
                  <Link href="/auth/login">
                    <div className="bg-primary-700 hover:bg-primary-600 text-white px-4 py-2 rounded font-medium transition text-center cursor-pointer">
                      Login
                    </div>
                  </Link>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
