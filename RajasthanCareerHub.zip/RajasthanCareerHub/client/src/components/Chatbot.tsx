import { useState, useRef, useEffect } from 'react';
import { Send, Bot, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  text: string;
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { 
      id: '0', 
      type: 'bot', 
      text: 'Hello! I\'m your career advisor. How can I help you with your job search or application process?' 
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Auto-scroll to bottom of chat on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  // API call to get bot response
  const chatMutation = useMutation({
    mutationFn: async (userMessage: string) => {
      const res = await apiRequest('POST', '/api/chat', { message: userMessage });
      return res.json();
    },
    onSuccess: (data) => {
      setChatMessages(prev => [
        ...prev,
        { 
          id: Date.now().toString(), 
          type: 'bot', 
          text: data.response 
        }
      ]);
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: 'Failed to get a response. Please try again.',
        variant: 'destructive',
      });
      setChatMessages(prev => [
        ...prev,
        { 
          id: Date.now().toString(), 
          type: 'bot', 
          text: 'I\'m sorry, I\'m having trouble connecting right now. Please try again later.' 
        }
      ]);
    }
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // Add user message to chat
    setChatMessages(prev => [
      ...prev,
      { id: Date.now().toString(), type: 'user', text: message }
    ]);
    
    // Send to API
    chatMutation.mutate(message);
    
    // Clear input
    setMessage('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-full w-14 h-14 shadow-lg flex items-center justify-center"
        variant="default"
      >
        {isOpen ? <X size={24} /> : <Bot size={24} />}
      </Button>

      {/* Chat Window */}
      {isOpen && (
        <Card className="absolute bottom-16 right-0 w-80 sm:w-96 h-[500px] flex flex-col shadow-xl overflow-hidden">
          <div className="bg-primary p-3 text-white flex justify-between items-center">
            <h3 className="text-lg font-semibold">Career Advisor</h3>
            <div className="flex gap-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 text-white hover:text-white hover:bg-primary/80"
                onClick={() => setChatMessages([
                  { 
                    id: '0', 
                    type: 'bot', 
                    text: 'Hello! I\'m your career advisor. How can I help you with your job search or application process?' 
                  }
                ])}
              >
                <ChevronUp size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 text-white hover:text-white hover:bg-primary/80"
                onClick={() => setIsOpen(false)}
              >
                <X size={16} />
              </Button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {chatMessages.map(msg => (
              <div
                key={msg.id}
                className={cn(
                  "flex",
                  msg.type === "user" ? "justify-end" : "justify-start"
                )}
              >
                <div
                  className={cn(
                    "max-w-[80%] rounded-lg px-3 py-2",
                    msg.type === "user"
                      ? "bg-primary text-white"
                      : "bg-muted text-foreground"
                  )}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-3 border-t">
            <div className="flex gap-2">
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your message..."
                className="resize-none"
                rows={2}
                disabled={chatMutation.isPending}
              />
              <Button 
                size="icon"
                onClick={handleSendMessage}
                disabled={!message.trim() || chatMutation.isPending}
                className="self-end"
              >
                <Send size={18} />
              </Button>
            </div>
            <div className="text-xs text-muted-foreground mt-1 text-center">
              {chatMutation.isPending ? "Thinking..." : "Press Enter to send"}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}