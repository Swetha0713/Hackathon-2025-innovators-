import { useQuery } from "@tanstack/react-query";
import { Job } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatSalaryRange, formatDateShort, getDeadlineStatus } from "@/lib/utils";
import { Calendar, MapPin, Briefcase, Clock, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function JobRecommendations() {
  const { data: recommendedJobs, isLoading, error } = useQuery<Job[]>({
    queryKey: ["/api/recommendations"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">AI Job Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-2" />
                <div className="flex gap-2 mt-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">AI Job Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Error loading recommendations. Please complete your profile with your skills and experience.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!recommendedJobs || recommendedJobs.length === 0) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">AI Job Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            No recommended jobs found. Please complete your profile with more skills and experience
            to get personalized recommendations.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">
          AI Job Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendedJobs.map((job) => (
            <Card key={job.id} className="p-4 hover:bg-muted/40 transition-colors">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold">{job.title}</h3>
                  <p className="text-sm text-muted-foreground">{formatSalaryRange(job.salaryMin, job.salaryMax)}</p>
                  
                  <div className="flex flex-wrap gap-2 mt-2">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3 mr-1" />
                      {job.location}
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Briefcase className="h-3 w-3 mr-1" />
                      {job.jobType}
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3 mr-1" />
                      {formatDateShort(job.deadline)}
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {getDeadlineStatus(job.deadline).status}
                    </div>
                  </div>
                </div>

                <Badge variant={job.isRemote ? "outline" : "secondary"}>
                  {job.isRemote ? "Remote" : "On-site"}
                </Badge>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button 
                  asChild 
                  variant="outline" 
                  className="text-xs"
                >
                  <Link to={`/jobs/${job.id}`}>
                    View Details
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </Link>
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}