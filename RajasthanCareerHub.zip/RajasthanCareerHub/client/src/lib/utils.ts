import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, formatDistanceToNow, isAfter } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format salary range from min and max values
export function formatSalaryRange(min?: number | null, max?: number | null): string {
  if (!min && !max) return "Not specified";
  if (min && !max) return `₹${min.toLocaleString()} and above`;
  if (!min && max) return `Up to ₹${max.toLocaleString()}`;
  return `₹${min?.toLocaleString()} - ₹${max?.toLocaleString()}`;
}

// Format date to a short readable format
export function formatDateShort(date?: Date | string | null): string {
  if (!date) return "Not specified";
  return format(new Date(date), "dd MMM yyyy");
}

// Get formatted job type for display
export function getFormattedJobType(type: string): string {
  switch (type) {
    case "PERMANENT": return "Permanent";
    case "CONTRACT": return "Contract";
    case "INTERNSHIP": return "Internship";
    case "PART_TIME": return "Part-time";
    default: return type;
  }
}

// Get deadline status (active or expired)
export function getDeadlineStatus(deadline: Date | string): { status: string; color: string } {
  const deadlineDate = new Date(deadline);
  const isActive = isAfter(deadlineDate, new Date());
  
  return {
    status: isActive ? "Active" : "Expired",
    color: isActive ? "text-green-600" : "text-red-600",
  };
}

// Get days remaining until deadline
export function getDaysRemaining(deadline: Date | string): number {
  const deadlineDate = new Date(deadline);
  const today = new Date();
  
  const diffTime = deadlineDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

// Get status badge color for application status
export function getStatusBadgeColor(status: string): string {
  switch (status) {
    case "SUBMITTED": return "bg-blue-100 text-blue-800 border-blue-200";
    case "UNDER_REVIEW": return "bg-amber-100 text-amber-800 border-amber-200";
    case "SHORTLISTED": return "bg-indigo-100 text-indigo-800 border-indigo-200";
    case "INTERVIEW_SCHEDULED": return "bg-purple-100 text-purple-800 border-purple-200";
    case "SELECTED": return "bg-green-100 text-green-800 border-green-200";
    case "REJECTED": return "bg-red-100 text-red-800 border-red-200";
    default: return "bg-gray-100 text-gray-800 border-gray-200";
  }
}

// Get formatted status text
export function getFormattedStatusText(status: string): string {
  switch (status) {
    case "SUBMITTED": return "Submitted";
    case "UNDER_REVIEW": return "Under Review";
    case "SHORTLISTED": return "Shortlisted";
    case "INTERVIEW_SCHEDULED": return "Interview Scheduled";
    case "SELECTED": return "Selected";
    case "REJECTED": return "Rejected";
    default: return status;
  }
}
