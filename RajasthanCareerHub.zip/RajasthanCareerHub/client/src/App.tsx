import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";

import Header from "./components/Header";
import Footer from "./components/ui/footer";
import { Chatbot } from "./components/Chatbot";

import Home from "@/pages/Home";
import Jobs from "@/pages/Jobs";
import Internships from "@/pages/Internships";
import Departments from "@/pages/Departments";
import JobDetails from "@/pages/JobDetails";
import Apply from "@/pages/apply";
import Register from "@/pages/auth/register";
import Login from "@/pages/auth/login";
import Profile from "@/pages/Profile";
import Dashboard from "@/pages/admin/Dashboard";
import ManageJobs from "@/pages/admin/JobManager";
import Applications from "@/pages/admin/ApplicationsManager";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/jobs" component={Jobs} />
          <Route path="/internships" component={Internships} />
          <Route path="/departments" component={Departments} />
          <Route path="/jobs/:id" component={JobDetails} />
          <Route path="/apply/:id" component={Apply} />
          <Route path="/auth/register" component={Register} />
          <Route path="/auth/login" component={Login} />
          <Route path="/profile" component={Profile} />
          <Route path="/admin" component={Dashboard} />
          <Route path="/admin/jobs" component={ManageJobs} />
          <Route path="/admin/applications" component={Applications} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Chatbot />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
