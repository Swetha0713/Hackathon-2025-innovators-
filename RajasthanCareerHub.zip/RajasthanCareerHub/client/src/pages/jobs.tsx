import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import JobCard from "@/components/ui/job-card";
import JobFilters from "@/components/ui/job-filters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  LayoutList, 
  LayoutGrid, 
  Search,
  Loader2 
} from "lucide-react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const Jobs = () => {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    jobTypes: [],
    departments: [],
    experienceLevels: [],
    locations: [],
    salaryRange: [10000, 100000],
  });
  const [view, setView] = useState<"list" | "grid">("list");
  const jobsPerPage = 5;

  // Parse URL query parameters
  useEffect(() => {
    const searchParams = new URLSearchParams(location.split("?")[1] || "");
    const query = searchParams.get("query") || "";
    const departmentId = searchParams.get("departmentId") || "";
    
    setSearchQuery(query);
    if (departmentId) {
      setFilters(prev => ({
        ...prev,
        departments: [departmentId]
      }));
    }
  }, [location]);

  // Fetch departments
  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
  });

  // Fetch jobs
  const { data: allJobs, isLoading } = useQuery({
    queryKey: ["/api/jobs", searchQuery],
    queryFn: async ({ queryKey }) => {
      const query = queryKey[1] as string;
      const url = `/api/jobs${query ? `?query=${query}` : ""}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
  });

  // Filter jobs based on selected filters
  const filteredJobs = allJobs ? allJobs.filter((job: any) => {
    // Filter by job type
    if (filters.jobTypes.length > 0 && !filters.jobTypes.includes(job.type)) {
      return false;
    }
    
    // Filter by department
    if (
      filters.departments.length > 0 &&
      !filters.departments.includes(job.departmentId.toString())
    ) {
      return false;
    }
    
    // Filter by location
    if (filters.locations.length > 0) {
      const jobLocations = job.location.split(", ");
      const hasMatchingLocation = jobLocations.some((loc: string) =>
        filters.locations.includes(loc)
      );
      if (!hasMatchingLocation) return false;
    }
    
    // Filter by salary range
    const [minSalary, maxSalary] = filters.salaryRange;
    if (job.salaryMin && job.salaryMin > maxSalary) return false;
    if (job.salaryMax && job.salaryMax < minSalary) return false;
    
    return true;
  }) : [];

  // Pagination
  const totalPages = Math.ceil((filteredJobs?.length || 0) / jobsPerPage);
  const currentJobs = filteredJobs?.slice(
    (currentPage - 1) * jobsPerPage,
    currentPage * jobsPerPage
  );

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
    
    const params = new URLSearchParams();
    if (searchQuery) params.set("query", searchQuery);
    
    setLocation(`/jobs${params.toString() ? `?${params.toString()}` : ""}`);
  };

  // Handle filter changes
  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  // Handle pagination
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Page Header */}
      <section className="bg-primary/10 py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Browse Jobs</h1>
          <p className="text-gray-600">
            Find and apply for government jobs in technical and educational departments
          </p>
          
          <form 
            className="mt-4 flex flex-col md:flex-row gap-3 max-w-3xl" 
            onSubmit={handleSearch}
          >
            <Input
              type="text"
              placeholder="Search jobs, keywords, skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </form>
        </div>
      </section>
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Filters Sidebar */}
            <div className="md:w-1/4">
              <JobFilters
                onFilterChange={handleFilterChange}
                initialFilters={filters}
              />
            </div>
            
            {/* Jobs Listing */}
            <div className="md:w-3/4">
              <div className="bg-white rounded-lg p-5 shadow-md mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-primary">
                    {isLoading
                      ? "Loading jobs..."
                      : `${filteredJobs?.length || 0} ${
                          searchQuery ? `results for "${searchQuery}"` : "Job Opportunities"
                        }`}
                  </h2>
                  <div className="flex space-x-3">
                    <Button
                      variant={view === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setView("list")}
                    >
                      <LayoutList className="h-4 w-4 mr-1" />
                      List
                    </Button>
                    <Button
                      variant={view === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setView("grid")}
                    >
                      <LayoutGrid className="h-4 w-4 mr-1" />
                      Grid
                    </Button>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredJobs && filteredJobs.length > 0 ? (
                  <>
                    <div className={view === "grid" ? "grid grid-cols-1 md:grid-cols-2 gap-4" : "space-y-4"}>
                      {currentJobs.map((job: any) => (
                        <JobCard
                          key={job.id}
                          job={job}
                          departmentName={
                            departments?.find((d: any) => d.id === job.departmentId)?.name || "Department"
                          }
                        />
                      ))}
                    </div>
                    
                    {totalPages > 1 && (
                      <Pagination className="mt-6">
                        <PaginationContent>
                          <PaginationItem>
                            <PaginationPrevious 
                              onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                              className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                          
                          {[...Array(totalPages)].map((_, i) => (
                            <PaginationItem key={i + 1}>
                              <PaginationLink
                                onClick={() => handlePageChange(i + 1)}
                                isActive={currentPage === i + 1}
                              >
                                {i + 1}
                              </PaginationLink>
                            </PaginationItem>
                          ))}
                          
                          <PaginationItem>
                            <PaginationNext
                              onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                              className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                        </PaginationContent>
                      </Pagination>
                    )}
                  </>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No jobs found matching your criteria.</p>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setFilters({
                          jobTypes: [],
                          departments: [],
                          experienceLevels: [],
                          locations: [],
                          salaryRange: [10000, 100000],
                        });
                        setSearchQuery("");
                        setLocation("/jobs");
                      }}
                      className="mt-4"
                    >
                      Reset Filters
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Jobs;
