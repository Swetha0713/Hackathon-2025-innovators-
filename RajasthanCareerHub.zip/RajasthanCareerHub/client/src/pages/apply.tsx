import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChevronLeft,
  Upload,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  FileText,
  Briefcase,
  MapPin,
  Calendar,
  IndianRupee
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatSalaryRange, formatDateShort, getFormattedJobType } from "@/lib/utils";

// Form schema
const applicationSchema = z.object({
  jobId: z.string(),
  coverLetter: z.string().min(10, "Cover letter must be at least 10 characters").max(2000, "Cover letter should not exceed 2000 characters"),
  education: z.string().min(5, "Education information is required"),
  experience: z.string().optional(),
});

type ApplicationValues = z.infer<typeof applicationSchema>;

const Apply = () => {
  const [match, params] = useRoute('/apply/:jobId');
  const [location, navigate] = useLocation();
  const jobId = params?.jobId;
  const { toast } = useToast();
  
  const [resume, setResume] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to fetch user");
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get job details
  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${jobId}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch job details");
      return res.json();
    },
  });

  // Get department details
  const { data: department, isLoading: isLoadingDepartment } = useQuery({
    queryKey: [`/api/departments/${job?.departmentId}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch department details");
      return res.json();
    },
    enabled: !!job?.departmentId,
  });

  // Form setup
  const form = useForm<ApplicationValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      jobId: jobId || "",
      coverLetter: "",
      education: "",
      experience: "",
    },
  });

  // Handle Resume upload
  const handleResumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Resume file must be less than 5MB",
        });
        e.target.value = "";
        return;
      }
      
      // Check file type
      const validTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
      if (!validTypes.includes(file.type)) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Resume must be in PDF, DOC, or DOCX format",
        });
        e.target.value = "";
        return;
      }
      
      setResume(file);
    }
  };

  // Handle form submission
  const onSubmit = async (data: ApplicationValues) => {
    if (!resume) {
      toast({
        variant: "destructive",
        title: "Resume required",
        description: "Please upload your resume",
      });
      return;
    }

    if (!user) {
      navigate("/auth/login?redirect=" + location);
      return;
    }

    setIsSubmitting(true);
    setSubmitError("");

    try {
      const formData = new FormData();
      
      // Append form fields
      Object.entries(data).forEach(([key, value]) => {
        formData.append(key, value);
      });
      
      // Append resume file
      formData.append("resume", resume);
      
      // Submit application
      const response = await fetch("/api/applications", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit application");
      }

      setSubmitSuccess(true);
      toast({
        title: "Application submitted",
        description: "Your application has been submitted successfully",
      });
      
      setTimeout(() => {
        navigate("/profile");
      }, 3000);
    } catch (error) {
      console.error(error);
      setSubmitError(error instanceof Error ? error.message : "Failed to submit application");
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: error instanceof Error ? error.message : "Failed to submit application",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Redirect if not logged in
  if (!isLoadingUser && !user) {
    navigate(`/auth/login?redirect=/apply/${jobId}`);
    return null;
  }

  // Loading state
  if (isLoadingJob || isLoadingDepartment || isLoadingUser) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  // Error state if job not found
  if (!job) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Job Not Found</h1>
            <p className="text-gray-600 mb-6">
              The job you're trying to apply for doesn't exist or has been removed.
            </p>
            <Button asChild>
              <Link href="/jobs">Browse All Jobs</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Success state
  if (submitSuccess) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardHeader>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle className="text-center">Application Submitted!</CardTitle>
              <CardDescription className="text-center">
                Your application has been successfully submitted for review.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-sm border-t border-b border-gray-100 py-3">
                  <div className="flex justify-between mb-1">
                    <span className="font-medium">Job Position:</span>
                    <span>{job.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Department:</span>
                    <span>{department?.name}</span>
                  </div>
                </div>
                <p className="text-center text-gray-600 text-sm">
                  You'll receive notifications about the status of your application.
                  You can also check your application status in your profile.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button asChild>
                <Link href="/profile">
                  Go to Profile
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <Button variant="ghost" asChild className="mb-2">
              <Link href={`/jobs/${jobId}`}>
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Job Details
              </Link>
            </Button>
            
            <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Apply for Position</h1>
            <p className="text-gray-600 mb-6">
              Complete the form below to apply for the selected position
            </p>
            
            {/* Job Summary Card */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>{job.title}</CardTitle>
                <CardDescription>
                  {department?.name} | {job.location}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3 mb-3">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Briefcase className="h-3 w-3" />
                    {getFormattedJobType(job.type)}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {job.location}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <IndianRupee className="h-3 w-3" />
                    {formatSalaryRange(job.salaryMin, job.salaryMax)}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Deadline: {formatDateShort(job.deadline)}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">
                  {job.description.substring(0, 200)}
                  {job.description.length > 200 ? "..." : ""}
                </p>
              </CardContent>
            </Card>
            
            {submitError && (
              <Alert variant="destructive" className="mb-6">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{submitError}</AlertDescription>
              </Alert>
            )}
            
            {/* Application Form */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Application Form</CardTitle>
                    <CardDescription>
                      Please provide accurate information to support your application
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="coverLetter"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cover Letter</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Tell us why you're interested in this position and why you're a good fit..."
                                  className="h-32"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Explain your interest in the position and highlight relevant qualifications.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="education"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Education</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Provide details about your educational background..."
                                  className="h-24"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Include degrees, institutions, graduation years, and fields of study.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="experience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Work Experience</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Describe your relevant work experience..."
                                  className="h-24"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                List your relevant work experience, including employers, positions, and responsibilities.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div>
                          <Label htmlFor="resume">Resume / CV</Label>
                          <div className="mt-1 flex items-center">
                            <Label
                              htmlFor="resume-upload"
                              className="flex items-center justify-center w-full h-24 px-4 transition border-2 border-gray-300 border-dashed rounded-md appearance-none cursor-pointer hover:border-gray-400 focus:outline-none"
                            >
                              {resume ? (
                                <div className="flex items-center space-x-2">
                                  <FileText className="h-8 w-8 text-green-500" />
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">{resume.name}</p>
                                    <p className="text-xs text-gray-500">
                                      {(resume.size / 1024 / 1024).toFixed(2)} MB
                                    </p>
                                  </div>
                                </div>
                              ) : (
                                <div className="space-y-1 text-center">
                                  <Upload className="mx-auto h-8 w-8 text-gray-400" />
                                  <div className="text-sm text-gray-600">
                                    <span className="font-medium text-primary hover:underline">
                                      Upload your resume
                                    </span>
                                    <p className="text-xs text-gray-500">PDF, DOC, or DOCX (Max 5MB)</p>
                                  </div>
                                </div>
                              )}
                            </Label>
                            <input
                              id="resume-upload"
                              name="resume"
                              type="file"
                              className="sr-only"
                              onChange={handleResumeChange}
                              accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            />
                          </div>
                          {!resume && (
                            <p className="text-sm text-red-500 mt-1">Resume is required</p>
                          )}
                        </div>
                        
                        <div className="flex justify-end">
                          <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Submitting...
                              </>
                            ) : (
                              <>Submit Application</>
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </div>
              
              {/* Sidebar */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Application Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 text-sm">
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                          <span className="text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          Tailor your cover letter to the specific job requirements
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                          <span className="text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          Highlight relevant skills and experiences that match the job description
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                          <span className="text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          Ensure your resume is up-to-date and clearly formatted
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                          <span className="text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          Proofread your application before submitting to avoid errors
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                          <span className="text-xs font-bold">5</span>
                        </div>
                        <span className="text-gray-700">
                          Be honest and accurate about your qualifications and experience
                        </span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Selection Process</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 text-sm">
                      <div className="flex items-start">
                        <Badge className="mr-2 mt-0.5">1</Badge>
                        <div>
                          <h4 className="font-medium text-gray-800">Application Review</h4>
                          <p className="text-gray-600">
                            All applications are reviewed by HR and the department hiring team
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Badge className="mr-2 mt-0.5">2</Badge>
                        <div>
                          <h4 className="font-medium text-gray-800">Shortlisting</h4>
                          <p className="text-gray-600">
                            Qualified candidates are shortlisted for the next stage
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Badge className="mr-2 mt-0.5">3</Badge>
                        <div>
                          <h4 className="font-medium text-gray-800">Interview</h4>
                          <p className="text-gray-600">
                            Shortlisted candidates are invited for an interview
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Badge className="mr-2 mt-0.5">4</Badge>
                        <div>
                          <h4 className="font-medium text-gray-800">Selection</h4>
                          <p className="text-gray-600">
                            Final candidates are selected based on overall evaluation
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Apply;
