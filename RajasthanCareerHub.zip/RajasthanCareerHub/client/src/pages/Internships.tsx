import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, MapPin, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import JobCard from "@/components/job/JobCard";
import type { Job, Department } from "@shared/schema";

const Internships = () => {
  const [filters, setFilters] = useState({
    keyword: "",
    departmentId: "",
    location: "",
    postedAfter: ""
  });

  const [sortBy, setSortBy] = useState("recent");
  
  // Fetch the departments for the filter dropdown
  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: () => fetch('/api/departments').then(res => res.json()),
  });

  // Fetch internships with filters
  const { data: jobs, isLoading, refetch } = useQuery({
    queryKey: ['/api/internships', filters],
    queryFn: () => {
      const params = new URLSearchParams();
      
      // Add other filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== "") {
          params.append(key, String(value));
        }
      });
      
      return fetch(`/api/internships?${params.toString()}`).then(res => res.json());
    },
  });

  const handleFilterChange = (name: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    refetch();
  };

  const handleReset = () => {
    setFilters({
      keyword: "",
      departmentId: "",
      location: "",
      postedAfter: ""
    });
    setSortBy("recent");
  };

  // Sort internships based on the selected option
  const sortedInternships = jobs ? [...jobs].sort((a: Job, b: Job) => {
    switch (sortBy) {
      case "recent":
        return new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime();
      case "stipend-high":
        return (b.salaryMax || 0) - (a.salaryMax || 0);
      case "stipend-low":
        return (a.salaryMin || 0) - (b.salaryMin || 0);
      default:
        return 0;
    }
  }) : [];

  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="py-8">
        <div className="container mx-auto px-4">
          <h2 className="font-heading font-bold text-2xl sm:text-3xl text-gray-800 mb-6">Find Internship Opportunities</h2>
          
          <Card className="mb-8">
            <CardContent className="p-6">
              <form onSubmit={handleSearch}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <Label htmlFor="keyword">Keyword</Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input 
                        id="keyword" 
                        className="pl-10" 
                        placeholder="Skills, keywords..."
                        value={filters.keyword}
                        onChange={(e) => handleFilterChange("keyword", e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="department">Department</Label>
                    <Select 
                      value={filters.departmentId} 
                      onValueChange={(value) => handleFilterChange("departmentId", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All Departments" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        {departments?.map((dept: Department) => (
                          <SelectItem key={dept.id} value={String(dept.id)}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input 
                        id="location" 
                        className="pl-10" 
                        placeholder="City or district..."
                        value={filters.location}
                        onChange={(e) => handleFilterChange("location", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-center">
                  <div className="mb-3 sm:mb-0">
                    <Label htmlFor="postDate" className="mr-2">Posted Date:</Label>
                    <Select 
                      value={filters.postedAfter} 
                      onValueChange={(value) => handleFilterChange("postedAfter", value)}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Any Time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any Time</SelectItem>
                        <SelectItem value={new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()}>Today</SelectItem>
                        <SelectItem value={new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()}>Last 3 Days</SelectItem>
                        <SelectItem value={new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()}>Last Week</SelectItem>
                        <SelectItem value={new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()}>Last Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleReset}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-700 border-none"
                    >
                      Reset
                    </Button>
                    <Button type="submit">Search</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
          
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-heading font-bold text-2xl text-gray-800">
              {isLoading ? 'Searching...' : `${sortedInternships.length} Internship Opportunities`}
            </h2>
            <div className="flex items-center">
              <span className="text-gray-600 text-sm mr-2">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="min-w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Date (Newest)</SelectItem>
                  <SelectItem value="stipend-high">Stipend (High to Low)</SelectItem>
                  <SelectItem value="stipend-low">Stipend (Low to High)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mb-8">
            {isLoading ? (
              <div className="grid grid-cols-1 gap-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-6 bg-gray-200 rounded mb-2 w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-4 w-1/2"></div>
                      <div className="flex gap-2 mb-4">
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                      </div>
                      <div className="h-10 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : sortedInternships.length > 0 ? (
              sortedInternships.map((job: Job) => (
                <JobCard key={job.id} job={job} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No internships found matching your criteria. Please try different filters.</p>
                </CardContent>
              </Card>
            )}
          </div>
          
          {sortedInternships.length > 10 && (
            <div className="flex justify-center">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary-50">
                Load More Internships
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Internships;
