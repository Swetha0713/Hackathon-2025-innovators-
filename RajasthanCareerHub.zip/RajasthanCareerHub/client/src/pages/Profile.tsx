import { useState } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Loader2, User, BellRing, Settings, LogOut, PenSquare } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import type { User as UserType, UserProfile, Notification as NotificationType } from "@shared/schema";
import JobRecommendations from "@/components/profile/JobRecommendations";

// Form schema for profile
const profileSchema = z.object({
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters",
  }),
  lastName: z.string().min(2, {
    message: "Last name must be at least 2 characters",
  }),
  email: z.string().email({
    message: "Please enter a valid email address",
  }),
  phone: z.string().optional(),
});

// Form schema for education details
const educationSchema = z.object({
  education: z.string().min(2, {
    message: "Education details are required",
  }),
  experience: z.string().optional(),
  skills: z.string().min(2, {
    message: "Skills are required",
  }),
  address: z.string().optional(),
  city: z.string().min(2, {
    message: "City is required",
  }),
  state: z.string().min(2, {
    message: "State is required",
  }),
  pincode: z.string().min(6, {
    message: "Pincode must be at least 6 characters",
  }),
  resumePath: z.any().optional(),
});

type ProfileValues = z.infer<typeof profileSchema>;
type EducationValues = z.infer<typeof educationSchema>;

const Profile = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [resumeFile, setResumeFile] = useState<File | null>(null);

  // Check if user is logged in
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 401) {
          // Redirect to login if unauthorized
          navigate('/login?redirect=/profile');
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      return res.json();
    }),
  });

  // Get user profile
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['/api/profile'],
    queryFn: () => fetch('/api/profile', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 404) {
          // Profile not found is ok, user might not have created one yet
          return null;
        }
        throw new Error('Failed to fetch profile');
      }
      return res.json();
    }),
    enabled: !!user,
  });

  // Get user notifications
  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: () => fetch('/api/notifications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch notifications');
      return res.json();
    }),
    enabled: !!user,
  });

  // Initialize profile form
  const profileForm = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
    },
    values: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
    },
  });

  // Initialize education form
  const educationForm = useForm<EducationValues>({
    resolver: zodResolver(educationSchema),
    defaultValues: {
      education: "",
      experience: "",
      skills: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      resumePath: null,
    },
    values: profile ? {
      education: profile.education || "",
      experience: profile.experience || "",
      skills: profile.skills || "",
      address: profile.address || "",
      city: profile.city || "",
      state: profile.state || "",
      pincode: profile.pincode || "",
      resumePath: null,
    } : {
      education: "",
      experience: "",
      skills: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      resumePath: null,
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (values: ProfileValues) => {
      const response = await fetch('/api/auth/me', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update profile');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
        variant: "success",
      });
      
      // Invalidate user query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update education profile mutation
  const updateEducationMutation = useMutation({
    mutationFn: async (values: EducationValues) => {
      const formData = new FormData();
      Object.entries(values).forEach(([key, value]) => {
        if (key !== 'resumePath' && value !== undefined) {
          formData.append(key, value);
        }
      });

      if (resumeFile) {
        formData.append('resume', resumeFile);
      }

      const response = await fetch('/api/profile', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update education profile');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your education and personal details have been updated successfully.",
        variant: "success",
      });
      
      // Invalidate profile query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark all notifications as read mutation
  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/notifications/read-all', {
        method: 'PUT',
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to mark notifications as read');
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate notifications query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    },
  });

  // Mark single notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'PUT',
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to mark notification as read');
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate notifications query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to logout');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Logged out successfully",
        variant: "success",
      });
      
      // Invalidate user query to refresh auth state
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      // Redirect to home page
      navigate('/');
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onProfileSubmit = (values: ProfileValues) => {
    updateProfileMutation.mutate(values);
  };

  const onEducationSubmit = (values: EducationValues) => {
    updateEducationMutation.mutate(values);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (isLoadingUser) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="animate-pulse">
            <CardContent className="p-8">
              <div className="h-6 bg-gray-200 rounded mb-4 w-1/2"></div>
              <div className="space-y-4">
                {[...Array(4)].map((_, index) => (
                  <div key={index} className="h-12 bg-gray-200 rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-amber-600 mb-4">Please log in to view your profile.</p>
              <Button onClick={() => navigate('/login?redirect=/profile')}>
                Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  // Count unread notifications
  const unreadCount = notifications?.filter((notification: NotificationType) => !notification.read).length || 0;

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div className="flex items-center mb-4 md:mb-0">
                  <Avatar className="h-16 w-16 mr-4">
                    <AvatarImage src={user.profilePicture} alt={`${user.firstName} ${user.lastName}`} />
                    <AvatarFallback className="bg-primary text-white text-lg">
                      {getInitials(user.firstName, user.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-2xl">{user.firstName} {user.lastName}</CardTitle>
                    <CardDescription className="text-base">{user.email}</CardDescription>
                  </div>
                </div>
                <Button variant="outline" onClick={handleLogout} className="flex items-center">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </CardHeader>
            
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-4 mb-8">
                  <TabsTrigger value="profile" className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </TabsTrigger>
                  <TabsTrigger value="education" className="flex items-center">
                    <PenSquare className="h-4 w-4 mr-2" />
                    Education & Resume
                  </TabsTrigger>
                  <TabsTrigger value="notifications" className="flex items-center relative">
                    <BellRing className="h-4 w-4 mr-2" />
                    Notifications
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                        {unreadCount}
                      </span>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="recommendations" className="flex items-center">
                    <Settings className="h-4 w-4 mr-2" />
                    AI Recommendations
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="profile">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                      <p className="text-gray-600 mb-4">
                        Update your personal details here. This information will be used for your job applications.
                      </p>
                    </div>
                    
                    <Form {...profileForm}>
                      <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                          <FormField
                            control={profileForm.control}
                            name="firstName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>First Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="lastName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Last Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input type="email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={profileForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              "Save Changes"
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                </TabsContent>
                
                <TabsContent value="education">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Education & Experience</h3>
                      <p className="text-gray-600 mb-4">
                        Add your educational qualifications, work experience, and skills. This information will be used on your applications.
                      </p>
                    </div>
                    
                    <Form {...educationForm}>
                      <form onSubmit={educationForm.handleSubmit(onEducationSubmit)} className="space-y-4">
                        <FormField
                          control={educationForm.control}
                          name="education"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Education</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="e.g., B.Tech Computer Science (2018-2022) from XYZ University" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Include your degrees, graduation years, and institutions
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={educationForm.control}
                          name="experience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Work Experience (Optional)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="e.g., Software Developer at ABC Company (2022-Present)" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={educationForm.control}
                          name="skills"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Skills</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="e.g., Java, Python, React, SQL, Project Management" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                List your technical and professional skills
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Separator className="my-6" />
                        
                        <div>
                          <h3 className="text-lg font-medium mb-4">Address Information</h3>
                        </div>
                        
                        <FormField
                          control={educationForm.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address (Optional)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Street address" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                          <FormField
                            control={educationForm.control}
                            name="city"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>City</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Jaipur" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={educationForm.control}
                            name="state"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Rajasthan" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={educationForm.control}
                            name="pincode"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Pincode</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 302001" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Separator className="my-6" />
                        
                        <div>
                          <h3 className="text-lg font-medium mb-4">Resume</h3>
                        </div>
                        
                        <FormField
                          control={educationForm.control}
                          name="resumePath"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Upload Resume</FormLabel>
                              <FormControl>
                                <FileUpload
                                  id="resume"
                                  accept=".pdf,.doc,.docx"
                                  maxSize={5 * 1024 * 1024} // 5MB
                                  onChange={(file) => {
                                    setResumeFile(file);
                                    field.onChange(file);
                                  }}
                                  value={resumeFile}
                                />
                              </FormControl>
                              <FormDescription>
                                Upload your resume in PDF, DOC, or DOCX format (max 5MB)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateEducationMutation.isPending}
                          >
                            {updateEducationMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              "Save Changes"
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                </TabsContent>
                
                <TabsContent value="notifications">
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-medium">Your Notifications</h3>
                      {notifications?.length > 0 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => markAllReadMutation.mutate()}
                          disabled={markAllReadMutation.isPending}
                        >
                          {markAllReadMutation.isPending ? "Marking..." : "Mark All as Read"}
                        </Button>
                      )}
                    </div>
                    
                    {!notifications || notifications.length === 0 ? (
                      <div className="bg-gray-50 rounded-lg p-8 text-center">
                        <BellRing className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-800 mb-2">No Notifications</h3>
                        <p className="text-gray-600">
                          You don't have any notifications yet. When there are updates to your applications or new opportunities matching your profile, they will appear here.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {notifications.map((notification: NotificationType) => (
                          <Card key={notification.id} className={notification.read ? 'bg-gray-50' : 'bg-white'}>
                            <CardContent className="p-4 flex items-start justify-between">
                              <div className="flex items-start">
                                <div className={`flex-shrink-0 h-2 w-2 rounded-full mt-2 mr-3 ${notification.read ? 'bg-gray-300' : 'bg-blue-500'}`}></div>
                                <div>
                                  <p className="text-gray-800">{notification.message}</p>
                                  <p className="text-xs text-gray-500 mt-1">
                                    {new Date(notification.createdAt).toLocaleString()}
                                  </p>
                                </div>
                              </div>
                              {!notification.read && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => markAsReadMutation.mutate(notification.id)}
                                  disabled={markAsReadMutation.isPending}
                                >
                                  Mark as read
                                </Button>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="recommendations">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">AI-Powered Job Recommendations</h3>
                      <p className="text-gray-600 mb-4">
                        Based on your skills, experience, and profile, we've found these personalized job recommendations for you.
                      </p>
                    </div>
                    
                    {/* AI-powered job recommendations */}
                    <JobRecommendations />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
