import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import DepartmentCard from "@/components/ui/department-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Building, Loader2 } from "lucide-react";

const Departments = () => {
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
  });

  // Fetch jobs
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
  });

  // Filter departments based on search query
  const filteredDepartments = departments
    ? departments.filter((dept: any) =>
        dept.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dept.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  // Count jobs per department
  const getJobCountForDepartment = (departmentId: number) => {
    if (!jobs) return 0;
    return jobs.filter((job: any) => job.departmentId === departmentId).length;
  };

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  const isLoading = isLoadingDepartments || isLoadingJobs;

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Page Header */}
      <section className="bg-primary/10 py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Departments</h1>
          <p className="text-gray-600">
            Explore job opportunities across various technical and educational departments
          </p>
          
          <form 
            className="mt-4 flex flex-col md:flex-row gap-3 max-w-3xl" 
            onSubmit={handleSearch}
          >
            <Input
              type="text"
              placeholder="Search departments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </form>
        </div>
      </section>
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="all">All Departments</TabsTrigger>
                <TabsTrigger value="technical">Technical</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
              </TabsList>
              
              <div className="text-sm text-gray-600">
                {isLoading ? (
                  <span className="flex items-center">
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Loading...
                  </span>
                ) : (
                  <span>{departments?.length || 0} departments</span>
                )}
              </div>
            </div>
            
            <TabsContent value="all" className="mt-0">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredDepartments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {filteredDepartments.map((dept: any) => (
                    <DepartmentCard 
                      key={dept.id} 
                      department={dept} 
                      jobCount={getJobCountForDepartment(dept.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-white rounded-lg p-8 max-w-md mx-auto shadow-md">
                    <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">No departments found</h3>
                    <p className="text-gray-500 mb-4">
                      We couldn't find any departments matching your search criteria.
                    </p>
                    {searchQuery && (
                      <Button 
                        variant="outline" 
                        onClick={() => setSearchQuery("")}
                      >
                        Clear Search
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="technical" className="mt-0">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {filteredDepartments
                    .filter((dept: any) => 
                      dept.name.toLowerCase().includes("technical") || 
                      dept.name.toLowerCase().includes("engineering") ||
                      dept.name.toLowerCase().includes("technology") ||
                      dept.name.toLowerCase().includes("it")
                    )
                    .map((dept: any) => (
                      <DepartmentCard 
                        key={dept.id} 
                        department={dept} 
                        jobCount={getJobCountForDepartment(dept.id)}
                      />
                    ))
                  }
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="education" className="mt-0">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {filteredDepartments
                    .filter((dept: any) => 
                      dept.name.toLowerCase().includes("education") || 
                      dept.name.toLowerCase().includes("teaching") ||
                      dept.name.toLowerCase().includes("academic")
                    )
                    .map((dept: any) => (
                      <DepartmentCard 
                        key={dept.id} 
                        department={dept} 
                        jobCount={getJobCountForDepartment(dept.id)}
                      />
                    ))
                  }
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          {/* Department Structure */}
          <div className="mt-12 bg-white rounded-lg p-6 shadow-md">
            <h2 className="text-xl font-bold text-primary mb-4">Department Structure</h2>
            <p className="text-gray-700 mb-6">
              The Technical and Education departments of the Government of Rajasthan are organized into several 
              specialized divisions to efficiently deliver public services and implement government initiatives.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Technical Departments</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">1</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Information Technology Department</span>
                      <p className="text-sm text-gray-600">Focuses on software development, cybersecurity, and digital infrastructure.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">2</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Engineering Department</span>
                      <p className="text-sm text-gray-600">Handles civil, electrical, and mechanical engineering projects.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">3</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Research & Development</span>
                      <p className="text-sm text-gray-600">Focuses on innovation and technological advancements.</p>
                    </div>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Education Departments</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">1</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Primary Education</span>
                      <p className="text-sm text-gray-600">Oversees elementary education across the state.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">2</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Higher Education</span>
                      <p className="text-sm text-gray-600">Manages colleges, universities, and vocational training.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                      <span className="text-xs font-bold">3</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-800">Teacher Training & Development</span>
                      <p className="text-sm text-gray-600">Focuses on teacher skill enhancement and professional development.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Departments;
