import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  MapPin, 
  Calendar, 
  Clock, 
  GraduationCap, 
  Briefcase,
  Building,
  CreditCard,
  CheckCircle,
  Home,
  ExternalLink,
  Sparkles
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import type { Job, Department } from "@shared/schema";
import PersonalizedJobDescription from "@/components/job/PersonalizedJobDescription";

const JobDetails = () => {
  const [match, params] = useRoute<{ id: string }>("/jobs/:id");
  const jobId = match ? parseInt(params.id) : 0;

  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${jobId}`],
    queryFn: () => fetch(`/api/jobs/${jobId}`).then(res => {
      if (!res.ok) throw new Error("Failed to fetch job details");
      return res.json();
    }),
    enabled: !!jobId,
  });

  const { data: department } = useQuery({
    queryKey: [`/api/departments/${job?.departmentId}`],
    queryFn: () => fetch(`/api/departments/${job?.departmentId}`).then(res => {
      if (!res.ok) throw new Error("Failed to fetch department details");
      return res.json();
    }),
    enabled: !!job?.departmentId,
  });

  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok && res.status !== 401) throw new Error('Failed to fetch user');
      if (res.status === 401) return null;
      return res.json();
    }),
    retry: false,
  });

  const { data: applications } = useQuery({
    queryKey: ['/api/applications', { userId: user?.id }],
    queryFn: () => fetch('/api/applications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch applications');
      return res.json();
    }),
    enabled: !!user,
  });

  // Check if user has already applied for this job
  const hasApplied = applications?.some((app: any) => app.jobId === jobId);

  const formatJobType = (type: string) => {
    return type.replace('_', ' ').toLowerCase()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const formatExperience = (level: string) => {
    switch(level) {
      case 'ENTRY_LEVEL': return 'Entry Level';
      case 'JUNIOR': return '1-3 years';
      case 'MID_LEVEL': return '3-5 years';
      case 'SENIOR': return '5+ years';
      default: return level;
    }
  };

  const formatSalary = (min?: number, max?: number) => {
    if (!min && !max) return 'Not specified';
    if (!max) return `₹${min} LPA`;
    if (!min) return `Up to ₹${max} LPA`;
    return `₹${min}-${max} LPA`;
  };

  if (isLoadingJob) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="animate-pulse">
            <CardContent className="p-8">
              <div className="h-8 bg-gray-200 rounded mb-4 w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded mb-6 w-1/2"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="h-24 bg-gray-200 rounded"></div>
                <div className="h-24 bg-gray-200 rounded"></div>
              </div>
              <div className="h-4 bg-gray-200 rounded mb-3 w-full"></div>
              <div className="h-4 bg-gray-200 rounded mb-3 w-full"></div>
              <div className="h-4 bg-gray-200 rounded mb-3 w-3/4"></div>
              <div className="h-10 bg-gray-200 rounded w-40 mt-6"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-red-500 mb-4">Job not found or has been removed.</p>
              <Link href="/jobs">
                <Button>Back to Jobs</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Link href="/jobs">
              <a className="text-primary hover:text-primary-dark font-medium inline-flex items-center">
                <Home className="mr-2 h-4 w-4" />
                <span>Back to Jobs</span>
              </a>
            </Link>
          </div>
          
          <Card className="mb-6">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-gray-800 mb-2">{job.title}</h1>
                  <p className="text-gray-600 mb-3">{department?.name}, {job.location}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                      {formatJobType(job.jobType)}
                    </Badge>
                    {job.isRemote && (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        Remote
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="mt-3 md:mt-0 text-right">
                  <p className="text-green-600 font-semibold text-xl">{formatSalary(job.salaryMin, job.salaryMax)}</p>
                  <p className="text-sm text-gray-500">
                    Posted: {format(new Date(job.postedAt), 'dd MMM yyyy')}
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="flex items-center">
                  <MapPin className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">{job.location}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">Application Deadline: {format(new Date(job.deadline), 'dd MMM yyyy')}</span>
                </div>
                <div className="flex items-center">
                  <GraduationCap className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">Qualification: {job.qualifications.split(',')[0]}</span>
                </div>
                <div className="flex items-center">
                  <Briefcase className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">Experience: {formatExperience(job.experience)}</span>
                </div>
                <div className="flex items-center">
                  <Building className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">Department: {department?.name}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="text-gray-400 mr-2 h-5 w-5" />
                  <span className="text-gray-600">Employment Type: {formatJobType(job.jobType)}</span>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-3">Job Description</h2>
                <p className="text-gray-600 whitespace-pre-line mb-4">{job.description}</p>
              </div>
              
              {/* Only show personalized description for logged in users */}
              {user && (
                <div className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-100">
                  <div className="flex items-center mb-3">
                    <Sparkles className="h-5 w-5 text-purple-500 mr-2" />
                    <h2 className="text-lg font-semibold text-gray-800">Personalized AI Insights</h2>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">Based on your profile and skills, here's how this job aligns with your experience:</p>
                  <PersonalizedJobDescription jobId={job.id} />
                </div>
              )}
              
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-3">Responsibilities</h2>
                <ul className="list-disc pl-5 space-y-2">
                  {job.responsibilities.split('\n').map((resp, index) => (
                    <li key={index} className="text-gray-600">{resp}</li>
                  ))}
                </ul>
              </div>
              
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-3">Qualifications</h2>
                <ul className="list-disc pl-5 space-y-2">
                  {job.qualifications.split('\n').map((qual, index) => (
                    <li key={index} className="text-gray-600">{qual}</li>
                  ))}
                </ul>
              </div>
              
              <div className="mt-8">
                {!user ? (
                  <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mb-6">
                    <p className="text-amber-700">Please log in to apply for this position.</p>
                    <div className="mt-3">
                      <Link href={`/login?redirect=/jobs/${job.id}`}>
                        <Button className="mr-3">Login</Button>
                      </Link>
                      <Link href="/register">
                        <Button variant="outline">Register</Button>
                      </Link>
                    </div>
                  </div>
                ) : hasApplied ? (
                  <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6 flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <p className="text-green-700">You have already applied for this position.</p>
                    <Link href="/applications">
                      <Button variant="link" className="ml-2">View your applications</Button>
                    </Link>
                  </div>
                ) : new Date() > new Date(job.deadline) ? (
                  <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
                    <p className="text-red-700">The application deadline for this position has passed.</p>
                  </div>
                ) : (
                  <Link href={`/apply/${job.id}`}>
                    <Button size="lg" className="bg-primary hover:bg-primary-dark text-white px-6">
                      Apply Now
                    </Button>
                  </Link>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Share This Job</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Button variant="outline" size="sm" className="inline-flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                  Facebook
                </Button>
                <Button variant="outline" size="sm" className="inline-flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                  </svg>
                  Twitter
                </Button>
                <Button variant="outline" size="sm" className="inline-flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect x="2" y="9" width="4" height="12"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm" className="inline-flex items-center">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Copy Link
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;
