import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { FileUpload } from "@/components/ui/file-upload";
import { Home, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";

// Form schema
const applicationSchema = z.object({
  coverLetter: z.string().min(10, {
    message: "Cover letter must be at least 10 characters",
  }).max(5000, {
    message: "Cover letter must not be longer than 5000 characters",
  }),
  resume: z.any()
    .refine((file) => file !== null, {
      message: "Resume is required",
    })
});

type ApplicationValues = z.infer<typeof applicationSchema>;

const ApplicationSubmit = () => {
  const [match, params] = useRoute<{ id: string }>("/apply/:id");
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const jobId = match ? parseInt(params.id) : 0;
  
  // Check if user is logged in
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 401) {
          // Redirect to login if unauthorized
          setLocation(`/login?redirect=/apply/${jobId}`);
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      return res.json();
    }),
  });

  // Fetch job details
  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${jobId}`],
    queryFn: () => fetch(`/api/jobs/${jobId}`).then(res => {
      if (!res.ok) throw new Error("Failed to fetch job details");
      return res.json();
    }),
    enabled: !!jobId,
  });

  // Check if user has already applied for this job
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ['/api/applications', { userId: user?.id }],
    queryFn: () => fetch('/api/applications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch applications');
      return res.json();
    }),
    enabled: !!user,
  });

  const hasApplied = applications?.some((app: any) => app.jobId === jobId);

  // Initialize form
  const form = useForm<ApplicationValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      coverLetter: "",
      resume: null
    },
  });

  // Create application mutation
  const createApplication = useMutation({
    mutationFn: async (values: ApplicationValues) => {
      const formData = new FormData();
      formData.append('jobId', jobId.toString());
      formData.append('coverLetter', values.coverLetter);
      formData.append('resume', values.resume);

      const response = await fetch('/api/applications', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to submit application');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your application has been successfully submitted.",
        variant: "success",
      });
      
      // Invalidate applications query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/applications'] });
      
      // Redirect to applications page
      setLocation('/applications');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ApplicationValues) => {
    createApplication.mutate(values);
  };

  if (isLoadingUser || isLoadingJob || isLoadingApplications) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-8">
            <div className="h-6 bg-gray-200 rounded w-1/2 mb-4 animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-8 animate-pulse"></div>
            <div className="space-y-6">
              <div className="h-32 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-64 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-10 bg-gray-200 rounded w-32 animate-pulse"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-8 text-center">
            <p className="text-red-500 mb-4">Job not found or has been removed.</p>
            <Link href="/jobs">
              <Button>Back to Jobs</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-8 text-center">
            <p className="text-amber-600 mb-4">Please log in to apply for this position.</p>
            <div className="flex justify-center space-x-4">
              <Link href={`/login?redirect=/apply/${jobId}`}>
                <Button>Login</Button>
              </Link>
              <Link href="/register">
                <Button variant="outline">Register</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (hasApplied) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-8 text-center">
            <p className="text-green-600 mb-4">You have already applied for this position.</p>
            <div className="flex justify-center space-x-4">
              <Link href="/applications">
                <Button>View Your Applications</Button>
              </Link>
              <Link href="/jobs">
                <Button variant="outline">Browse More Jobs</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (new Date() > new Date(job.deadline)) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-8 text-center">
            <p className="text-red-600 mb-4">The application deadline for this position has passed.</p>
            <Link href="/jobs">
              <Button>Browse Other Jobs</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <Link href={`/jobs/${jobId}`}>
              <a className="text-primary hover:text-primary-dark font-medium inline-flex items-center">
                <ArrowLeft className="mr-2 h-4 w-4" />
                <span>Back to Job Details</span>
              </a>
            </Link>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Apply for: {job.title}</CardTitle>
              <CardDescription>{job.departmentName}, {job.location}</CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-800 mb-2">Application Information</h3>
                <p className="text-gray-600 mb-4">
                  Please complete the application form below. Make sure to upload your resume and write a cover letter explaining why you are a good fit for this position.
                </p>
                
                <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-4">
                  <p className="text-blue-700 text-sm">
                    Your application will be reviewed by the hiring team. You will be notified of any updates via email and on your profile.
                  </p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="resume"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Resume/CV</FormLabel>
                        <FormControl>
                          <FileUpload
                            id="resume"
                            accept=".pdf,.doc,.docx"
                            maxSize={5 * 1024 * 1024} // 5MB
                            onChange={field.onChange}
                            value={field.value}
                          />
                        </FormControl>
                        <FormDescription>
                          Upload your resume in PDF, DOC, or DOCX format (max 5MB)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="coverLetter"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cover Letter</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Write your cover letter here..."
                            className="min-h-[200px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Explain why you are a good fit for this position and what you can contribute.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      size="lg"
                      disabled={createApplication.isPending}
                    >
                      {createApplication.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
            
            <CardFooter className="bg-gray-50 border-t px-6 py-4">
              <p className="text-sm text-gray-500">
                By submitting this application, you confirm that all the information provided is accurate and complete.
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ApplicationSubmit;
