import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import Stats from "@/components/ui/stats";
import JobCard from "@/components/ui/job-card";
import DepartmentCard from "@/components/ui/department-card";
import ApplicationProcess from "@/components/ui/application-process";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Search } from "lucide-react";

const Home = () => {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");

  // Fetch departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
  });

  // Fetch jobs (limited to 4 for the homepage)
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      const allJobs = await res.json();
      // Sort by posted date (newest first)
      return allJobs
        .sort((a: any, b: any) => new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime())
        .slice(0, 4); // Get only the 4 most recent jobs
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const queryParams = new URLSearchParams();
    
    if (searchQuery) {
      queryParams.set("query", searchQuery);
    }
    
    if (departmentFilter) {
      queryParams.set("departmentId", departmentFilter);
    }
    
    navigate(`/jobs?${queryParams.toString()}`);
  };

  // Count jobs per department
  const getJobCountForDepartment = (departmentId: number) => {
    if (!jobs) return 0;
    return jobs.filter((job: any) => job.departmentId === departmentId).length;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Hero Section */}
      <section className="bg-primary text-white py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="md:flex items-center">
            <div className="md:w-3/5 md:pr-8">
              <h2 className="text-2xl md:text-4xl font-bold mb-4 leading-tight">
                Discover Opportunities with <br />Government of Rajasthan
              </h2>
              <p className="mb-6 text-white/90">
                Find and apply for government jobs and internships in technical and educational
                departments. Build your career in public service.
              </p>
              
              <div className="bg-white rounded-lg p-4 shadow-lg">
                <form className="flex flex-col md:flex-row gap-3" onSubmit={handleSearch}>
                  <div className="flex-1">
                    <Input
                      type="text"
                      placeholder="Search jobs, keywords, departments..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div className="md:w-1/4">
                    <Select
                      value={departmentFilter}
                      onValueChange={setDepartmentFilter}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All Departments" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        {departments?.map((dept: any) => (
                          <SelectItem key={dept.id} value={dept.id.toString()}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="bg-[#D97D0D] hover:bg-[#D97D0D]/90 text-white">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </form>
              </div>
            </div>
            <div className="hidden md:block md:w-2/5">
              {/* SVG illustration instead of image */}
              <div className="bg-white/10 rounded-lg p-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-full h-auto"
                >
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                  <path d="M6 11h4"></path>
                  <path d="M14 11h4"></path>
                  <path d="M6 15h4"></path>
                  <path d="M14 15h4"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Stats Section */}
      <Stats />
      
      {/* Latest Jobs Section */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-primary">Latest Opportunities</h2>
            <Button variant="outline" asChild>
              <Link href="/jobs">View All Jobs</Link>
            </Button>
          </div>
          
          {isLoadingJobs ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : jobs && jobs.length > 0 ? (
            <div className="space-y-4">
              {jobs.map((job: any) => (
                <JobCard 
                  key={job.id} 
                  job={job} 
                  departmentName={
                    departments?.find((d: any) => d.id === job.departmentId)?.name || "Department"
                  }
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No jobs available at the moment.</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Featured Departments Section */}
      <section className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-primary mb-6">Featured Departments</h2>
          
          {isLoadingDepartments ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : departments && departments.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {departments.slice(0, 3).map((dept: any) => (
                <DepartmentCard 
                  key={dept.id} 
                  department={dept} 
                  jobCount={getJobCountForDepartment(dept.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No departments available.</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Application Process Section */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <ApplicationProcess />
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-12 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Start Your Career in Government?</h2>
          <p className="mb-6 text-white/90 max-w-2xl mx-auto">
            Join the Technical and Education Department of the Government of Rajasthan and contribute
            to the development of the state. Explore opportunities that match your skills and aspirations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              asChild
              className="bg-white text-primary hover:bg-gray-100"
            >
              <Link href="/jobs">Browse All Jobs</Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              asChild
              className="text-white border-white hover:bg-white hover:text-primary"
            >
              <Link href="/internships">View Internships</Link>
            </Button>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Home;
