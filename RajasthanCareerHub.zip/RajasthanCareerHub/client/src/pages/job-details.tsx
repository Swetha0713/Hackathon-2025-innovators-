import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useRoute, useLocation } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Briefcase,
  MapPin,
  Calendar,
  IndianRupee,
  Clock,
  ChevronLeft,
  Share2,
  Bookmark,
  FileText,
  Loader2,
  GraduationCap,
  Building,
  AlertTriangle
} from "lucide-react";
import {
  formatDateShort,
  formatSalaryRange,
  getDeadlineStatus,
  getFormattedJobType,
  getDaysRemaining
} from "@/lib/utils";

const JobDetails = () => {
  const [match, params] = useRoute('/jobs/:id');
  const [, navigate] = useLocation();
  const jobId = params?.id;

  // Fetch job details
  const { data: job, isLoading, isError } = useQuery({
    queryKey: [`/api/jobs/${jobId}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch job details");
      return res.json();
    },
  });

  // Fetch department details
  const { data: department, isLoading: isLoadingDepartment } = useQuery({
    queryKey: [`/api/departments/${job?.departmentId}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch department details");
      return res.json();
    },
    enabled: !!job?.departmentId,
  });

  // Fetch current user
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (res.status === 401) return null;
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get skills from job
  const skillsList = job?.skills?.split(",").map((skill: string) => skill.trim()) || [];
  const deadlineStatus = job ? getDeadlineStatus(job.deadline) : { text: "", className: "" };
  const daysRemaining = job ? getDaysRemaining(job.deadline) : 0;
  const isDeadlinePassed = daysRemaining < 0;

  // Check if the user has already applied for this job
  const { data: userApplications } = useQuery({
    queryKey: ["/api/applications/user"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) return [];
        return res.json();
      } catch (error) {
        return [];
      }
    },
    enabled: !!user,
  });

  const hasApplied = userApplications?.some((app: any) => app.jobId === parseInt(jobId as string));

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: job.title,
        text: `Check out this job opportunity: ${job.title}`,
        url: window.location.href,
      })
      .catch((error) => {
        console.log('Error sharing', error);
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  if (isLoading || isLoadingDepartment) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  if (isError || !job) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Job Not Found</h1>
            <p className="text-gray-600 mb-6">
              The job you're looking for doesn't exist or has been removed.
            </p>
            <Button asChild>
              <Link href="/jobs">Browse All Jobs</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <Button variant="ghost" asChild className="mb-2">
              <Link href="/jobs">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Jobs
              </Link>
            </Button>
            
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex flex-col md:flex-row md:items-start">
                {/* Job Title and Basic Info */}
                <div className="md:w-2/3 md:pr-8">
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-3 rounded mr-4 hidden md:flex items-center justify-center">
                      <Briefcase className="h-8 w-8 text-primary" />
                    </div>
                    
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <Badge variant="outline" className={getJobTypeBadgeColor(job.type)}>
                          {getFormattedJobType(job.type)}
                        </Badge>
                        <Badge variant="outline" className="bg-primary/10 text-primary">
                          {department?.name || "Department"}
                        </Badge>
                        <Badge variant="outline" className={deadlineStatus.className}>
                          {deadlineStatus.text}
                        </Badge>
                      </div>
                      
                      <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">{job.title}</h1>
                      
                      <div className="flex flex-wrap gap-4 mb-4 text-gray-600">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {job.location}
                        </div>
                        <div className="flex items-center">
                          <IndianRupee className="h-4 w-4 mr-1" />
                          {formatSalaryRange(job.salaryMin, job.salaryMax)}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          Posted on {formatDateShort(job.postedAt)}
                        </div>
                      </div>
                      
                      <div className="mb-4 text-gray-600 flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>
                          Application Deadline: <strong>{formatDateShort(job.deadline)}</strong> 
                          {!isDeadlinePassed && (
                            <span className="ml-1 text-sm">
                              ({daysRemaining} days remaining)
                            </span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="md:w-1/3 mt-6 md:mt-0 flex flex-col">
                  <div className="flex flex-col gap-3">
                    {isDeadlinePassed ? (
                      <Button disabled variant="destructive">
                        Application Closed
                      </Button>
                    ) : user ? (
                      hasApplied ? (
                        <Button disabled variant="outline" className="border-green-500 text-green-600">
                          <FileText className="h-4 w-4 mr-2" />
                          Already Applied
                        </Button>
                      ) : (
                        <Button asChild>
                          <Link href={`/apply/${job.id}`}>
                            <FileText className="h-4 w-4 mr-2" />
                            Apply Now
                          </Link>
                        </Button>
                      )
                    ) : (
                      <Button asChild>
                        <Link href={`/auth/login?redirect=/jobs/${job.id}`}>
                          <FileText className="h-4 w-4 mr-2" />
                          Login to Apply
                        </Link>
                      </Button>
                    )}
                    
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Bookmark className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 border border-gray-200 rounded-lg bg-gray-50">
                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Department Information</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {department?.description || "Department information not available"}
                    </p>
                    <Button variant="link" asChild className="p-0 h-auto">
                      <Link href={`/departments`}>
                        View All Departments
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Job Details Sections */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              {/* Job Description */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-xl font-bold text-primary mb-4">Job Description</h2>
                <div className="prose max-w-none text-gray-700">
                  <p className="whitespace-pre-line">{job.description}</p>
                </div>
              </div>
              
              {/* Requirements */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-xl font-bold text-primary mb-4">Requirements</h2>
                <div className="prose max-w-none text-gray-700">
                  <p className="whitespace-pre-line">{job.requirements}</p>
                </div>
              </div>
              
              {/* Skills */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-xl font-bold text-primary mb-4">Required Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {skillsList.map((skill: string, index: number) => (
                    <Badge key={index} variant="secondary" className="px-3 py-1 text-sm">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              
              {/* Application Instructions */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-xl font-bold text-primary mb-4">How to Apply</h2>
                <div className="prose max-w-none text-gray-700">
                  <p>
                    To apply for this position, you will need to submit an online application through 
                    our portal. Please have the following documents ready before you begin:
                  </p>
                  <ul className="mt-3 space-y-2">
                    <li className="flex items-start">
                      <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                        <span className="text-xs font-bold">1</span>
                      </div>
                      <span>Updated resume/CV in PDF, DOC, or DOCX format</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                        <span className="text-xs font-bold">2</span>
                      </div>
                      <span>Cover letter explaining your interest and qualifications</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                        <span className="text-xs font-bold">3</span>
                      </div>
                      <span>Educational qualifications and relevant certificates</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-0.5 mr-2">
                        <span className="text-xs font-bold">4</span>
                      </div>
                      <span>Any additional supporting documents mentioned in the requirements</span>
                    </li>
                  </ul>
                  
                  <div className="mt-6">
                    {isDeadlinePassed ? (
                      <Button disabled variant="destructive" className="w-full md:w-auto">
                        Application Closed
                      </Button>
                    ) : user ? (
                      hasApplied ? (
                        <Button disabled variant="outline" className="border-green-500 text-green-600 w-full md:w-auto">
                          <FileText className="h-4 w-4 mr-2" />
                          Already Applied
                        </Button>
                      ) : (
                        <Button asChild className="w-full md:w-auto">
                          <Link href={`/apply/${job.id}`}>
                            <FileText className="h-4 w-4 mr-2" />
                            Apply Now
                          </Link>
                        </Button>
                      )
                    ) : (
                      <Button asChild className="w-full md:w-auto">
                        <Link href={`/auth/login?redirect=/jobs/${job.id}`}>
                          <FileText className="h-4 w-4 mr-2" />
                          Login to Apply
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Sidebar */}
            <div className="space-y-6">
              {/* Job Summary */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-lg font-bold text-primary mb-4">Job Summary</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Job Type</h3>
                    <p className="font-medium text-gray-800">{getFormattedJobType(job.type)}</p>
                  </div>
                  <Separator />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Department</h3>
                    <p className="font-medium text-gray-800">{department?.name || "N/A"}</p>
                  </div>
                  <Separator />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Location</h3>
                    <p className="font-medium text-gray-800">{job.location}</p>
                  </div>
                  <Separator />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Salary Range</h3>
                    <p className="font-medium text-gray-800">{formatSalaryRange(job.salaryMin, job.salaryMax)}</p>
                  </div>
                  <Separator />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Application Deadline</h3>
                    <p className="font-medium text-gray-800">{formatDateShort(job.deadline)}</p>
                  </div>
                </div>
              </div>
              
              {/* Similar Jobs */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-lg font-bold text-primary mb-4">Similar Jobs</h2>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Explore other opportunities in the {department?.name || "same"} department:
                  </p>
                  <div className="space-y-2">
                    <Link href="/jobs" className="block p-3 border border-gray-200 rounded-md hover:bg-gray-50 transition">
                      <h3 className="font-medium text-gray-800 mb-1">View All Jobs</h3>
                      <p className="text-sm text-gray-600">Browse all available job opportunities</p>
                    </Link>
                    <Link href={`/jobs?departmentId=${job.departmentId}`} className="block p-3 border border-gray-200 rounded-md hover:bg-gray-50 transition">
                      <h3 className="font-medium text-gray-800 mb-1">Department Jobs</h3>
                      <p className="text-sm text-gray-600">View all jobs in {department?.name || "this department"}</p>
                    </Link>
                    <Link href={`/jobs?type=${job.type}`} className="block p-3 border border-gray-200 rounded-md hover:bg-gray-50 transition">
                      <h3 className="font-medium text-gray-800 mb-1">{getFormattedJobType(job.type)} Jobs</h3>
                      <p className="text-sm text-gray-600">Browse {getFormattedJobType(job.type).toLowerCase()} opportunities</p>
                    </Link>
                  </div>
                </div>
              </div>
              
              {/* Help Box */}
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h2 className="text-lg font-bold text-primary mb-4">Need Assistance?</h2>
                <p className="text-sm text-gray-600 mb-4">
                  If you have any questions about this job or the application process, please contact our support team.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 text-primary mr-2" />
                    <span className="text-gray-700">Secretariat, Jaipur, Rajasthan</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 text-primary mr-2" />
                    <span className="text-gray-700">Monday to Friday, 9 AM - 5 PM</span>
                  </div>
                  <div className="flex items-center">
                    <Building className="h-4 w-4 text-primary mr-2" />
                    <span className="text-gray-700">Email: careers@rajasthan.gov.in</span>
                  </div>
                  <div className="flex items-center">
                    <GraduationCap className="h-4 w-4 text-primary mr-2" />
                    <span className="text-gray-700">Helpline: 1800-XXX-XXXX</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default JobDetails;

function getJobTypeBadgeColor(type: string): string {
  switch (type) {
    case "FULL_TIME":
      return "bg-blue-100 text-blue-800";
    case "PART_TIME":
      return "bg-green-100 text-green-800";
    case "CONTRACT":
      return "bg-orange-100 text-orange-800";
    case "INTERNSHIP":
      return "bg-purple-100 text-purple-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
}
