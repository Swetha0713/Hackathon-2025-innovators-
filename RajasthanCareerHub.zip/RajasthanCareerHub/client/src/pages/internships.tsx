import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import JobCard from "@/components/ui/job-card";
import JobFilters from "@/components/ui/job-filters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search,
  Briefcase,
  BookOpen,
  Loader2 
} from "lucide-react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const Internships = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    jobTypes: ["INTERNSHIP"],
    departments: [],
    experienceLevels: [],
    locations: [],
    salaryRange: [10000, 100000],
  });
  const internshipsPerPage = 5;

  // Fetch departments
  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
  });

  // Fetch all jobs (will filter to internships)
  const { data: allJobs, isLoading } = useQuery({
    queryKey: ["/api/jobs", searchQuery],
    queryFn: async ({ queryKey }) => {
      const query = queryKey[1] as string;
      let url = `/api/jobs?type=INTERNSHIP`;
      if (query) url += `&query=${query}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch internships");
      return res.json();
    },
  });

  // Filter internships based on selected filters (other than job type)
  const filteredInternships = allJobs ? allJobs.filter((job: any) => {
    // Always filter for type = INTERNSHIP
    if (job.type !== "INTERNSHIP") return false;
    
    // Filter by department
    if (
      filters.departments.length > 0 &&
      !filters.departments.includes(job.departmentId.toString())
    ) {
      return false;
    }
    
    // Filter by location
    if (filters.locations.length > 0) {
      const jobLocations = job.location.split(", ");
      const hasMatchingLocation = jobLocations.some((loc: string) =>
        filters.locations.includes(loc)
      );
      if (!hasMatchingLocation) return false;
    }
    
    // Filter by salary range
    const [minSalary, maxSalary] = filters.salaryRange;
    if (job.salaryMin && job.salaryMin > maxSalary) return false;
    if (job.salaryMax && job.salaryMax < minSalary) return false;
    
    return true;
  }) : [];

  // Pagination
  const totalPages = Math.ceil((filteredInternships?.length || 0) / internshipsPerPage);
  const currentInternships = filteredInternships?.slice(
    (currentPage - 1) * internshipsPerPage,
    currentPage * internshipsPerPage
  );

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
  };

  // Handle filter changes
  const handleFilterChange = (newFilters: any) => {
    // Always include INTERNSHIP type in filters
    setFilters({
      ...newFilters,
      jobTypes: ["INTERNSHIP"]
    });
    setCurrentPage(1);
  };

  // Handle pagination
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Page Header */}
      <section className="bg-primary/10 py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Internship Opportunities</h1>
          <p className="text-gray-600">
            Find and apply for government internships in technical and educational departments
          </p>
          
          <form 
            className="mt-4 flex flex-col md:flex-row gap-3 max-w-3xl" 
            onSubmit={handleSearch}
          >
            <Input
              type="text"
              placeholder="Search internships, keywords, skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </form>
        </div>
      </section>
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Filters Sidebar */}
            <div className="md:w-1/4">
              <JobFilters
                onFilterChange={handleFilterChange}
                initialFilters={filters}
              />
            </div>
            
            {/* Internships Listing */}
            <div className="md:w-3/4">
              <div className="bg-white rounded-lg p-5 shadow-md mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-primary">
                    {isLoading
                      ? "Loading internships..."
                      : `${filteredInternships?.length || 0} Internship Opportunities`}
                  </h2>
                  <div className="flex items-center bg-primary/10 rounded-lg px-3 py-1.5 text-sm text-primary">
                    <BookOpen className="h-4 w-4 mr-2" />
                    <span>Internships Only</span>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredInternships && filteredInternships.length > 0 ? (
                  <>
                    <div className="space-y-4">
                      {currentInternships.map((job: any) => (
                        <JobCard
                          key={job.id}
                          job={job}
                          departmentName={
                            departments?.find((d: any) => d.id === job.departmentId)?.name || "Department"
                          }
                        />
                      ))}
                    </div>
                    
                    {totalPages > 1 && (
                      <Pagination className="mt-6">
                        <PaginationContent>
                          <PaginationItem>
                            <PaginationPrevious 
                              onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                              className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                          
                          {[...Array(totalPages)].map((_, i) => (
                            <PaginationItem key={i + 1}>
                              <PaginationLink
                                onClick={() => handlePageChange(i + 1)}
                                isActive={currentPage === i + 1}
                              >
                                {i + 1}
                              </PaginationLink>
                            </PaginationItem>
                          ))}
                          
                          <PaginationItem>
                            <PaginationNext
                              onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                              className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                        </PaginationContent>
                      </Pagination>
                    )}
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="bg-gray-50 rounded-lg p-8">
                      <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">No internships found</h3>
                      <p className="text-gray-500 mb-4">
                        There are currently no internship opportunities matching your criteria.
                      </p>
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setFilters({
                            jobTypes: ["INTERNSHIP"],
                            departments: [],
                            experienceLevels: [],
                            locations: [],
                            salaryRange: [10000, 100000],
                          });
                          setSearchQuery("");
                        }}
                      >
                        Reset Filters
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Internship Information */}
              <div className="bg-white rounded-lg p-5 shadow-md">
                <h3 className="text-xl font-bold text-primary mb-4">About Government Internships</h3>
                <div className="space-y-4 text-gray-700">
                  <p>
                    Internships with the Government of Rajasthan provide valuable opportunities for students
                    and recent graduates to gain practical work experience in public service.
                  </p>
                  <p>
                    Most internships are 3-6 months in duration and offer a structured learning experience
                    with mentorship from experienced government professionals.
                  </p>
                  <p>
                    Interns receive a fixed stipend and may be eligible for a certificate of completion
                    and recommendation letter upon successful completion of their internship program.
                  </p>
                  <p>
                    Many former interns have gone on to secure permanent positions within government
                    departments, making this an excellent starting point for your career in public service.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Internships;
