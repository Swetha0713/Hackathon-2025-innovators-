import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import JobCard from "@/components/job/JobCard";
import DepartmentCard from "@/components/department/DepartmentCard";
import type { Job, Department } from "@shared/schema";

const Home = () => {
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: () => fetch('/api/departments').then(res => res.json()),
  });

  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => fetch('/api/jobs').then(res => res.json()),
  });

  // Stats
  const stats = {
    jobs: jobs?.length || 0,
    departments: departments?.length || 0,
    internships: jobs?.filter((job: Job) => job.jobType === "INTERNSHIP").length || 0
  };

  // Featured departments (first 6)
  const featuredDepartments = departments?.slice(0, 6) || [];

  // Recent jobs (first 4)
  const recentJobs = jobs?.slice(0, 4) || [];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-12 sm:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="font-heading font-bold text-3xl sm:text-4xl md:text-5xl mb-4">
              Build Your Career with Rajasthan Government
            </h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8">
              Discover opportunities in technical and educational sectors
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/jobs">
                <Button className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-6 h-auto text-lg">
                  Find Jobs
                </Button>
              </Link>
              <Link href="/internships">
                <Button variant="outline" className="bg-white hover:bg-gray-100 text-primary border-white px-6 py-6 h-auto text-lg">
                  Explore Internships
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <Card className="bg-gray-50">
              <CardContent className="p-6">
                <p className="text-4xl font-bold text-primary mb-2">{stats.jobs}+</p>
                <p className="text-gray-600">Open Job Positions</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-50">
              <CardContent className="p-6">
                <p className="text-4xl font-bold text-primary mb-2">{stats.departments}</p>
                <p className="text-gray-600">Government Departments</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-50">
              <CardContent className="p-6">
                <p className="text-4xl font-bold text-primary mb-2">{stats.internships}+</p>
                <p className="text-gray-600">Internship Opportunities</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Recent Jobs Section */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-heading font-bold text-2xl text-gray-800">Latest Opportunities</h2>
            <Link href="/jobs">
              <a className="text-primary hover:text-primary-dark font-medium inline-flex items-center">
                <span>View All Jobs</span>
                <ChevronRight className="ml-1 h-5 w-5" />
              </a>
            </Link>
          </div>
          
          <div className="mb-8">
            {isLoadingJobs ? (
              <div className="grid grid-cols-1 gap-4">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-6 bg-gray-200 rounded mb-2 w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-4 w-1/2"></div>
                      <div className="flex gap-2 mb-4">
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                      </div>
                      <div className="h-10 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : recentJobs.length > 0 ? (
              recentJobs.map((job: Job) => (
                <JobCard key={job.id} job={job} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No jobs available at the moment. Please check back later.</p>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="flex justify-center">
            <Link href="/jobs">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary-50">
                Load More Opportunities
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Departments Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="font-heading font-bold text-3xl text-gray-800 mb-3">Browse by Department</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore career opportunities across various technical and educational departments of the Rajasthan Government
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoadingDepartments ? (
              [...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 rounded-full bg-gray-200 mr-4"></div>
                      <div className="h-5 bg-gray-200 rounded w-2/3"></div>
                    </div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4 mt-4"></div>
                  </CardContent>
                </Card>
              ))
            ) : featuredDepartments.length > 0 ? (
              featuredDepartments.map((department: Department) => (
                <DepartmentCard key={department.id} department={department} />
              ))
            ) : (
              <Card className="col-span-full">
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No departments available at the moment.</p>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="text-center mt-10">
            <Link href="/departments">
              <a className="text-primary hover:text-primary-dark font-medium inline-flex items-center">
                <span>View All Departments</span>
                <ChevronRight className="ml-1 h-5 w-5" />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Application Process Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="font-heading font-bold text-3xl text-gray-800 mb-3">How to Apply</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Follow these simple steps to apply for government positions and track your application status
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">1</div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Create Account</h3>
              <p className="text-gray-600">Register with your email and create a profile with your qualifications</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">2</div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Find Opportunities</h3>
              <p className="text-gray-600">Search and filter through available positions in different departments</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">3</div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Submit Application</h3>
              <p className="text-gray-600">Complete the application form and upload required documents</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">4</div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Track Status</h3>
              <p className="text-gray-600">Monitor your application status and receive notifications about updates</p>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Link href="/register">
              <Button className="bg-amber-500 hover:bg-amber-600 text-white">Register Now</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
