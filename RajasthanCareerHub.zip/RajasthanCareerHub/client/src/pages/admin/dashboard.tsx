import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartBarStacked,
  BriefcaseBusiness,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  Loader2,
  Users,
  GraduationCap,
  Building,
  FileText,
  Package,
  ArrowUpRight,
  Mailbox,
  AlertTriangle,
} from "lucide-react";

const AdminDashboard = () => {
  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to fetch user");
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get all jobs
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/applications"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch applications");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async ({ queryKey }) => {
      // This endpoint doesn't exist in our API, but we can simulate it
      // In a real app, this would be fetched from the server
      return { length: 10 }; // Mock data
    },
    enabled: !!user?.isAdmin,
  });

  const isLoading = isLoadingUser || isLoadingJobs || isLoadingApplications || isLoadingDepartments || isLoadingUsers;

  // Check if user is not admin
  if (!isLoadingUser && (!user || !user.isAdmin)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-6">
              You do not have permission to access the admin dashboard.
            </p>
            <Button asChild>
              <Link href="/">Return to Home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  // Calculate statistics
  const activeJobs = jobs?.filter((job: any) => job.isActive).length || 0;
  const inactiveJobs = (jobs?.length || 0) - activeJobs;
  const totalApplications = applications?.length || 0;
  const pendingApplications = applications?.filter((app: any) => app.status === "PENDING").length || 0;
  const shortlistedApplications = applications?.filter((app: any) => app.status === "SHORTLISTED").length || 0;
  const interviewApplications = applications?.filter((app: any) => app.status === "INTERVIEW").length || 0;
  const selectedApplications = applications?.filter((app: any) => app.status === "SELECTED").length || 0;
  const rejectedApplications = applications?.filter((app: any) => app.status === "REJECTED").length || 0;
  const internships = jobs?.filter((job: any) => job.type === "INTERNSHIP").length || 0;
  const fullTimeJobs = jobs?.filter((job: any) => job.type === "FULL_TIME").length || 0;
  const partTimeJobs = jobs?.filter((job: any) => job.type === "PART_TIME").length || 0;
  const contractJobs = jobs?.filter((job: any) => job.type === "CONTRACT").length || 0;

  // Get latest applications
  const latestApplications = applications
    ? [...applications]
        .sort((a: any, b: any) => new Date(b.appliedAt).getTime() - new Date(a.appliedAt).getTime())
        .slice(0, 5)
    : [];

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Admin Dashboard</h1>
              <p className="text-gray-600">
                Overview of jobs, applications, and portal statistics
              </p>
            </div>
            <div className="flex space-x-3">
              <Button asChild>
                <Link href="/admin/jobs/new">
                  <BriefcaseBusiness className="h-4 w-4 mr-2" />
                  Post New Job
                </Link>
              </Button>
            </div>
          </div>
          
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-2xl font-bold">{jobs?.length || 0}</div>
                    <p className="text-xs text-gray-500">
                      <span className="text-green-500 font-medium">{activeJobs} active</span>
                      {inactiveJobs > 0 && (
                        <span className="ml-1 text-gray-500">• {inactiveJobs} inactive</span>
                      )}
                    </p>
                  </div>
                  <BriefcaseBusiness className="h-8 w-8 text-primary/60" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-2xl font-bold">{totalApplications}</div>
                    <p className="text-xs text-gray-500">
                      <span className="text-yellow-500 font-medium">{pendingApplications} pending</span>
                      {selectedApplications > 0 && (
                        <span className="ml-1 text-green-500">• {selectedApplications} selected</span>
                      )}
                    </p>
                  </div>
                  <ClipboardList className="h-8 w-8 text-primary/60" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Departments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-2xl font-bold">{departments?.length || 0}</div>
                    <p className="text-xs text-gray-500">
                      Across technical and education sectors
                    </p>
                  </div>
                  <Building className="h-8 w-8 text-primary/60" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Registered Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-2xl font-bold">{users?.length || 0}</div>
                    <p className="text-xs text-gray-500">
                      Potential job applicants
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-primary/60" />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Job Distribution and Application Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Job Type Distribution</CardTitle>
                <CardDescription>
                  Breakdown of jobs by employment type
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-16 text-sm font-medium">Full Time</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-blue-500 rounded-full"
                          style={{
                            width: `${jobs?.length ? (fullTimeJobs / jobs.length) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{fullTimeJobs}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-16 text-sm font-medium">Part Time</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-green-500 rounded-full"
                          style={{
                            width: `${jobs?.length ? (partTimeJobs / jobs.length) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{partTimeJobs}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-16 text-sm font-medium">Contract</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-orange-500 rounded-full"
                          style={{
                            width: `${jobs?.length ? (contractJobs / jobs.length) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{contractJobs}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-16 text-sm font-medium">Internship</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-purple-500 rounded-full"
                          style={{
                            width: `${jobs?.length ? (internships / jobs.length) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{internships}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Application Status</CardTitle>
                <CardDescription>
                  Overview of application statuses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-20 text-sm font-medium">Pending</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-yellow-500 rounded-full"
                          style={{
                            width: `${totalApplications ? (pendingApplications / totalApplications) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{pendingApplications}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-20 text-sm font-medium">Shortlisted</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-blue-500 rounded-full"
                          style={{
                            width: `${totalApplications ? (shortlistedApplications / totalApplications) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{shortlistedApplications}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-20 text-sm font-medium">Interview</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-indigo-500 rounded-full"
                          style={{
                            width: `${totalApplications ? (interviewApplications / totalApplications) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{interviewApplications}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-20 text-sm font-medium">Selected</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-green-500 rounded-full"
                          style={{
                            width: `${totalApplications ? (selectedApplications / totalApplications) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{selectedApplications}</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-20 text-sm font-medium">Rejected</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-3 bg-red-500 rounded-full"
                          style={{
                            width: `${totalApplications ? (rejectedApplications / totalApplications) * 100 : 0}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <div className="w-10 text-right text-sm font-medium">{rejectedApplications}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Latest Applications and Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Recent Applications</CardTitle>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href="/admin/applications">
                        View All
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {latestApplications.length > 0 ? (
                    <div className="space-y-4">
                      {latestApplications.map((application: any) => {
                        const job = jobs?.find((j: any) => j.id === application.jobId);
                        
                        return (
                          <div key={application.id} className="flex items-center p-3 border border-gray-100 rounded-lg hover:bg-gray-50">
                            <div className="mr-4 p-2 bg-primary/10 rounded-full">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {job?.title || "Job unavailable"}
                              </p>
                              <p className="text-xs text-gray-500">
                                Applied {new Date(application.appliedAt).toLocaleDateString()} • Status: 
                                <span className={`ml-1 font-medium
                                  ${application.status === "PENDING" ? "text-yellow-600" : ""}
                                  ${application.status === "SHORTLISTED" ? "text-blue-600" : ""}
                                  ${application.status === "INTERVIEW" ? "text-indigo-600" : ""}
                                  ${application.status === "SELECTED" ? "text-green-600" : ""}
                                  ${application.status === "REJECTED" ? "text-red-600" : ""}
                                `}>
                                  {application.status.charAt(0) + application.status.slice(1).toLowerCase()}
                                </span>
                              </p>
                            </div>
                            <Button variant="ghost" size="sm" asChild>
                              <Link href={`/admin/applications?id=${application.id}`}>
                                Review
                              </Link>
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-gray-500">No applications yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/admin/jobs/new">
                        <BriefcaseBusiness className="h-4 w-4 mr-2" />
                        Post New Job
                      </Link>
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/admin/jobs">
                        <Package className="h-4 w-4 mr-2" />
                        Manage Jobs
                      </Link>
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/admin/applications">
                        <ClipboardList className="h-4 w-4 mr-2" />
                        Review Applications
                      </Link>
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start" asChild disabled>
                      <Link href="#">
                        <ChartBarStacked className="h-4 w-4 mr-2" />
                        Analytics Dashboard
                      </Link>
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start" asChild disabled>
                      <Link href="#">
                        <Mailbox className="h-4 w-4 mr-2" />
                        Message Applicants
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>System Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm font-medium">API</span>
                      </div>
                      <span className="text-xs text-green-600">Operational</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm font-medium">Database</span>
                      </div>
                      <span className="text-xs text-green-600">Operational</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm font-medium">File Storage</span>
                      </div>
                      <span className="text-xs text-green-600">Operational</span>
                    </div>
                    
                    <div className="pt-2 text-xs text-right">
                      <span className="text-gray-500">Last updated: {new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AdminDashboard;
