import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertTriangle,
  BriefcaseBusiness,
  Edit,
  Loader2,
  MoreHorizontal,
  PlusCircle,
  Search,
  Trash2,
  Eye,
  XCircle,
  CheckCircle2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  formatDateShort,
  getFormattedJobType,
  getDaysRemaining,
} from "@/lib/utils";

const ManageJobs = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [showInactive, setShowInactive] = useState(false);
  const [deleteJobId, setDeleteJobId] = useState<number | null>(null);
  const [confirmDeleteDialog, setConfirmDeleteDialog] = useState(false);

  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to fetch user");
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get all jobs
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Delete job mutation
  const deleteJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      await apiRequest("DELETE", `/api/jobs/${jobId}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Job deleted",
        description: "The job posting has been successfully deleted",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setConfirmDeleteDialog(false);
      setDeleteJobId(null);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete job",
        description: error instanceof Error ? error.message : "An error occurred",
      });
    },
  });

  // Toggle job active status mutation
  const toggleJobStatusMutation = useMutation({
    mutationFn: async ({ jobId, isActive }: { jobId: number; isActive: boolean }) => {
      await apiRequest("PUT", `/api/jobs/${jobId}`, { isActive });
    },
    onSuccess: () => {
      toast({
        title: "Job status updated",
        description: "The job status has been successfully updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update job status",
        description: error instanceof Error ? error.message : "An error occurred",
      });
    },
  });

  // Filter jobs based on search query and active status
  const filteredJobs = jobs
    ? jobs.filter((job: any) => {
        // Filter by search query
        const matchesSearch =
          job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.type.toLowerCase().includes(searchQuery.toLowerCase());

        // Filter by active status if showInactive is false
        const matchesStatus = showInactive ? true : job.isActive;

        return matchesSearch && matchesStatus;
      })
    : [];

  // Sort jobs by posted date (newest first)
  const sortedJobs = [...(filteredJobs || [])].sort(
    (a: any, b: any) => new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime()
  );

  // Get department name by id
  const getDepartmentName = (departmentId: number) => {
    const department = departments?.find((d: any) => d.id === departmentId);
    return department ? department.name : "Unknown Department";
  };

  // Handle job deletion
  const handleDeleteJob = (jobId: number) => {
    setDeleteJobId(jobId);
    setConfirmDeleteDialog(true);
  };

  // Confirm job deletion
  const confirmDeleteJob = () => {
    if (deleteJobId) {
      deleteJobMutation.mutate(deleteJobId);
    }
  };

  // Handle job status toggle
  const handleToggleJobStatus = (jobId: number, currentStatus: boolean) => {
    toggleJobStatusMutation.mutate({ jobId, isActive: !currentStatus });
  };

  // Loading state
  const isLoading = isLoadingUser || isLoadingJobs || isLoadingDepartments;

  // Check if user is not admin
  if (!isLoadingUser && (!user || !user.isAdmin)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-6">
              You do not have permission to access this page.
            </p>
            <Button asChild>
              <Link href="/">Return to Home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />

      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">Manage Jobs</h1>
              <p className="text-gray-600">
                View, edit, and manage all job and internship postings
              </p>
            </div>
            <div className="flex space-x-3">
              <Button asChild>
                <Link href="/admin/jobs/new">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Post New Job
                </Link>
              </Button>
            </div>
          </div>

          {/* Search and Filter Bar */}
          <div className="mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4 items-center">
                  <div className="relative w-full md:w-1/2">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      type="search"
                      placeholder="Search jobs by title, location, or description..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center space-x-2 ml-auto">
                    <Switch
                      id="show-inactive"
                      checked={showInactive}
                      onCheckedChange={setShowInactive}
                    />
                    <Label htmlFor="show-inactive">Show inactive jobs</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Jobs Table */}
          <Card>
            <CardHeader>
              <CardTitle>All Job Postings</CardTitle>
              <CardDescription>
                {sortedJobs?.length || 0} job{sortedJobs?.length !== 1 && "s"} found
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : sortedJobs?.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[300px]">Job Title</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Posted</TableHead>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedJobs.map((job: any) => {
                        const daysRemaining = getDaysRemaining(job.deadline);
                        const isExpired = daysRemaining < 0;

                        return (
                          <TableRow key={job.id}>
                            <TableCell className="font-medium">{job.title}</TableCell>
                            <TableCell>{getDepartmentName(job.departmentId)}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{getFormattedJobType(job.type)}</Badge>
                            </TableCell>
                            <TableCell>{job.location}</TableCell>
                            <TableCell>{formatDateShort(job.postedAt)}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span>{formatDateShort(job.deadline)}</span>
                                {isExpired ? (
                                  <span className="text-xs text-red-500">Expired</span>
                                ) : (
                                  <span className="text-xs text-gray-500">
                                    {daysRemaining} days left
                                  </span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <Switch
                                  id={`job-status-${job.id}`}
                                  checked={job.isActive}
                                  onCheckedChange={() =>
                                    handleToggleJobStatus(job.id, job.isActive)
                                  }
                                  disabled={
                                    toggleJobStatusMutation.isPending ||
                                    isExpired
                                  }
                                />
                                <span
                                  className={
                                    job.isActive ? "text-green-600" : "text-gray-500"
                                  }
                                >
                                  {job.isActive ? "Active" : "Inactive"}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Open menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem asChild>
                                    <Link href={`/jobs/${job.id}`}>
                                      <Eye className="h-4 w-4 mr-2" />
                                      View Job
                                    </Link>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem asChild>
                                    <Link href={`/admin/jobs/${job.id}`}>
                                      <Edit className="h-4 w-4 mr-2" />
                                      Edit Job
                                    </Link>
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => handleDeleteJob(job.id)}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete Job
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <BriefcaseBusiness className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">No Jobs Found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchQuery
                      ? "No jobs matching your search criteria"
                      : "There are no jobs available at the moment."}
                  </p>
                  <Button asChild>
                    <Link href="/admin/jobs/new">
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Post New Job
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={confirmDeleteDialog} onOpenChange={setConfirmDeleteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this job posting? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                This will permanently remove the job posting and all associated applications.
              </AlertDescription>
            </Alert>
          </div>
          <DialogFooter className="flex space-x-2 sm:justify-end">
            <Button
              variant="outline"
              onClick={() => setConfirmDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDeleteJob}
              disabled={deleteJobMutation.isPending}
            >
              {deleteJobMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Job
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default ManageJobs;
