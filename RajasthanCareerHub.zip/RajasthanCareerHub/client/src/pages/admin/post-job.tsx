import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useRoute, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertTriangle,
  CalendarIcon,
  Check,
  ChevronLeft,
  Loader2,
  Save,
  CheckCircle2,
} from "lucide-react";
import { insertJobSchema } from "@shared/schema";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

// Extend the job schema for the form
const formSchema = insertJobSchema.extend({
  deadlineDate: z.date({
    required_error: "Please select a deadline date",
  }),
}).omit({ deadline: true });

type FormData = z.infer<typeof formSchema>;

const PostJob = () => {
  const [match, params] = useRoute('/admin/jobs/:id');
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [error, setError] = useState("");
  const isEditMode = !!params?.id;

  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to fetch user");
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get all departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get job details if in edit mode
  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${params?.id}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch job details");
      return res.json();
    },
    enabled: !!params?.id && !!user?.isAdmin,
  });

  // Post/Edit job mutation
  const jobMutation = useMutation({
    mutationFn: async (data: any) => {
      if (isEditMode) {
        return apiRequest("PUT", `/api/jobs/${params?.id}`, data);
      } else {
        return apiRequest("POST", "/api/jobs", data);
      }
    },
    onSuccess: () => {
      setSubmitSuccess(true);
      toast({
        title: isEditMode ? "Job Updated" : "Job Posted",
        description: isEditMode
          ? "The job posting has been successfully updated"
          : "The job posting has been successfully created",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate("/admin/jobs");
      }, 2000);
    },
    onError: (error) => {
      setError(error instanceof Error ? error.message : "An error occurred");
      toast({
        variant: "destructive",
        title: isEditMode ? "Failed to update job" : "Failed to post job",
        description: error instanceof Error ? error.message : "An error occurred",
      });
    },
  });

  // Form setup
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      departmentId: "",
      location: "",
      type: "",
      salaryMin: undefined,
      salaryMax: undefined,
      description: "",
      requirements: "",
      skills: "",
      deadlineDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      isActive: true,
    },
  });

  // Populate form with existing job data if in edit mode
  useEffect(() => {
    if (job && isEditMode) {
      form.reset({
        title: job.title,
        departmentId: job.departmentId.toString(),
        location: job.location,
        type: job.type,
        salaryMin: job.salaryMin,
        salaryMax: job.salaryMax,
        description: job.description,
        requirements: job.requirements,
        skills: job.skills,
        deadlineDate: new Date(job.deadline),
        isActive: job.isActive,
      });
    }
  }, [job, isEditMode, form]);

  // Handle form submission
  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setError("");

    try {
      // Convert form data to API format
      const jobData = {
        ...data,
        departmentId: parseInt(data.departmentId),
        deadline: data.deadlineDate.toISOString(),
        adminId: user.id,
      };

      // Remove the deadlineDate field which is used only for the form
      const { deadlineDate, ...apiData } = jobData;

      await jobMutation.mutateAsync(apiData);
    } catch (error) {
      console.error("Job submission error:", error);
      setError(error instanceof Error ? error.message : "Failed to submit job posting");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading state
  const isLoading = isLoadingUser || isLoadingDepartments || (isEditMode && isLoadingJob);

  // Check if user is not admin
  if (!isLoadingUser && (!user || !user.isAdmin)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-6">
              You do not have permission to access this page.
            </p>
            <Button asChild>
              <Link href="/">Return to Home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Success state
  if (submitSuccess) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              {isEditMode ? "Job Updated Successfully" : "Job Posted Successfully"}
            </h1>
            <p className="text-gray-600 mb-6">
              {isEditMode
                ? "Your job posting has been updated and is now live."
                : "Your job posting has been created and is now live."}
            </p>
            <div className="flex space-x-4 justify-center">
              <Button asChild variant="outline">
                <Link href="/admin/jobs">View All Jobs</Link>
              </Button>
              {!isEditMode && (
                <Button asChild>
                  <Link href="/admin/jobs/new">Post Another Job</Link>
                </Button>
              )}
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />

      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <Button variant="ghost" asChild className="mb-2">
              <Link href="/admin/jobs">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Jobs
              </Link>
            </Button>

            <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">
              {isEditMode ? "Edit Job Posting" : "Post New Job"}
            </h1>
            <p className="text-gray-600">
              {isEditMode
                ? "Update the details of an existing job posting"
                : "Create a new job or internship opportunity"}
            </p>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Job Form */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Job Details</CardTitle>
                  <CardDescription>
                    Enter the details of the job position
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Job Title</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="e.g., Senior Software Developer"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              The title of the job position
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="departmentId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Department</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select department" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {departments?.map((dept: any) => (
                                    <SelectItem
                                      key={dept.id}
                                      value={dept.id.toString()}
                                    >
                                      {dept.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Job Type</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select job type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="FULL_TIME">Full Time</SelectItem>
                                  <SelectItem value="PART_TIME">Part Time</SelectItem>
                                  <SelectItem value="CONTRACT">Contract</SelectItem>
                                  <SelectItem value="INTERNSHIP">Internship</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Jaipur, Rajasthan" {...field} />
                            </FormControl>
                            <FormDescription>
                              City or multiple cities where the job is located (comma-separated)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="salaryMin"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Minimum Salary (₹)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  placeholder="e.g., 50000"
                                  {...field}
                                  value={field.value || ""}
                                  onChange={e => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="salaryMax"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Maximum Salary (₹)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  placeholder="e.g., 80000"
                                  {...field}
                                  value={field.value || ""}
                                  onChange={e => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Job Description</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Describe the job responsibilities and expectations..."
                                className="min-h-32"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Provide a detailed description of the job role and responsibilities
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="requirements"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Requirements</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="List the qualifications, experience, and skills required..."
                                className="min-h-32"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Specify qualifications, experience, and education requirements
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="skills"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Required Skills</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="e.g., Java, Spring Boot, SQL"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Comma-separated list of skills required for the position
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="deadlineDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Application Deadline</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "w-full pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) =>
                                    date < new Date(new Date().setHours(0, 0, 0, 0))
                                  }
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              The last date for submitting applications
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="isActive"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Active Status</FormLabel>
                              <FormDescription>
                                Job will be visible to applicants if active
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button type="submit" disabled={isSubmitting}>
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              {isEditMode ? "Updating..." : "Posting..."}
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              {isEditMode ? "Update Job" : "Post Job"}
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>

            {/* Guidelines */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Posting Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border bg-card p-3">
                      <h3 className="font-medium text-sm mb-2 flex items-center">
                        <Check className="h-4 w-4 mr-1 text-green-600" />
                        Job Title
                      </h3>
                      <p className="text-sm text-gray-600">
                        Use clear and specific titles that accurately describe the position.
                      </p>
                    </div>
                    
                    <div className="rounded-lg border bg-card p-3">
                      <h3 className="font-medium text-sm mb-2 flex items-center">
                        <Check className="h-4 w-4 mr-1 text-green-600" />
                        Description
                      </h3>
                      <p className="text-sm text-gray-600">
                        Provide detailed information about the role, responsibilities, and work environment.
                      </p>
                    </div>
                    
                    <div className="rounded-lg border bg-card p-3">
                      <h3 className="font-medium text-sm mb-2 flex items-center">
                        <Check className="h-4 w-4 mr-1 text-green-600" />
                        Requirements
                      </h3>
                      <p className="text-sm text-gray-600">
                        Clearly state required qualifications, experience, education, and certifications.
                      </p>
                    </div>
                    
                    <div className="rounded-lg border bg-card p-3">
                      <h3 className="font-medium text-sm mb-2 flex items-center">
                        <Check className="h-4 w-4 mr-1 text-green-600" />
                        Skills
                      </h3>
                      <p className="text-sm text-gray-600">
                        List specific skills required, separating each with a comma (e.g., "Java, SQL, Project Management").
                      </p>
                    </div>
                    
                    <div className="rounded-lg border bg-card p-3">
                      <h3 className="font-medium text-sm mb-2 flex items-center">
                        <Check className="h-4 w-4 mr-1 text-green-600" />
                        Salary Range
                      </h3>
                      <p className="text-sm text-gray-600">
                        Provide a realistic salary range based on the job level and responsibilities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PostJob;
