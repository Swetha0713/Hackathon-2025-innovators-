import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, LineChart, ResponsiveContainer, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import {
  Briefcase,
  Users,
  FileText,
  Building,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  UserCheck
} from "lucide-react";
import { format, subDays } from "date-fns";

const AdminDashboard = () => {
  const [_, navigate] = useLocation();
  
  // Check if user is logged in and is admin
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 401) {
          // Redirect to login if unauthorized
          navigate('/login?redirect=/admin');
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      return res.json();
    }),
  });

  // Get all jobs
  const { data: jobs } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => fetch('/api/jobs', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch jobs');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Get all applications
  const { data: applications } = useQuery({
    queryKey: ['/api/applications'],
    queryFn: () => fetch('/api/applications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch applications');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Get departments
  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: () => fetch('/api/departments', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch departments');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Verify admin status
  if (isLoadingUser) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="animate-pulse">
          <CardContent className="p-8">
            <div className="h-8 bg-gray-200 rounded mb-4 w-1/2"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-amber-600 mb-4">Please log in to access the admin dashboard.</p>
            <Button onClick={() => navigate('/login?redirect=/admin')}>
              Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user.isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-red-600 mb-4">You don't have access to the admin dashboard.</p>
            <Button onClick={() => navigate('/')}>
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate statistics
  const totalJobs = jobs?.length || 0;
  const activeJobs = jobs?.filter((job: any) => job.isActive && new Date(job.deadline) >= new Date()).length || 0;
  const totalApplications = applications?.length || 0;
  const pendingReview = applications?.filter((app: any) => app.status === 'SUBMITTED').length || 0;
  const shortlisted = applications?.filter((app: any) => app.status === 'SHORTLISTED').length || 0;
  const selected = applications?.filter((app: any) => app.status === 'SELECTED').length || 0;
  const rejected = applications?.filter((app: any) => app.status === 'REJECTED').length || 0;
  const totalDepartments = departments?.length || 0;

  // Prepare chart data
  const getLast7Days = () => {
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      result.push({
        date: format(date, 'MM/dd'),
        fullDate: date
      });
    }
    return result;
  };

  const last7Days = getLast7Days();

  const applicationChartData = last7Days.map(day => {
    const count = applications?.filter((app: any) => {
      const appDate = new Date(app.submittedAt);
      return appDate.getDate() === day.fullDate.getDate() &&
        appDate.getMonth() === day.fullDate.getMonth() &&
        appDate.getFullYear() === day.fullDate.getFullYear();
    }).length || 0;
    
    return {
      date: day.date,
      applications: count
    };
  });

  const statusDistribution = [
    { name: 'Submitted', value: pendingReview },
    { name: 'Under Review', value: applications?.filter((app: any) => app.status === 'UNDER_REVIEW').length || 0 },
    { name: 'Shortlisted', value: shortlisted },
    { name: 'Interview', value: applications?.filter((app: any) => app.status === 'INTERVIEW_SCHEDULED').length || 0 },
    { name: 'Selected', value: selected },
    { name: 'Rejected', value: rejected }
  ];

  const departmentJobsData = departments?.map((dept: any) => ({
    name: dept.name.length > 15 ? dept.name.substring(0, 15) + '...' : dept.name,
    jobs: jobs?.filter((job: any) => job.departmentId === dept.id).length || 0,
    applications: applications?.filter((app: any) => {
      const job = jobs?.find((j: any) => j.id === app.jobId);
      return job?.departmentId === dept.id;
    }).length || 0
  })) || [];

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => navigate('/admin/jobs')}>
              Manage Jobs
            </Button>
            <Button variant="outline" onClick={() => navigate('/admin/applications')}>
              Manage Applications
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Jobs</p>
                <h3 className="text-3xl font-bold">{totalJobs}</h3>
                <p className="text-sm text-green-600">{activeJobs} active</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Applications</p>
                <h3 className="text-3xl font-bold">{totalApplications}</h3>
                <p className="text-sm text-amber-600">{pendingReview} pending review</p>
              </div>
              <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
                <FileText className="h-6 w-6 text-amber-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Selection Rate</p>
                <h3 className="text-3xl font-bold">
                  {totalApplications > 0 ? Math.round((selected / totalApplications) * 100) : 0}%
                </h3>
                <p className="text-sm text-green-600">{selected} selected</p>
              </div>
              <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                <UserCheck className="h-6 w-6 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Departments</p>
                <h3 className="text-3xl font-bold">{totalDepartments}</h3>
                <p className="text-sm text-purple-600">{jobs?.filter((job: any) => job.isRemote).length || 0} remote jobs</p>
              </div>
              <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Building className="h-6 w-6 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Application Trends</CardTitle>
              <CardDescription>Daily application submissions over the last 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={applicationChartData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="applications" stroke="#0F4C81" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Application Status</CardTitle>
              <CardDescription>Distribution of applications by current status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={statusDistribution}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#0F4C81" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Department Performance</CardTitle>
            <CardDescription>Jobs and applications by department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={departmentJobsData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="jobs" fill="#0F4C81" name="Jobs" />
                  <Bar dataKey="applications" fill="#f59e0b" name="Applications" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
