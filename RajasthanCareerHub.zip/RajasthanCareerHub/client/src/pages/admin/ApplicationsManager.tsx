import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import {
  Search,
  FileText,
  ChevronDown,
  Eye,
  Download,
  Clock,
  CheckCircle2,
  XCircle,
  ClipboardList,
  User,
  Calendar,
  CalendarClock,
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import type { Application, Job, Department } from "@shared/schema";

// Status update form schema
const statusUpdateSchema = z.object({
  status: z.string().min(1, {
    message: "Status is required",
  }),
  notes: z.string().optional(),
});

type StatusUpdateValues = z.infer<typeof statusUpdateSchema>;

const ApplicationsManager = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  
  // Check if user is logged in and is admin
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 401) {
          // Redirect to login if unauthorized
          navigate('/login?redirect=/admin/applications');
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      return res.json();
    }),
  });

  // Get all applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ['/api/applications'],
    queryFn: () => fetch('/api/applications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch applications');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Get all jobs
  const { data: jobs } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => fetch('/api/jobs', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch jobs');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Get all departments
  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: () => fetch('/api/departments', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch departments');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Get application statuses
  const { data: constants } = useQuery({
    queryKey: ['/api/constants'],
    queryFn: () => fetch('/api/constants').then(res => {
      if (!res.ok) throw new Error('Failed to fetch constants');
      return res.json();
    }),
    enabled: !!user?.isAdmin,
  });

  // Update application status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, notes }: { id: number, status: string, notes?: string }) => {
      const response = await fetch(`/api/applications/${id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status, notes }),
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update application status');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Status updated successfully",
        variant: "success",
      });
      setIsUpdateModalOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/applications'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Initialize status update form
  const statusForm = useForm<StatusUpdateValues>({
    resolver: zodResolver(statusUpdateSchema),
    defaultValues: {
      status: "",
      notes: "",
    },
  });

  // Handle status update form submission
  const onStatusUpdate = (values: StatusUpdateValues) => {
    if (selectedApp) {
      updateStatusMutation.mutate({
        id: selectedApp.id,
        status: values.status,
        notes: values.notes,
      });
    }
  };

  // Set up status update form when selecting an application
  const handleUpdateStatus = (application: Application) => {
    setSelectedApp(application);
    statusForm.reset({
      status: application.status,
      notes: application.notes || "",
    });
    setIsUpdateModalOpen(true);
  };

  // Handle view application details
  const handleViewApplication = (application: Application) => {
    setSelectedApp(application);
    setIsViewModalOpen(true);
  };

  // Format status for display and styling
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SUBMITTED':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Submitted</Badge>;
      case 'UNDER_REVIEW':
        return <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">Under Review</Badge>;
      case 'SHORTLISTED':
        return <Badge variant="outline" className="bg-indigo-100 text-indigo-800 border-indigo-200">Shortlisted</Badge>;
      case 'INTERVIEW_SCHEDULED':
        return <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">Interview Scheduled</Badge>;
      case 'SELECTED':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Selected</Badge>;
      case 'REJECTED':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  // Get job details by ID
  const getJobDetails = (jobId: number) => {
    return jobs?.find((job: Job) => job.id === jobId);
  };

  // Get department name by ID
  const getDepartmentName = (departmentId: number) => {
    return departments?.find((dept: Department) => dept.id === departmentId)?.name || 'Unknown Department';
  };

  // Filter applications based on search term and active tab
  const filteredApplications = applications?.filter((application: Application) => {
    const job = getJobDetails(application.jobId);
    const matchesSearch = 
      job?.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(application.id).includes(searchTerm);
    
    if (activeTab === 'all') return matchesSearch;
    if (activeTab === 'submitted') return matchesSearch && application.status === 'SUBMITTED';
    if (activeTab === 'review') return matchesSearch && application.status === 'UNDER_REVIEW';
    if (activeTab === 'shortlisted') return matchesSearch && application.status === 'SHORTLISTED';
    if (activeTab === 'interview') return matchesSearch && application.status === 'INTERVIEW_SCHEDULED';
    if (activeTab === 'selected') return matchesSearch && application.status === 'SELECTED';
    if (activeTab === 'rejected') return matchesSearch && application.status === 'REJECTED';
    
    return matchesSearch;
  });

  // Verify admin status
  if (isLoadingUser) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="animate-pulse">
          <CardContent className="p-8">
            <div className="h-8 bg-gray-200 rounded mb-4 w-1/2"></div>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-gray-200 rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-amber-600 mb-4">Please log in to access the admin dashboard.</p>
            <Button onClick={() => navigate('/login?redirect=/admin/applications')}>
              Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user.isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-red-600 mb-4">You don't have access to the admin dashboard.</p>
            <Button onClick={() => navigate('/')}>
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Application Management</h1>
            <p className="text-gray-500">Review and manage job applications</p>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => navigate('/admin')}>
              Dashboard
            </Button>
            <Button variant="outline" onClick={() => navigate('/admin/jobs')}>
              Manage Jobs
            </Button>
          </div>
        </div>
        
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search by job title or application ID..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="submitted">Submitted</TabsTrigger>
                  <TabsTrigger value="review">Under Review</TabsTrigger>
                  <TabsTrigger value="shortlisted">Shortlisted</TabsTrigger>
                  <TabsTrigger value="interview">Interview</TabsTrigger>
                  <TabsTrigger value="selected">Selected</TabsTrigger>
                  <TabsTrigger value="rejected">Rejected</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            {isLoadingApplications ? (
              <div className="space-y-4 animate-pulse">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-16 bg-gray-200 rounded"></div>
                ))}
              </div>
            ) : filteredApplications?.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Job Title</TableHead>
                    <TableHead>Applicant</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredApplications.map((application: Application) => {
                    const job = getJobDetails(application.jobId);
                    const departmentName = job ? getDepartmentName(job.departmentId) : 'Unknown';
                    
                    return (
                      <TableRow key={application.id}>
                        <TableCell className="font-medium">{application.id}</TableCell>
                        <TableCell>{job?.title || `Job #${application.jobId}`}</TableCell>
                        <TableCell>User #{application.userId}</TableCell>
                        <TableCell>{departmentName}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                            {format(new Date(application.submittedAt), 'dd MMM yyyy')}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(application.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <ChevronDown className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleViewApplication(application)}>
                                <Eye className="h-4 w-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleUpdateStatus(application)}>
                                <ClipboardList className="h-4 w-4 mr-2" />
                                Update Status
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => navigate(`/jobs/${application.jobId}`)}>
                                <FileText className="h-4 w-4 mr-2" />
                                View Job Posting
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Download Resume
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-800 mb-2">No applications found</h3>
                <p className="text-gray-600 mb-6">
                  {searchTerm ? "No applications match your search criteria." : "There are no applications in this category."}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Update Status Modal */}
      <Dialog open={isUpdateModalOpen} onOpenChange={setIsUpdateModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Application Status</DialogTitle>
            <DialogDescription>
              Change the status of application #{selectedApp?.id}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...statusForm}>
            <form onSubmit={statusForm.handleSubmit(onStatusUpdate)} className="space-y-6">
              <FormField
                control={statusForm.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Application Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {constants?.applicationStatuses.map((status: string) => (
                          <SelectItem key={status} value={status}>
                            {status.replace('_', ' ')
                              .split(' ')
                              .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                              .join(' ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={statusForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add notes or feedback for the applicant..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      These notes will be visible to the applicant
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsUpdateModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={updateStatusMutation.isPending}
                >
                  {updateStatusMutation.isPending ? "Updating..." : "Update Status"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* View Application Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
            <DialogDescription>
              Viewing application #{selectedApp?.id}
            </DialogDescription>
          </DialogHeader>
          
          {selectedApp && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Application ID</h3>
                  <p className="mt-1">{selectedApp.id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Status</h3>
                  <div className="mt-1">{getStatusBadge(selectedApp.status)}</div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Applicant ID</h3>
                  <div className="mt-1 flex items-center">
                    <User className="h-4 w-4 mr-2 text-gray-400" />
                    <span>User #{selectedApp.userId}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Job Position</h3>
                  <p className="mt-1">{getJobDetails(selectedApp.jobId)?.title || `Job #${selectedApp.jobId}`}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Department</h3>
                  <p className="mt-1">
                    {getJobDetails(selectedApp.jobId) 
                      ? getDepartmentName(getJobDetails(selectedApp.jobId)!.departmentId) 
                      : 'Unknown'}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Job Type</h3>
                  <p className="mt-1">
                    {getJobDetails(selectedApp.jobId)
                      ? getJobDetails(selectedApp.jobId)!.jobType.replace('_', ' ')
                          .split(' ')
                          .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                          .join(' ')
                      : 'Unknown'}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Application Date</h3>
                  <div className="mt-1 flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{format(new Date(selectedApp.submittedAt), 'dd MMMM yyyy, HH:mm')}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Last Updated</h3>
                  <div className="mt-1 flex items-center">
                    <CalendarClock className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{format(new Date(selectedApp.updatedAt), 'dd MMMM yyyy, HH:mm')}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Cover Letter</h3>
                <div className="mt-2 p-4 bg-gray-50 rounded-md border text-sm whitespace-pre-line">
                  {selectedApp.coverLetter || "No cover letter provided."}
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Resume</h3>
                <div className="mt-2">
                  <Button variant="outline" size="sm" className="flex items-center">
                    <FileText className="h-4 w-4 mr-2" />
                    <span>Download Resume</span>
                  </Button>
                </div>
              </div>
              
              {selectedApp.notes && (
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Notes/Feedback</h3>
                  <div className="mt-2 p-4 bg-gray-50 rounded-md border text-sm whitespace-pre-line">
                    {selectedApp.notes}
                  </div>
                </div>
              )}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsViewModalOpen(false)}
                >
                  Close
                </Button>
                <Button onClick={() => {
                  setIsViewModalOpen(false);
                  handleUpdateStatus(selectedApp);
                }}>
                  Update Status
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ApplicationsManager;
