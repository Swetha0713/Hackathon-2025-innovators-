import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertTriangle,
  Check,
  ChevronRight,
  FileText,
  Loader2,
  MoreHorizontal,
  Search,
  UserCheck,
  X,
  Eye,
  ExternalLink,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  formatDateShort,
  getStatusBadgeColor,
  getFormattedStatusText,
} from "@/lib/utils";

const Applications = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTab, setSelectedTab] = useState("all");
  const [viewApplicationId, setViewApplicationId] = useState<number | null>(null);
  const [updateApplicationId, setUpdateApplicationId] = useState<number | null>(null);
  const [updateStatus, setUpdateStatus] = useState("");
  const [adminNotes, setAdminNotes] = useState("");
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);

  // Get URL query parameters
  const searchParams = typeof window !== "undefined" 
    ? new URLSearchParams(window.location.search) 
    : new URLSearchParams();
  const applicationIdParam = searchParams.get("id");

  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to fetch user");
        return res.json();
      } catch (error) {
        return null;
      }
    },
  });

  // Get all applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/applications"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch applications");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all jobs
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
    enabled: !!user?.isAdmin,
  });

  // Get all users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async ({ queryKey }) => {
      // This endpoint doesn't exist in our API, so we'll derive users from applications
      if (!applications) return [];
      
      const uniqueUserIds = [...new Set(applications.map((app: any) => app.userId))];
      return uniqueUserIds.map(id => {
        const app = applications.find((a: any) => a.userId === id);
        // Mock user object - in a real app, we would fetch this from the API
        return { id, username: `applicant_${id}` };
      });
    },
    enabled: !!applications,
  });

  // Get specific application details
  const { data: applicationDetail, isLoading: isLoadingApplicationDetail } = useQuery({
    queryKey: [`/api/applications/${viewApplicationId}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch application details");
      return res.json();
    },
    enabled: !!viewApplicationId && !!user?.isAdmin,
  });

  // Update application status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, notes }: { id: number; status: string; notes: string }) => {
      await apiRequest("PATCH", `/api/applications/${id}/status`, { status, adminNotes: notes });
    },
    onSuccess: () => {
      toast({
        title: "Status Updated",
        description: "The application status has been successfully updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      setIsStatusDialogOpen(false);
      setUpdateApplicationId(null);
      setUpdateStatus("");
      setAdminNotes("");
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update status",
        description: error instanceof Error ? error.message : "An error occurred",
      });
    },
  });

  // Helper function to get job details by id
  const getJobById = (jobId: number) => {
    return jobs?.find((job: any) => job.id === jobId);
  };

  // Helper function to get department details by id
  const getDepartmentById = (departmentId: number) => {
    return departments?.find((dept: any) => dept.id === departmentId);
  };

  // Helper function to get user by id
  const getUserById = (userId: number) => {
    return users?.find((user: any) => user.id === userId);
  };

  // Open application view dialog
  const handleViewApplication = (id: number) => {
    setViewApplicationId(id);
  };

  // Open application status update dialog
  const handleUpdateStatus = (id: number) => {
    const application = applications?.find((app: any) => app.id === id);
    if (application) {
      setUpdateApplicationId(id);
      setUpdateStatus(application.status);
      setAdminNotes(application.adminNotes || "");
      setIsStatusDialogOpen(true);
    }
  };

  // Submit status update
  const handleSubmitStatusUpdate = () => {
    if (updateApplicationId && updateStatus) {
      updateStatusMutation.mutate({
        id: updateApplicationId,
        status: updateStatus,
        notes: adminNotes,
      });
    }
  };

  // Filter applications based on search query and tab
  const filteredApplications = applications
    ? applications.filter((app: any) => {
        // Get associated job
        const job = getJobById(app.jobId);
        if (!job) return false;

        // Get associated department
        const department = getDepartmentById(job.departmentId);

        // Filter by search query
        const matchesSearch =
          job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (department?.name || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.status.toLowerCase().includes(searchQuery.toLowerCase());

        // Filter by status tab
        let matchesTab = true;
        if (selectedTab !== "all") {
          matchesTab = app.status === selectedTab.toUpperCase();
        }

        return matchesSearch && matchesTab;
      })
    : [];

  // Sort applications by applied date (newest first)
  const sortedApplications = [...(filteredApplications || [])].sort(
    (a: any, b: any) => new Date(b.appliedAt).getTime() - new Date(a.appliedAt).getTime()
  );

  // Automatically view application if id is in URL
  useEffect(() => {
    if (applicationIdParam && applications) {
      const appId = parseInt(applicationIdParam);
      const appExists = applications.some((app: any) => app.id === appId);
      if (appExists) {
        handleViewApplication(appId);
      }
    }
  }, [applicationIdParam, applications]);

  // Loading state
  const isLoading = 
    isLoadingUser || 
    isLoadingApplications || 
    isLoadingJobs || 
    isLoadingDepartments || 
    isLoadingUsers;

  // Check if user is not admin
  if (!isLoadingUser && (!user || !user.isAdmin)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-6">
              You do not have permission to access this page.
            </p>
            <Button asChild>
              <Link href="/">Return to Home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />

      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">
                Manage Applications
              </h1>
              <p className="text-gray-600">
                Review and manage job applications from candidates
              </p>
            </div>
          </div>

          {/* Applications Tabs and Search */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <Tabs 
                  defaultValue="all" 
                  value={selectedTab}
                  onValueChange={setSelectedTab}
                  className="w-full md:w-auto"
                >
                  <TabsList className="grid grid-cols-5 w-full md:w-auto">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="pending">Pending</TabsTrigger>
                    <TabsTrigger value="shortlisted">Shortlisted</TabsTrigger>
                    <TabsTrigger value="interview">Interview</TabsTrigger>
                    <TabsTrigger value="selected">Selected</TabsTrigger>
                  </TabsList>
                </Tabs>

                <div className="relative w-full md:w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="search"
                    placeholder="Search applications..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : sortedApplications.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Applicant</TableHead>
                        <TableHead>Job Position</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Applied Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedApplications.map((application: any) => {
                        const job = getJobById(application.jobId);
                        const department = job ? getDepartmentById(job.departmentId) : null;
                        
                        return (
                          <TableRow key={application.id}>
                            <TableCell className="font-medium">
                              Applicant #{application.userId}
                            </TableCell>
                            <TableCell>
                              {job ? job.title : "Job not available"}
                            </TableCell>
                            <TableCell>
                              {department ? department.name : "N/A"}
                            </TableCell>
                            <TableCell>
                              {formatDateShort(application.appliedAt)}
                            </TableCell>
                            <TableCell>
                              <Badge
                                className={getStatusBadgeColor(application.status)}
                              >
                                {getFormattedStatusText(application.status)}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Open menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem 
                                    onClick={() => handleViewApplication(application.id)}
                                  >
                                    <Eye className="h-4 w-4 mr-2" />
                                    View Application
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleUpdateStatus(application.id)}
                                  >
                                    <UserCheck className="h-4 w-4 mr-2" />
                                    Update Status
                                  </DropdownMenuItem>
                                  {job && (
                                    <>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem asChild>
                                        <Link href={`/jobs/${job.id}`}>
                                          <ExternalLink className="h-4 w-4 mr-2" />
                                          View Job Posting
                                        </Link>
                                      </DropdownMenuItem>
                                    </>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">
                    No Applications Found
                  </h3>
                  <p className="text-gray-500 mb-4">
                    {searchQuery
                      ? "No applications matching your search criteria"
                      : selectedTab !== "all"
                      ? `No applications with ${selectedTab} status`
                      : "There are no applications yet."}
                  </p>
                  {searchQuery && (
                    <Button 
                      variant="outline" 
                      onClick={() => setSearchQuery("")}
                    >
                      Clear Search
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Application Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {applications?.length || 0}
                </div>
                <p className="text-xs text-gray-500">All applications</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Pending</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  {applications?.filter((app: any) => app.status === "PENDING").length || 0}
                </div>
                <p className="text-xs text-gray-500">Awaiting review</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Shortlisted</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {applications?.filter((app: any) => app.status === "SHORTLISTED").length || 0}
                </div>
                <p className="text-xs text-gray-500">Passed initial screening</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Interview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-indigo-600">
                  {applications?.filter((app: any) => app.status === "INTERVIEW").length || 0}
                </div>
                <p className="text-xs text-gray-500">Scheduled for interview</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Selected</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {applications?.filter((app: any) => app.status === "SELECTED").length || 0}
                </div>
                <p className="text-xs text-gray-500">Approved for hiring</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* View Application Dialog */}
      <Dialog 
        open={!!viewApplicationId} 
        onOpenChange={(open) => !open && setViewApplicationId(null)}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
          </DialogHeader>
          
          {isLoadingApplicationDetail ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : applicationDetail ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Applicant ID</h3>
                  <p className="font-medium">#{applicationDetail.userId}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Application Date</h3>
                  <p className="font-medium">{formatDateShort(applicationDetail.appliedAt)}</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Job Position</h3>
                <p className="font-medium">
                  {getJobById(applicationDetail.jobId)?.title || "Job not available"}
                </p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Status</h3>
                <Badge className={getStatusBadgeColor(applicationDetail.status)}>
                  {getFormattedStatusText(applicationDetail.status)}
                </Badge>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Resume</h3>
                <a 
                  href={applicationDetail.resumeUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-center"
                >
                  <FileText className="h-4 w-4 mr-1" />
                  View Resume
                </a>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Cover Letter</h3>
                <div className="mt-1 p-3 bg-gray-50 rounded-md text-sm max-h-40 overflow-y-auto">
                  {applicationDetail.coverLetter || "No cover letter provided"}
                </div>
              </div>
              
              {applicationDetail.adminNotes && (
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Admin Notes</h3>
                  <div className="mt-1 p-3 bg-gray-50 rounded-md text-sm">
                    {applicationDetail.adminNotes}
                  </div>
                </div>
              )}
              
              <div className="flex justify-end space-x-3">
                <Button 
                  variant="outline"
                  onClick={() => setViewApplicationId(null)}
                >
                  Close
                </Button>
                <Button onClick={() => handleUpdateStatus(applicationDetail.id)}>
                  Update Status
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-gray-500">Application not found</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Update Status Dialog */}
      <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Application Status</DialogTitle>
            <DialogDescription>
              Change the status of this application and provide feedback to the candidate.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select
                value={updateStatus}
                onValueChange={setUpdateStatus}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="SHORTLISTED">Shortlisted</SelectItem>
                  <SelectItem value="INTERVIEW">Interview</SelectItem>
                  <SelectItem value="SELECTED">Selected</SelectItem>
                  <SelectItem value="REJECTED">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Admin Notes / Feedback</label>
              <Textarea
                placeholder="Provide feedback or notes about this application..."
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                rows={4}
              />
              <p className="text-xs text-gray-500">
                Notes will be visible to the applicant on their profile.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsStatusDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitStatusUpdate}
              disabled={updateStatusMutation.isPending}
            >
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                "Update Status"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default Applications;
