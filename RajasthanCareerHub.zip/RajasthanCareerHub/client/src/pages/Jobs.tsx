import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, MapPin, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import JobCard from "@/components/job/JobCard";
import type { Job, Department } from "@shared/schema";

const Jobs = () => {
  const [filters, setFilters] = useState({
    keyword: "",
    departmentId: "",
    jobType: "",
    location: "",
    experience: "",
    salaryMin: "",
    salaryMax: "",
    isRemote: false,
    postedAfter: ""
  });

  const [sortBy, setSortBy] = useState("recent");
  
  // Fetch the departments for the filter dropdown
  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: () => fetch('/api/departments').then(res => res.json()),
  });

  // Fetch job types, experience levels
  const { data: constants } = useQuery({
    queryKey: ['/api/constants'],
    queryFn: () => fetch('/api/constants').then(res => res.json()),
  });

  // Fetch jobs with filters
  const { data: jobs, isLoading, refetch } = useQuery({
    queryKey: ['/api/jobs', filters],
    queryFn: () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== "" && value !== false) {
          params.append(key, String(value));
        }
      });
      
      return fetch(`/api/jobs?${params.toString()}`).then(res => res.json());
    },
  });

  const handleFilterChange = (name: string, value: string | boolean) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    refetch();
  };

  const handleReset = () => {
    setFilters({
      keyword: "",
      departmentId: "",
      jobType: "",
      location: "",
      experience: "",
      salaryMin: "",
      salaryMax: "",
      isRemote: false,
      postedAfter: ""
    });
    setSortBy("recent");
  };

  // Sort jobs based on the selected option
  const sortedJobs = jobs ? [...jobs].sort((a: Job, b: Job) => {
    switch (sortBy) {
      case "recent":
        return new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime();
      case "salary-high":
        return (b.salaryMax || 0) - (a.salaryMax || 0);
      case "salary-low":
        return (a.salaryMin || 0) - (b.salaryMin || 0);
      default:
        return 0;
    }
  }) : [];

  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="py-8">
        <div className="container mx-auto px-4">
          <h2 className="font-heading font-bold text-2xl sm:text-3xl text-gray-800 mb-6">Find Your Opportunity</h2>
          
          <Card className="mb-8">
            <CardContent className="p-6">
              <form onSubmit={handleSearch}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <Label htmlFor="keyword">Keyword</Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input 
                        id="keyword" 
                        className="pl-10" 
                        placeholder="Job title, skills, keywords..."
                        value={filters.keyword}
                        onChange={(e) => handleFilterChange("keyword", e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="department">Department</Label>
                    <Select 
                      value={filters.departmentId} 
                      onValueChange={(value) => handleFilterChange("departmentId", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All Departments" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        {departments?.map((dept: Department) => (
                          <SelectItem key={dept.id} value={String(dept.id)}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="jobType">Job Type</Label>
                    <Select 
                      value={filters.jobType} 
                      onValueChange={(value) => handleFilterChange("jobType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All Types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        {constants?.jobTypes.map((type: string) => (
                          <SelectItem key={type} value={type}>
                            {type.replace('_', ' ').toLowerCase()
                              .split(' ')
                              .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                              .join(' ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input 
                        id="location" 
                        className="pl-10" 
                        placeholder="City or district..."
                        value={filters.location}
                        onChange={(e) => handleFilterChange("location", e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="experience">Experience</Label>
                    <Select 
                      value={filters.experience} 
                      onValueChange={(value) => handleFilterChange("experience", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Any Experience" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any Experience</SelectItem>
                        {constants?.experienceLevels.map((level: string) => (
                          <SelectItem key={level} value={level}>
                            {level === 'ENTRY_LEVEL' 
                              ? 'Entry Level' 
                              : level === 'JUNIOR' 
                                ? '1-3 Years' 
                                : level === 'MID_LEVEL' 
                                  ? '3-5 Years' 
                                  : '5+ Years'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="salary">Salary Range</Label>
                    <Select 
                      value={`${filters.salaryMin}-${filters.salaryMax}`} 
                      onValueChange={(value) => {
                        const [min, max] = value.split('-');
                        handleFilterChange("salaryMin", min);
                        handleFilterChange("salaryMax", max);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Any Salary" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="-">Any Salary</SelectItem>
                        <SelectItem value="0-3">Up to ₹3 LPA</SelectItem>
                        <SelectItem value="3-6">₹3-6 LPA</SelectItem>
                        <SelectItem value="6-10">₹6-10 LPA</SelectItem>
                        <SelectItem value="10-">₹10+ LPA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="postDate">Posted Date</Label>
                    <Select 
                      value={filters.postedAfter} 
                      onValueChange={(value) => handleFilterChange("postedAfter", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Any Time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any Time</SelectItem>
                        <SelectItem value={new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()}>Today</SelectItem>
                        <SelectItem value={new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()}>Last 3 Days</SelectItem>
                        <SelectItem value={new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()}>Last Week</SelectItem>
                        <SelectItem value={new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()}>Last Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-center">
                  <div className="mb-3 sm:mb-0">
                    <div className="flex items-center">
                      <Checkbox 
                        id="remote" 
                        checked={filters.isRemote}
                        onCheckedChange={(checked) => handleFilterChange("isRemote", Boolean(checked))}
                      />
                      <Label htmlFor="remote" className="ml-2">Remote Work</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleReset}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-700 border-none"
                    >
                      Reset
                    </Button>
                    <Button type="submit">Search</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
          
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-heading font-bold text-2xl text-gray-800">
              {isLoading ? 'Searching...' : `${sortedJobs.length} Opportunities`}
            </h2>
            <div className="flex items-center">
              <span className="text-gray-600 text-sm mr-2">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="min-w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Date (Newest)</SelectItem>
                  <SelectItem value="salary-high">Salary (High to Low)</SelectItem>
                  <SelectItem value="salary-low">Salary (Low to High)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mb-8">
            {isLoading ? (
              <div className="grid grid-cols-1 gap-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-6 bg-gray-200 rounded mb-2 w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-4 w-1/2"></div>
                      <div className="flex gap-2 mb-4">
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                        <div className="h-6 w-20 bg-gray-200 rounded"></div>
                      </div>
                      <div className="h-10 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : sortedJobs.length > 0 ? (
              sortedJobs.map((job: Job) => (
                <JobCard key={job.id} job={job} />
              ))
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No jobs found matching your criteria. Please try different filters.</p>
                </CardContent>
              </Card>
            )}
          </div>
          
          {sortedJobs.length > 0 && (
            <div className="flex justify-center">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary-50">
                Load More Opportunities
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Jobs;
