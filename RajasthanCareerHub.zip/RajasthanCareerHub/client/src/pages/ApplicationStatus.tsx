import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CheckCircle2,
  Clock,
  FileText,
  AlertCircle,
  Building,
  CalendarClock,
  Calendar,
  UserCheck,
  XCircle
} from "lucide-react";
import type { Application, Job } from "@shared/schema";

// Helper for status badge
const getStatusBadge = (status: string) => {
  switch (status) {
    case 'SUBMITTED':
      return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Submitted</Badge>;
    case 'UNDER_REVIEW':
      return <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">Under Review</Badge>;
    case 'SHORTLISTED':
      return <Badge variant="outline" className="bg-indigo-100 text-indigo-800 border-indigo-200">Shortlisted</Badge>;
    case 'INTERVIEW_SCHEDULED':
      return <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">Interview Scheduled</Badge>;
    case 'SELECTED':
      return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Selected</Badge>;
    case 'REJECTED':
      return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
    default:
      return <Badge variant="outline">Unknown</Badge>;
  }
};

const ApplicationStatus = () => {
  const [_, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('all');
  
  // Check if user is logged in
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => fetch('/api/auth/me', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) {
        if (res.status === 401) {
          // Redirect to login if unauthorized
          setLocation('/login?redirect=/applications');
          return null;
        }
        throw new Error('Failed to fetch user');
      }
      return res.json();
    }),
  });

  // Get user's applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ['/api/applications', { userId: user?.id }],
    queryFn: () => fetch('/api/applications', {
      credentials: 'include'
    }).then(res => {
      if (!res.ok) throw new Error('Failed to fetch applications');
      return res.json();
    }),
    enabled: !!user,
  });

  // Get jobs for applications
  const { data: jobs } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => fetch('/api/jobs').then(res => {
      if (!res.ok) throw new Error('Failed to fetch jobs');
      return res.json();
    }),
  });

  // Filter applications by status
  const filteredApplications = applications?.filter((app: Application) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'active') {
      return !['SELECTED', 'REJECTED'].includes(app.status);
    }
    if (activeTab === 'completed') {
      return ['SELECTED', 'REJECTED'].includes(app.status);
    }
    return app.status === activeTab;
  });

  // Get job details for each application
  const getJobDetails = (jobId: number) => {
    return jobs?.find((job: Job) => job.id === jobId);
  };

  if (isLoadingUser) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="animate-pulse">
            <CardContent className="p-8">
              <div className="h-6 bg-gray-200 rounded mb-4 w-1/2"></div>
              <div className="space-y-4">
                {[...Array(3)].map((_, index) => (
                  <div key={index} className="h-32 bg-gray-200 rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-amber-600 mb-4">Please log in to view your applications.</p>
              <Button onClick={() => setLocation('/login?redirect=/applications')}>
                Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">My Applications</CardTitle>
              <CardDescription>
                Track the status of your job and internship applications
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 sm:grid-cols-6 mb-6">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="SUBMITTED">Submitted</TabsTrigger>
                  <TabsTrigger value="UNDER_REVIEW">Under Review</TabsTrigger>
                  <TabsTrigger value="SHORTLISTED">Shortlisted</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                </TabsList>
                
                <TabsContent value={activeTab}>
                  {isLoadingApplications ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, index) => (
                        <Card key={index} className="animate-pulse">
                          <CardContent className="p-6">
                            <div className="h-5 bg-gray-200 rounded w-1/3 mb-3"></div>
                            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                            <div className="flex justify-between">
                              <div className="h-8 bg-gray-200 rounded w-24"></div>
                              <div className="h-8 bg-gray-200 rounded w-24"></div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : !filteredApplications?.length ? (
                    <div className="text-center py-12">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-800 mb-2">No Applications Found</h3>
                      <p className="text-gray-600 mb-6">
                        {activeTab === 'all' 
                          ? "You haven't applied for any positions yet." 
                          : "No applications with this status."}
                      </p>
                      <Button onClick={() => setLocation('/jobs')}>
                        Browse Jobs
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredApplications.map((application: Application) => {
                        const job = getJobDetails(application.jobId);
                        return (
                          <Card key={application.id} className="overflow-hidden">
                            <CardContent className="p-0">
                              <div className="p-6">
                                <div className="flex flex-col md:flex-row justify-between mb-3">
                                  <div>
                                    <h3 className="text-lg font-medium text-gray-800">
                                      {job?.title || `Job #${application.jobId}`}
                                    </h3>
                                    <p className="text-gray-600 text-sm">
                                      {job?.departmentName || 'Department'}, {job?.location || 'Location'}
                                    </p>
                                  </div>
                                  <div className="mt-2 md:mt-0">
                                    {getStatusBadge(application.status)}
                                  </div>
                                </div>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4 text-sm">
                                  <div className="flex items-center">
                                    <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                                    <span className="text-gray-600">
                                      Applied: {format(new Date(application.submittedAt), 'dd MMM yyyy')}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <CalendarClock className="h-4 w-4 text-gray-400 mr-2" />
                                    <span className="text-gray-600">
                                      Last Updated: {format(new Date(application.updatedAt), 'dd MMM yyyy')}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <Building className="h-4 w-4 text-gray-400 mr-2" />
                                    <span className="text-gray-600">
                                      {job?.jobType.replace('_', ' ').toLowerCase()
                                        .split(' ')
                                        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                        .join(' ') || 'Job Type'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              
                              {application.notes && (
                                <div className="bg-gray-50 border-t border-gray-200 p-4">
                                  <p className="text-sm text-gray-700 whitespace-pre-line">
                                    <span className="font-medium">Feedback/Notes:</span> {application.notes}
                                  </p>
                                </div>
                              )}
                              
                              <div className="border-t border-gray-200 p-4 flex justify-between items-center bg-gray-50">
                                <div className="flex items-center">
                                  {application.status === 'SUBMITTED' && (
                                    <Clock className="h-4 w-4 text-blue-500 mr-2" />
                                  )}
                                  {application.status === 'UNDER_REVIEW' && (
                                    <FileText className="h-4 w-4 text-amber-500 mr-2" />
                                  )}
                                  {application.status === 'SHORTLISTED' && (
                                    <CheckCircle2 className="h-4 w-4 text-indigo-500 mr-2" />
                                  )}
                                  {application.status === 'INTERVIEW_SCHEDULED' && (
                                    <CalendarClock className="h-4 w-4 text-purple-500 mr-2" />
                                  )}
                                  {application.status === 'SELECTED' && (
                                    <UserCheck className="h-4 w-4 text-green-500 mr-2" />
                                  )}
                                  {application.status === 'REJECTED' && (
                                    <XCircle className="h-4 w-4 text-red-500 mr-2" />
                                  )}
                                  <p className="text-sm text-gray-600">
                                    {application.status === 'SUBMITTED' && "Your application is submitted and pending review."}
                                    {application.status === 'UNDER_REVIEW' && "Your application is currently being reviewed."}
                                    {application.status === 'SHORTLISTED' && "Congratulations! You've been shortlisted."}
                                    {application.status === 'INTERVIEW_SCHEDULED' && "You've been selected for an interview."}
                                    {application.status === 'SELECTED' && "Congratulations! You've been selected for this position."}
                                    {application.status === 'REJECTED' && "Thank you for your interest, but we've decided to move forward with other candidates."}
                                  </p>
                                </div>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => setLocation(`/jobs/${application.jobId}`)}
                                >
                                  View Job
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
            
            <CardFooter className="bg-gray-50 border-t px-6 py-4 flex justify-between">
              <p className="text-sm text-gray-500">
                {filteredApplications?.length 
                  ? `Showing ${filteredApplications.length} application${filteredApplications.length !== 1 ? 's' : ''}`
                  : 'No applications to display'}
              </p>
              <Button 
                variant="outline" 
                onClick={() => setLocation('/jobs')}
              >
                Browse More Jobs
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ApplicationStatus;
