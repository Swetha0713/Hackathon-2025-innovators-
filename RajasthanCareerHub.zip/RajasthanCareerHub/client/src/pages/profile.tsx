import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import Nav from "@/components/ui/nav";
import Footer from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Briefcase, 
  Clock, 
  Search, 
  Bell, 
  User, 
  Loader2, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  FileText,
  Calendar
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { queryClient } from "@/lib/queryClient";
import { 
  formatDateShort, 
  getFormattedJobType,
  getStatusBadgeColor, 
  getFormattedStatusText 
} from "@/lib/utils";

const Profile = () => {
  const [activeTab, setActiveTab] = useState("applications");

  // Get user data
  const { data: user, isLoading: isLoadingUser, isError: isErrorUser } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch user data");
      return res.json();
    },
  });

  // Get user applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/applications/user"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch applications");
      return res.json();
    },
    enabled: !!user,
  });

  // Get jobs for applications
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    enabled: !!applications,
  });

  // Get departments
  const { data: departments, isLoading: isLoadingDepartments } = useQuery({
    queryKey: ["/api/departments"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string);
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json();
    },
    enabled: !!jobs,
  });

  // Get notifications
  const { data: notifications, isLoading: isLoadingNotifications } = useQuery({
    queryKey: ["/api/notifications"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    enabled: !!user,
  });

  // Mark notification as read
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await fetch(`/api/notifications/${notificationId}/read`, {
        method: "PATCH",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to mark notification as read");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const handleMarkAsRead = (notificationId: number) => {
    markAsReadMutation.mutate(notificationId);
  };

  // Helper function to get job details by id
  const getJobById = (jobId: number) => {
    return jobs?.find((job: any) => job.id === jobId);
  };

  // Helper function to get department details by id
  const getDepartmentById = (departmentId: number) => {
    return departments?.find((dept: any) => dept.id === departmentId);
  };

  // Loading state
  const isLoading = 
    isLoadingUser || 
    isLoadingApplications || 
    isLoadingJobs || 
    isLoadingDepartments || 
    isLoadingNotifications;

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  // Error state
  if (isErrorUser || !user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Nav />
        <div className="flex-grow flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Authentication Required</h1>
            <p className="text-gray-600 mb-6">
              Please login to view your profile and application status.
            </p>
            <Button asChild>
              <Link href="/auth/login?redirect=/profile">Login</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      
      {/* Main Content */}
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">My Profile</h1>
            <p className="text-gray-600">
              View and manage your applications and notifications
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Profile Sidebar */}
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-2">
                    <User className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle>{user.fullName}</CardTitle>
                  <CardDescription>{user.email}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 text-sm">
                    <div>
                      <p className="text-gray-500">Username</p>
                      <p className="font-medium">{user.username}</p>
                    </div>
                    {user.phone && (
                      <div>
                        <p className="text-gray-500">Phone</p>
                        <p className="font-medium">{user.phone}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-gray-500">Account Created</p>
                      <p className="font-medium">{formatDateShort(user.createdAt)}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="flex space-x-2 w-full">
                    <Button variant="outline" className="flex-1" asChild>
                      <Link href="/jobs">
                        <Search className="h-4 w-4 mr-2" />
                        Browse Jobs
                      </Link>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
              
              {/* Application Stats */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Application Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Applications</span>
                      <Badge variant="outline">{applications?.length || 0}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Pending</span>
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                        {applications?.filter((app: any) => app.status === "PENDING").length || 0}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Shortlisted</span>
                      <Badge variant="outline" className="bg-blue-100 text-blue-800">
                        {applications?.filter((app: any) => app.status === "SHORTLISTED").length || 0}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Interview</span>
                      <Badge variant="outline" className="bg-purple-100 text-purple-800">
                        {applications?.filter((app: any) => app.status === "INTERVIEW").length || 0}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Selected</span>
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {applications?.filter((app: any) => app.status === "SELECTED").length || 0}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Rejected</span>
                      <Badge variant="outline" className="bg-red-100 text-red-800">
                        {applications?.filter((app: any) => app.status === "REJECTED").length || 0}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-3">
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="applications">
                    <Briefcase className="h-4 w-4 mr-2" />
                    Applications
                  </TabsTrigger>
                  <TabsTrigger value="notifications">
                    <Bell className="h-4 w-4 mr-2" />
                    Notifications
                    {notifications?.filter((n: any) => !n.isRead).length > 0 && (
                      <Badge className="ml-2 bg-red-500" variant="destructive">
                        {notifications?.filter((n: any) => !n.isRead).length}
                      </Badge>
                    )}
                  </TabsTrigger>
                </TabsList>
                
                {/* Applications Tab */}
                <TabsContent value="applications">
                  <Card>
                    <CardHeader>
                      <CardTitle>My Applications</CardTitle>
                      <CardDescription>
                        Track the status of your job applications
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {applications && applications.length > 0 ? (
                        <div className="space-y-4">
                          {applications.map((application: any) => {
                            const job = getJobById(application.jobId);
                            const department = job ? getDepartmentById(job.departmentId) : null;
                            
                            return (
                              <div key={application.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition duration-300">
                                <div className="flex flex-col md:flex-row md:items-center">
                                  <div className="md:w-3/4">
                                    <h3 className="text-lg font-semibold text-gray-800">
                                      {job?.title || "Job no longer available"}
                                    </h3>
                                    {job && department && (
                                      <p className="text-gray-600 mb-2">
                                        {department.name} | {job.location}
                                      </p>
                                    )}
                                    
                                    <div className="flex flex-wrap items-center gap-3 mb-3 text-sm">
                                      {job && (
                                        <Badge variant="outline" className="px-2 py-1">
                                          {getFormattedJobType(job.type)}
                                        </Badge>
                                      )}
                                      <Badge 
                                        variant="outline" 
                                        className={`${getStatusBadgeColor(application.status)} px-2 py-1`}
                                      >
                                        {getFormattedStatusText(application.status)}
                                      </Badge>
                                    </div>
                                    
                                    <div className="flex items-center text-gray-500 text-sm">
                                      <Calendar className="h-4 w-4 mr-1" />
                                      Applied on {formatDateShort(application.appliedAt)}
                                    </div>
                                  </div>
                                  
                                  <div className="md:w-1/4 mt-4 md:mt-0 md:flex md:justify-end">
                                    {job && (
                                      <Button variant="outline" asChild>
                                        <Link href={`/jobs/${job.id}`}>
                                          View Job
                                        </Link>
                                      </Button>
                                    )}
                                  </div>
                                </div>
                                
                                {application.adminNotes && (
                                  <div className="mt-3 p-3 bg-gray-50 rounded-md text-sm text-gray-700">
                                    <p className="font-medium mb-1">Feedback from Recruiter:</p>
                                    <p>{application.adminNotes}</p>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <div className="bg-gray-50 rounded-lg p-8">
                            <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-gray-700 mb-2">No Applications Yet</h3>
                            <p className="text-gray-500 mb-4">
                              You haven't applied to any jobs or internships yet.
                            </p>
                            <Button asChild>
                              <Link href="/jobs">Browse Jobs</Link>
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {/* Notifications Tab */}
                <TabsContent value="notifications">
                  <Card>
                    <CardHeader>
                      <CardTitle>Notifications</CardTitle>
                      <CardDescription>
                        Stay updated with your application status and important announcements
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {notifications && notifications.length > 0 ? (
                        <div className="space-y-3">
                          {notifications.map((notification: any) => (
                            <div 
                              key={notification.id} 
                              className={`p-4 border-l-4 ${
                                notification.isRead ? 'border-gray-200' : 'border-primary'
                              } bg-white rounded-r-lg shadow-sm`}
                            >
                              <div className="flex justify-between">
                                <h4 className={`font-medium ${notification.isRead ? 'text-gray-700' : 'text-gray-900'}`}>
                                  {notification.message}
                                </h4>
                                {!notification.isRead && (
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleMarkAsRead(notification.id)}
                                    className="h-7 text-xs"
                                  >
                                    Mark as read
                                  </Button>
                                )}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                {new Date(notification.createdAt).toLocaleString()}
                              </p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <div className="bg-gray-50 rounded-lg p-8">
                            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-gray-700 mb-2">No Notifications</h3>
                            <p className="text-gray-500">
                              You don't have any notifications yet. Check back later.
                            </p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                    {notifications && notifications.length > 0 && (
                      <CardFooter>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => {
                            notifications
                              .filter((n: any) => !n.isRead)
                              .forEach((n: any) => handleMarkAsRead(n.id));
                          }}
                          disabled={!notifications.some((n: any) => !n.isRead)}
                          className="ml-auto"
                        >
                          Mark all as read
                        </Button>
                      </CardFooter>
                    )}
                  </Card>
                </TabsContent>
              </Tabs>
              
              {/* Application Timeline */}
              {activeTab === "applications" && applications && applications.length > 0 && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Application Process</CardTitle>
                    <CardDescription>
                      Understanding the stages of the application process
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="relative">
                      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                      
                      <div className="space-y-6">
                        <div className="relative flex items-start">
                          <div className="absolute left-4 top-0 -ml-2 h-4 w-4 rounded-full bg-primary"></div>
                          <div className="ml-8">
                            <h3 className="font-medium text-gray-900">Application Submitted</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Your application is received and will be reviewed by our recruitment team.
                            </p>
                          </div>
                        </div>
                        
                        <div className="relative flex items-start">
                          <div className="absolute left-4 top-0 -ml-2 h-4 w-4 rounded-full bg-gray-200 border-2 border-white"></div>
                          <div className="ml-8">
                            <h3 className="font-medium text-gray-900">Application Shortlisting</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Applications are reviewed and shortlisted based on qualifications and requirements.
                            </p>
                          </div>
                        </div>
                        
                        <div className="relative flex items-start">
                          <div className="absolute left-4 top-0 -ml-2 h-4 w-4 rounded-full bg-gray-200 border-2 border-white"></div>
                          <div className="ml-8">
                            <h3 className="font-medium text-gray-900">Interview</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Shortlisted candidates are invited for an interview to assess skills and cultural fit.
                            </p>
                          </div>
                        </div>
                        
                        <div className="relative flex items-start">
                          <div className="absolute left-4 top-0 -ml-2 h-4 w-4 rounded-full bg-gray-200 border-2 border-white"></div>
                          <div className="ml-8">
                            <h3 className="font-medium text-gray-900">Final Selection</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Final candidates are selected based on overall assessment and background verification.
                            </p>
                          </div>
                        </div>
                        
                        <div className="relative flex items-start">
                          <div className="absolute left-4 top-0 -ml-2 h-4 w-4 rounded-full bg-gray-200 border-2 border-white"></div>
                          <div className="ml-8">
                            <h3 className="font-medium text-gray-900">Offer & Onboarding</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Selected candidates receive offer letters and onboarding information.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Profile;
