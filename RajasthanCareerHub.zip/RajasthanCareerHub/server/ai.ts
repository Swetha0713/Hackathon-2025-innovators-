// Simple AI recommendation engine for job matching
import { Job, UserProfile } from "@shared/schema";

interface SkillMatch {
  job: Job;
  matchScore: number;
}

// Extract skills from text
function extractSkills(text: string): string[] {
  if (!text) return [];
  
  // Convert to lowercase and remove special characters
  const normalizedText = text.toLowerCase().replace(/[^\w\s]/g, ' ');
  
  // Common tech skills to look for
  const commonSkills = [
    'javascript', 'react', 'node', 'typescript', 'python', 'java', 'c++', 'c#',
    'sql', 'postgresql', 'mysql', 'mongodb', 'nosql', 'html', 'css', 'php',
    'flutter', 'android', 'ios', 'swift', 'kotlin', 'docker', 'kubernetes',
    'aws', 'azure', 'gcp', 'linux', 'git', 'devops', 'machine learning', 'ai',
    'data science', 'blockchain', 'cloud', 'cybersecurity', 'testing', 'qa',
    'ui/ux', 'design', 'agile', 'scrum', 'product management'
  ];
  
  // Extract the skills that appear in the text
  return commonSkills.filter(skill => 
    normalizedText.includes(skill) || 
    normalizedText.includes(skill.replace(' ', ''))
  );
}

// Calculate match score between job and profile
function calculateMatchScore(job: Job, profile: UserProfile): number {
  if (!job || !profile) return 0;
  
  let score = 0;
  
  // Extract skills from job description and other properties
  const jobSkills = [
    ...extractSkills(job.description || ''),
    ...extractSkills(job.qualifications || ''),
    ...extractSkills(job.responsibilities || '')
  ];
  
  // Extract skills from user profile
  const userSkills = [
    ...(Array.isArray(profile.skills) ? profile.skills : extractSkills(profile.skills || '')),
    ...extractSkills(profile.experience || '')
  ];
  
  // Calculate skill matches
  userSkills.forEach(skill => {
    if (jobSkills.includes(skill)) {
      score += 10; // +10 points for each skill match
    }
  });
  
  // No title match since title isn't in the profile schema
  
  // Experience level match - parse experience string to get years
  if (job.experience && profile.experience) {
    // Try to extract years of experience from the string
    const yearsMatch = profile.experience.match(/(\d+)[\s+]?years?/i);
    const experienceYears = yearsMatch ? parseInt(yearsMatch[1]) : 0;
    
    switch (job.experience) {
      case 'ENTRY_LEVEL':
        score += experienceYears < 2 ? 20 : 5;
        break;
      case 'JUNIOR':
        score += (experienceYears >= 1 && experienceYears <= 3) ? 20 : 5;
        break;
      case 'MID_LEVEL':
        score += (experienceYears >= 3 && experienceYears <= 5) ? 20 : 5;
        break;
      case 'SENIOR':
        score += experienceYears > 5 ? 20 : 5;
        break;
    }
  }
  
  return score;
}

// Get job recommendations for a user
export function getJobRecommendations(
  userProfile: UserProfile,
  availableJobs: Job[],
  limit: number = 5
): Job[] {
  if (!userProfile || !availableJobs || availableJobs.length === 0) {
    return [];
  }
  
  // Calculate match scores for all jobs
  const jobMatches: SkillMatch[] = availableJobs.map(job => ({
    job,
    matchScore: calculateMatchScore(job, userProfile)
  }));
  
  // Sort by match score (highest first)
  jobMatches.sort((a, b) => b.matchScore - a.matchScore);
  
  // Return top N recommended jobs
  return jobMatches.slice(0, limit).map(match => match.job);
}

// Get personalized job description with highlighted skills
export function getPersonalizedJobDescription(
  job: Job,
  userProfile: UserProfile
): string {
  if (!job || !job.description || !userProfile) {
    return job?.description || '';
  }
  
  // Extract user skills
  const userSkills = [
    ...(Array.isArray(userProfile.skills) ? userProfile.skills : extractSkills(userProfile.skills || '')),
    ...extractSkills(userProfile.experience || '')
  ];
  
  if (userSkills.length === 0) {
    return job.description;
  }
  
  // Highlight matching skills in description
  let personalizedDesc = job.description;
  
  userSkills.forEach(skill => {
    // Create regex that matches the skill as a whole word, case insensitive
    const regex = new RegExp(`\\b${skill}\\b`, 'gi');
    personalizedDesc = personalizedDesc.replace(regex, `<strong class="text-primary">$&</strong>`);
  });
  
  return personalizedDesc;
}