import OpenAI from "openai";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. Do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// System prompt that gives context about the job portal
const SYSTEM_PROMPT = `You are a helpful career advisor chatbot on the Government of Rajasthan's Technical and Education Department job portal.
- Answer user questions about job opportunities, careers, application processes, and other job-related queries.
- Focus on being informative, helpful, and concise.
- If a user asks about specific job listings, encourage them to check the jobs page for the most up-to-date openings.
- If a user asks about application status, direct them to login and check the 'My Applications' section.
- For technical skills questions, provide accurate and helpful information.
- Always be respectful, professional, and maintain a positive tone.
- Personalize responses when possible.
- Keep responses concise, generally under 150 words unless more detail is specifically required.
- Answer in the same language the user asked the question in.`;

export async function generateChatResponse(userPrompt: string, jobData?: any[]): Promise<string> {
  try {
    let prompt = userPrompt;
    
    // Add context about available jobs if we have job data
    if (jobData && jobData.length > 0) {
      const jobContext = jobData.map(job => 
        `- ${job.title}: ${job.description.substring(0, 100)}... (ID: ${job.id})`
      ).join('\n');
      prompt = `User question: ${userPrompt}\n\nCurrent job listings:\n${jobContext}`;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // Latest model as of May 2024
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try asking again.";
  } catch (error) {
    console.error("Error calling OpenAI:", error);
    return "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later.";
  }
}