import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';

// Initialize Google Generative AI with API key
const genAI = new GoogleGenerativeAI(process.env.VERTEX_AI_API_KEY || '');

// Model configuration
const modelName = 'gemini-1.5-pro';

// Create a generative model instance
const model = genAI.getGenerativeModel({
  model: modelName,
  safetySettings: [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ],
});

/**
 * Generates a response using Vertex AI
 * 
 * @param userPrompt - The user's question or prompt
 * @param jobData - Optional job data to provide context
 * @returns - The generated response text
 */
export async function generateChatResponse(userPrompt: string, jobData?: any[]): Promise<string> {
  try {
    // Create system message with context
    let systemMessage = 'You are a helpful career assistant for the Government of Rajasthan Technical and Education Department Job Portal. ';
    systemMessage += 'You provide information about job opportunities, application processes, and career advice. ';
    systemMessage += 'Your responses should be concise, accurate, and helpful to job seekers. ';
    
    // If job data is provided, add it to the context
    if (jobData && jobData.length > 0) {
      systemMessage += 'Here is information about current job listings:\n';
      
      jobData.slice(0, 5).forEach((job, index) => {
        systemMessage += `Job ${index + 1}: ${job.title} - ${job.department} - ${job.location}\n`;
        systemMessage += `Description: ${job.description?.substring(0, 100)}...\n`;
        systemMessage += `Requirements: ${job.requirements?.substring(0, 100)}...\n\n`;
      });
    }

    // Create a chat session
    const chat = model.startChat({
      history: [
        { role: 'user', parts: [{ text: 'What kind of information can you provide?' }] },
        { role: 'model', parts: [{ text: 'I can help with information about job opportunities, application processes, qualifications needed for various positions, department information, career advice, and other job-related queries for the Government of Rajasthan Technical and Education Department.' }] },
      ],
      generationConfig: {
        temperature: 0.7,
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 1024,
      },
    });

    // Send the message with context and get response
    const result = await chat.sendMessage(systemMessage + '\n\nUser question: ' + userPrompt);
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error('Error calling Vertex AI:', error);
    return 'I apologize, but I encountered an error while processing your request. Please try again later.';
  }
}