/**
 * A comprehensive chatbot implementation that doesn't require external API calls
 * This provides a reliable chatbot experience without depending on third-party AI services
 */

import { Job } from '@shared/schema';

// Predefined responses for common questions
const RESPONSES: Record<string, string> = {
  // Job search related
  'job': 'You can find all available jobs on our Jobs page. You can filter by department, job type, location, and more.',
  'jobs': 'You can find all available jobs on our Jobs page. You can filter by department, job type, location, and more to find the perfect opportunity that matches your skills and interests.',
  'positions': 'We have various positions available in different departments. Check our Jobs page for the most up-to-date listings. You can also create job alerts to be notified when new positions matching your criteria are posted.',
  'openings': 'Current job openings can be found on our Jobs page. You can also set up notifications for new positions by updating your preferences in your profile.',
  'vacancies': 'All vacancies are listed on our Jobs page. You can filter by criteria like department, experience level, or job type to find positions that match your qualifications.',
  'search': 'To search for jobs, use the search bar on the Jobs page. You can filter results by keywords, department, location, or experience level.',
  'filter': 'Our job listings can be filtered by department, location, job type, and experience level to help you find the most relevant opportunities.',
  'salary': 'Salary details are provided in the individual job listings. Government positions typically follow standard pay scales based on grade and experience level.',
  'benefits': 'Government of Rajasthan jobs include benefits such as health insurance, pension plans, housing allowances, and paid leave. Specific benefits are mentioned in each job listing.',
  
  // Application process related
  'apply': 'To apply for a job, click on the job listing you\'re interested in and then click the "Apply Now" button. You\'ll need to create an account if you don\'t have one already.',
  'application': 'The application process involves submitting your resume, answering some questions, and possibly completing assessments. Once submitted, you can track your application status in your profile.',
  'resume': 'Your resume should highlight your relevant skills and experience. Make sure it\'s up-to-date before applying for positions. Our system will match your skills with job requirements.',
  'interview': 'If your application is selected, you\'ll be invited for interviews. These may be conducted virtually or in-person depending on the position and will typically include technical and behavioral questions.',
  'status': 'You can check the status of your applications in your profile dashboard. Applications may be in one of these states: Pending Review, Under Review, Interview Scheduled, Offer Extended, or Closed.',
  'rejected': 'If your application wasn\'t successful, we encourage you to apply for other positions that match your skills. You can also improve your profile to increase your chances for future applications.',
  'process': 'Our hiring process typically includes application screening, skills assessment, interviews, reference checks, and final selection. The timeline varies by department and position.',
  'documents': 'Required documents typically include your resume/CV, educational certificates, identity proof, and any relevant work experience certificates. Specific requirements are listed in each job posting.',
  
  // Department related
  'department': 'We have multiple departments including Information Technology, Educational Technology, and more. Each department has its own set of job openings and specializations.',
  'departments': 'Our main departments include Information Technology, Educational Technology, and others. You can filter jobs by department on our Jobs page to see opportunities in your area of expertise.',
  'it department': 'The Information Technology department handles various aspects of technical infrastructure and software development for the Government of Rajasthan.',
  'education department': 'The Educational Technology department focuses on implementing technology solutions in the education sector across Rajasthan schools and universities.',
  
  // Profile/Account related
  'profile': 'You can manage your profile by clicking on your username after logging in. There you can update your skills, experience, education, and personal information to improve job matches.',
  'account': 'Your account allows you to save job searches, track applications, and receive personalized job recommendations based on your skills and interests. Keep your information updated for best results.',
  'recommendations': 'Job recommendations are personalized based on your profile information, particularly your skills. Keep your profile updated with current skills and experience for the most relevant recommendations.',
  'skills': 'Adding relevant skills to your profile helps our system match you with appropriate job opportunities. Be specific and comprehensive when listing your skills and proficiency levels.',
  'password': 'You can reset your password by clicking on "Forgot Password" on the login page. You will receive an email with instructions to create a new password securely.',
  'signup': 'To create a new account, click on "Register" on the home page. You\'ll need to provide your email, create a password, and fill in basic profile information.',
  'delete account': 'To delete your account, please contact our support team at support@rajasthan-gov-careers.in with your request. Note that all your application data will be permanently removed.',
  
  // Help and support
  'help': 'If you need assistance with the job portal, please contact our support team at support@rajasthan-gov-careers.in or call our helpline at +91-XXXXXXXXXX during business hours.',
  'contact': 'You can contact our support team at support@rajasthan-gov-careers.in or call our helpline at +91-XXXXXXXXXX for any assistance with the portal or application process.',
  'support': 'For technical support or questions about your application, email support@rajasthan-gov-careers.in or call our helpline at +91-XXXXXXXXXX (Mon-Fri, 9:00 AM to 5:00 PM).',
  'feedback': 'We value your feedback! You can share your suggestions or report issues by clicking on the "Feedback" link at the bottom of any page or by emailing feedback@rajasthan-gov-careers.in.',
  'complaint': 'If you have a complaint about the recruitment process or website functionality, please email complaints@rajasthan-gov-careers.in with details of the issue for prompt resolution.',
  
  // Eligibility and qualifications
  'eligibility': 'Eligibility criteria vary by position and are clearly listed in each job posting. Common requirements include educational qualifications, experience, and sometimes age limits for certain roles.',
  'qualification': 'Required qualifications are specified in each job listing. These may include educational degrees, certifications, experience level, and specific technical skills.',
  'experience': 'Experience requirements vary by position. Entry-level positions may require minimal experience, while senior roles typically require 5+ years in relevant fields.',
  'education': 'Educational requirements differ based on the position. Technical roles may require specific degrees in computer science, engineering, or related fields, while administrative roles may accept various backgrounds.',
  'certification': 'Some positions require professional certifications relevant to the field. These requirements are listed in the job descriptions when applicable.',
  
  // Government specific
  'government': 'The Government of Rajasthan Technical and Education Department offers stable career opportunities with competitive benefits and the chance to contribute to public service.',
  'public service': 'Working in the public sector allows you to make a direct impact on citizen services and contribute to the development of Rajasthan state.',
  'exam': 'Some government positions require passing specific competitive examinations. Details about required exams are included in the job listings when applicable.',
  'selection': 'The selection process typically includes application screening, written tests or skill assessments, interviews, and documentation verification before final appointment.',
  
  // Technology and skills
  'technology': 'Our technical departments use a range of modern technologies including cloud computing, data analytics, mobile development, and cybersecurity tools.',
  'programming': 'Common programming skills required for our technical positions include expertise in languages like Java, Python, JavaScript, and frameworks relevant to web and mobile development.',
  'database': 'Database skills such as SQL, MongoDB, and data modeling are valuable for many of our technical positions in the IT department.',
  'infrastructure': 'Our IT infrastructure roles involve working with network systems, cloud platforms, security protocols, and server management.',

  // Chatbot capabilities
  'chatbot': 'I\'m a virtual assistant designed to help you with information about job opportunities, application processes, and career advice related to the Government of Rajasthan Technical and Education Department.',
  'assistant': 'As your virtual career assistant, I can provide information about job listings, application procedures, department details, and answer frequently asked questions about careers with the Government of Rajasthan.',
  
  // Default response
  'default': 'I\'m a career assistant for the Government of Rajasthan Technical and Education Department. I can help with information about job opportunities, the application process, and career advice. How can I assist you today?'
};

// Keywords that might be in a user's query, mapped to response keys
const KEYWORDS_MAP: Record<string, string[]> = {
  'job': ['position', 'opening', 'vacancy', 'opportunity', 'career', 'employment', 'work', 'role'],
  'jobs': ['positions', 'openings', 'vacancies', 'opportunities', 'careers', 'listings', 'postings'],
  'search': ['find', 'look for', 'search for', 'seeking', 'hunting', 'browsing'],
  'filter': ['narrow down', 'refine', 'sort', 'categorize'],
  'salary': ['pay', 'compensation', 'remuneration', 'wage', 'income', 'earnings'],
  'benefits': ['perks', 'advantages', 'insurance', 'medical', 'leave', 'vacation'],
  'apply': ['submit', 'application', 'applying', 'send', 'upload'],
  'application': ['apply', 'status', 'form', 'submitted', 'process', 'tracking'],
  'resume': ['cv', 'curriculum vitae', 'bio', 'biography', 'qualification'],
  'interview': ['meeting', 'call', 'screen', 'assessment', 'evaluation', 'selection'],
  'status': ['progress', 'state', 'stage', 'tracking', 'update'],
  'rejected': ['declined', 'unsuccessful', 'not selected', 'negative', 'denial'],
  'process': ['procedure', 'steps', 'stages', 'timeline', 'workflow'],
  'documents': ['papers', 'certificates', 'files', 'records', 'documentation'],
  'department': ['division', 'section', 'unit', 'branch', 'office'],
  'departments': ['divisions', 'sections', 'units', 'branches', 'offices'],
  'it department': ['information technology', 'tech department', 'it division', 'technical team'],
  'education department': ['educational tech', 'ed tech', 'learning technology', 'teaching'],
  'profile': ['account', 'details', 'information', 'personal data', 'bio'],
  'account': ['login', 'profile', 'register', 'signup', 'password', 'username', 'user'],
  'recommendations': ['suggest', 'recommendation', 'matching', 'suitable', 'fit'],
  'skills': ['abilities', 'competencies', 'expertise', 'talents', 'proficiencies'],
  'password': ['reset password', 'forgot password', 'change password', 'login issues'],
  'signup': ['register', 'create account', 'join', 'new user', 'enroll'],
  'delete account': ['remove account', 'deactivate', 'cancel account', 'terminate'],
  'help': ['support', 'assist', 'guidance', 'assistance', 'aid', 'help me'],
  'contact': ['email', 'phone', 'call', 'message', 'reach'],
  'support': ['help', 'contact', 'ticket', 'issue', 'problem', 'question'],
  'feedback': ['suggestion', 'comment', 'review', 'input', 'opinion'],
  'complaint': ['grievance', 'issue', 'problem', 'concern', 'dissatisfaction'],
  'eligibility': ['qualify', 'eligible', 'requirements', 'criteria', 'standards'],
  'qualification': ['degree', 'education', 'training', 'certification', 'diploma'],
  'experience': ['work history', 'background', 'job history', 'professional experience'],
  'education': ['degree', 'qualification', 'academic', 'school', 'university', 'college'],
  'certification': ['certificate', 'credential', 'license', 'accreditation'],
  'government': ['public sector', 'civil service', 'state government', 'public service'],
  'public service': ['government service', 'civil service', 'public sector', 'government work'],
  'exam': ['test', 'examination', 'assessment', 'evaluation', 'competitive exam'],
  'selection': ['hiring', 'recruitment', 'screening', 'choosing', 'shortlisting'],
  'technology': ['tech', 'digital', 'software', 'hardware', 'IT', 'computing'],
  'programming': ['coding', 'development', 'software development', 'engineer'],
  'database': ['sql', 'db', 'data storage', 'mongodb', 'oracle', 'mysql'],
  'infrastructure': ['network', 'servers', 'cloud', 'hardware', 'systems'],
  'chatbot': ['bot', 'virtual assistant', 'ai', 'chat assistant', 'digital assistant'],
  'assistant': ['help', 'ai', 'virtual helper', 'digital aid', 'automated support']
};

// Common question patterns that need more advanced matching
const QUESTION_PATTERNS: Array<{pattern: RegExp, responseKey: string}> = [
  {pattern: /how (can|do) I apply/i, responseKey: 'apply'},
  {pattern: /what (is|are) the benefits/i, responseKey: 'benefits'},
  {pattern: /how (can|do) I (create|make) (an|a) account/i, responseKey: 'signup'},
  {pattern: /what (is|are) the (application|hiring) process/i, responseKey: 'process'},
  {pattern: /how (can|do) I check (my|the) status/i, responseKey: 'status'},
  {pattern: /what documents (do I need|are required)/i, responseKey: 'documents'},
  {pattern: /how (can|do) I reset (my|the) password/i, responseKey: 'password'},
  {pattern: /what (is|are) the eligibility/i, responseKey: 'eligibility'},
  {pattern: /what qualifications (do I need|are required)/i, responseKey: 'qualification'},
  {pattern: /how much experience (do I need|is required)/i, responseKey: 'experience'},
  {pattern: /how (can|do) I update my (profile|skills)/i, responseKey: 'profile'},
  {pattern: /how (can|do) I contact/i, responseKey: 'contact'},
  {pattern: /what departments (are there|do you have)/i, responseKey: 'departments'},
  {pattern: /what (is|are) the salary/i, responseKey: 'salary'},
  {pattern: /who are you/i, responseKey: 'chatbot'},
  {pattern: /what can you (do|help with)/i, responseKey: 'assistant'}
];

/**
 * Find the best matching response for the user's query
 * 
 * @param message The user's message
 * @returns The most relevant response
 */
function findBestResponse(message: string): string {
  const normalizedMessage = message.toLowerCase();
  
  // Check for question patterns first (highest priority)
  for (const {pattern, responseKey} of QUESTION_PATTERNS) {
    if (pattern.test(message)) {
      return RESPONSES[responseKey] || RESPONSES['default'];
    }
  }
  
  // Direct matches (high priority)
  for (const [key, response] of Object.entries(RESPONSES)) {
    if (normalizedMessage.includes(key)) {
      return response;
    }
  }
  
  // Keyword-based matches (medium priority)
  for (const [responseKey, keywords] of Object.entries(KEYWORDS_MAP)) {
    for (const keyword of keywords) {
      if (normalizedMessage.includes(keyword)) {
        return RESPONSES[responseKey] || RESPONSES['default'];
      }
    }
  }
  
  // Context-based responses (lower priority)
  if (normalizedMessage.includes('thank')) {
    return 'You\'re welcome! If you have any other questions about job opportunities or the application process, feel free to ask.';
  }
  
  if (normalizedMessage.includes('hello') || normalizedMessage.includes('hi') || normalizedMessage.includes('hey')) {
    return 'Hello! I\'m your career advisor for the Government of Rajasthan Technical and Education Department. I can help you find job opportunities, understand the application process, and answer questions about our departments. How can I assist you today?';
  }
  
  if (normalizedMessage.includes('bye') || normalizedMessage.includes('goodbye')) {
    return 'Goodbye! Feel free to come back if you have more questions about job opportunities. Best of luck with your career!';
  }
  
  // Default response if no match is found
  return RESPONSES['default'];
}

/**
 * Generate a response from our chatbot system
 * 
 * @param userPrompt The user's question or message
 * @param jobData Optional job data to provide context in responses
 * @returns A response to the user's message
 */
export async function generateFallbackResponse(userPrompt: string, jobData?: Job[]): Promise<string> {
  try {
    let response = findBestResponse(userPrompt);
    
    // Enhance response with job data if available and relevant
    const normalizedPrompt = userPrompt.toLowerCase();
    const jobRelatedTerms = ['job', 'position', 'opening', 'vacancy', 'career', 'work', 'opportunity', 'employment'];
    
    const isJobRelated = jobRelatedTerms.some(term => normalizedPrompt.includes(term));
    
    if (jobData && jobData.length > 0) {
      // Check if the query is about specific skills or job types
      const commonSkills = [
        'python', 'javascript', 'java', 'c#', 'php', 'ruby', 'go', 'rust', 
        'react', 'angular', 'vue', 'node', 'django', 'flask', 'spring', 
        'devops', 'aws', 'azure', 'gcp', 'docker', 'kubernetes', 
        'machine learning', 'ml', 'ai', 'data science', 'deep learning',
        'database', 'sql', 'nosql', 'mysql', 'postgresql', 'mongodb',
        'frontend', 'backend', 'fullstack', 'web development', 'mobile development',
        'ui', 'ux', 'design', 'graphic', 'cybersecurity', 'security', 'networking',
        'cloud', 'big data', 'analytics', 'hadoop', 'spark', 'etl',
        'agile', 'scrum', 'project management', 'product management',
        'testing', 'qa', 'quality assurance', 'automation',
        'marketing', 'social media', 'content', 'writing', 'education'
      ];
      
      // Check for job type requests (internship, etc.)
      const internshipKeywords = ['intern', 'internship', 'student', 'college', 'university', 'entry-level', 'entry level', 'summer'];
      const isInternshipQuery = internshipKeywords.some(keyword => normalizedPrompt.includes(keyword));
      
      // Check for skill matches in user prompt
      const mentionedSkills = commonSkills.filter(skill => normalizedPrompt.includes(skill));
      
      // Filter jobs that match mentioned skills or job type
      let relevantJobs = jobData;
      
      // If looking for internships, filter to only show internships
      if (isInternshipQuery) {
        relevantJobs = jobData.filter(job => job.jobType === 'INTERNSHIP');
        
        // If no skills mentioned but looking for internships, return all internships
        if (mentionedSkills.length === 0 && relevantJobs.length > 0) {
          response += `\n\nI found ${relevantJobs.length} internship opportunities available now:\n`;
          
          relevantJobs.slice(0, 5).forEach((job, index) => {
            response += `${index + 1}. ${job.title} - ${job.location || 'Various Locations'}\n`;
            if (job.jobType) {
              response += `   Type: ${job.jobType}\n`;
            }
            if (job.experience) {
              response += `   Experience: ${job.experience.replace('_', ' ')}\n`;
            }
            
            // Extract a brief snippet of qualifications
            if (job.qualifications) {
              const snippet = job.qualifications.length > 100 ? 
                job.qualifications.substring(0, 100) + '...' : 
                job.qualifications;
              response += `   Requirements: ${snippet}\n`;
            }
          });
          
          response += '\nYou can find more details about these positions on our Internships page.';
          return response;
        }
      }
      
      if (mentionedSkills.length > 0) {
        // Filter jobs based on mentioned skills
        relevantJobs = jobData.filter(job => {
          const jobText = `${job.title} ${job.description} ${job.qualifications}`.toLowerCase();
          return mentionedSkills.some(skill => jobText.includes(skill));
        });
        
        // If we have matches, create a skill-focused response
        if (relevantJobs.length > 0) {
          response += `\n\nI found ${relevantJobs.length} jobs matching your skills in ${mentionedSkills.join(', ')}:\n`;
          
          relevantJobs.slice(0, 3).forEach((job, index) => {
            response += `${index + 1}. ${job.title} - ${job.location || 'Various Locations'}\n`;
            if (job.jobType) {
              response += `   Type: ${job.jobType}\n`;
            }
            if (job.experience) { // Changed from experienceLevel to experience
              response += `   Experience: ${job.experience.replace('_', ' ')}\n`;
            }
            
            // Extract a brief snippet of qualifications that match the skills
            if (job.qualifications) {
              const snippet = job.qualifications.length > 100 ? 
                job.qualifications.substring(0, 100) + '...' : 
                job.qualifications;
              response += `   Skills: ${snippet}\n`;
            }
          });
          
          response += '\nYou can find more details about these positions on our Jobs page.';
          return response;
        }
      }
      
      // If no skill match or general job query, show default job listings
      if (isJobRelated || mentionedSkills.length > 0) {
        response += '\n\nHere are some current openings that might interest you:\n';
        
        jobData.slice(0, 3).forEach((job, index) => {
          response += `${index + 1}. ${job.title} - ${job.location || 'Various Locations'}\n`;
          if (job.jobType) {
            response += `   Type: ${job.jobType}\n`;
          }
          if (job.experience) {
            response += `   Experience: ${job.experience.replace('_', ' ')}\n`;
          }
        });
        
        response += '\nYou can find more details about these positions on our Jobs page.';
      }
    }
    
    return response;
    
  } catch (error) {
    console.error('Error in chatbot:', error);
    return 'I\'m here to help with your job search and application questions. What would you like to know about career opportunities with the Government of Rajasthan?';
  }
}