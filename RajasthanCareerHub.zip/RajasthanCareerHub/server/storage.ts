import {
  users, type User, type InsertUser,
  jobs, type Job, type InsertJob,
  departments, type Department, type InsertDepartment,
  applications, type Application, type InsertApplication,
  userProfiles, type UserProfile, type InsertUserProfile,
  notifications, type Notification, type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, like, and, desc, gte, lte, or } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Job operations
  getJobs(filters?: JobFilters): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<InsertJob>): Promise<Job | undefined>;
  deleteJob(id: number): Promise<boolean>;
  
  // Department operations
  getDepartments(): Promise<Department[]>;
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department | undefined>;
  
  // Application operations
  getApplications(filters?: ApplicationFilters): Promise<Application[]>;
  getApplication(id: number): Promise<Application | undefined>;
  getUserApplications(userId: number): Promise<Application[]>;
  getJobApplications(jobId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplicationStatus(id: number, status: string, notes?: string): Promise<Application | undefined>;
  
  // UserProfile operations
  getUserProfile(userId: number): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: number, profile: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  
  // Notification operations
  getUserNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(userId: number): Promise<boolean>;
}

export interface JobFilters {
  keyword?: string;
  departmentId?: number;
  jobType?: string;
  location?: string;
  experience?: string;
  salaryMin?: number;
  salaryMax?: number;
  isRemote?: boolean;
  postedAfter?: Date;
  limit?: number;
}

export interface ApplicationFilters {
  userId?: number;
  jobId?: number;
  status?: string;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobs: Map<number, Job>;
  private departments: Map<number, Department>;
  private applications: Map<number, Application>;
  private userProfiles: Map<number, UserProfile>;
  private notifications: Map<number, Notification>;
  
  private userId: number;
  private jobId: number;
  private departmentId: number;
  private applicationId: number;
  private userProfileId: number;
  private notificationId: number;

  constructor() {
    this.users = new Map();
    this.jobs = new Map();
    this.departments = new Map();
    this.applications = new Map();
    this.userProfiles = new Map();
    this.notifications = new Map();
    
    this.userId = 1;
    this.jobId = 1;
    this.departmentId = 1;
    this.applicationId = 1;
    this.userProfileId = 1;
    this.notificationId = 1;
    
    // Initialize with sample departments
    this.initializeDepartments();
  }

  private initializeDepartments() {
    const departmentData: InsertDepartment[] = [
      {
        name: "Information Technology",
        description: "IT infrastructure, software development, and digital transformation initiatives",
        icon: "laptop-code",
        jobCount: 42
      },
      {
        name: "Higher Education",
        description: "University and college level teaching, administrative, and research positions",
        icon: "graduation-cap",
        jobCount: 64
      },
      {
        name: "School Education",
        description: "Teaching and administrative positions in government schools across Rajasthan",
        icon: "school",
        jobCount: 93
      },
      {
        name: "Technical Education",
        description: "Positions in technical institutes, polytechnics, and vocational training centers",
        icon: "cogs",
        jobCount: 38
      },
      {
        name: "Public Works",
        description: "Engineering and technical positions for infrastructure development projects",
        icon: "hammer",
        jobCount: 27
      },
      {
        name: "Science & Technology",
        description: "Research and development positions in various scientific departments",
        icon: "microscope",
        jobCount: 19
      }
    ];

    departmentData.forEach(dept => {
      this.createDepartment(dept);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      isAdmin: false,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job operations
  async getJobs(filters?: JobFilters): Promise<Job[]> {
    let jobs = Array.from(this.jobs.values());
    
    if (filters) {
      if (filters.keyword) {
        const keyword = filters.keyword.toLowerCase();
        jobs = jobs.filter(job => 
          job.title.toLowerCase().includes(keyword) || 
          job.description.toLowerCase().includes(keyword) ||
          job.qualifications.toLowerCase().includes(keyword) ||
          job.responsibilities.toLowerCase().includes(keyword)
        );
      }
      
      if (filters.departmentId) {
        jobs = jobs.filter(job => job.departmentId === filters.departmentId);
      }
      
      if (filters.jobType) {
        jobs = jobs.filter(job => job.jobType === filters.jobType);
      }
      
      if (filters.location) {
        const location = filters.location.toLowerCase();
        jobs = jobs.filter(job => job.location.toLowerCase().includes(location));
      }
      
      if (filters.experience) {
        jobs = jobs.filter(job => job.experience === filters.experience);
      }
      
      if (filters.salaryMin) {
        jobs = jobs.filter(job => 
          job.salaryMin !== undefined && job.salaryMin >= (filters.salaryMin || 0)
        );
      }
      
      if (filters.salaryMax) {
        jobs = jobs.filter(job => 
          job.salaryMax !== undefined && job.salaryMax <= (filters.salaryMax || Infinity)
        );
      }
      
      if (filters.isRemote !== undefined) {
        jobs = jobs.filter(job => job.isRemote === filters.isRemote);
      }
      
      if (filters.postedAfter) {
        jobs = jobs.filter(job => job.postedAt >= filters.postedAfter!);
      }
    }
    
    // Sort by most recently posted
    jobs = jobs.sort((a, b) => b.postedAt.getTime() - a.postedAt.getTime());
    
    // Apply limit if specified
    if (filters?.limit && filters.limit > 0) {
      jobs = jobs.slice(0, filters.limit);
    }
    
    return jobs;
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.jobId++;
    const now = new Date();
    const job: Job = { ...insertJob, id, postedAt: now };
    this.jobs.set(id, job);
    
    // Update department job count
    const department = await this.getDepartment(insertJob.departmentId);
    if (department) {
      await this.updateDepartment(department.id, { 
        jobCount: department.jobCount + 1 
      });
    }
    
    return job;
  }

  async updateJob(id: number, jobData: Partial<InsertJob>): Promise<Job | undefined> {
    const job = await this.getJob(id);
    if (!job) return undefined;
    
    // If department is changing, update job counts
    if (jobData.departmentId && jobData.departmentId !== job.departmentId) {
      const oldDepartment = await this.getDepartment(job.departmentId);
      const newDepartment = await this.getDepartment(jobData.departmentId);
      
      if (oldDepartment) {
        await this.updateDepartment(oldDepartment.id, { 
          jobCount: Math.max(0, oldDepartment.jobCount - 1) 
        });
      }
      
      if (newDepartment) {
        await this.updateDepartment(newDepartment.id, { 
          jobCount: newDepartment.jobCount + 1 
        });
      }
    }
    
    const updatedJob = { ...job, ...jobData };
    this.jobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteJob(id: number): Promise<boolean> {
    const job = await this.getJob(id);
    if (!job) return false;
    
    // Update department job count
    const department = await this.getDepartment(job.departmentId);
    if (department) {
      await this.updateDepartment(department.id, { 
        jobCount: Math.max(0, department.jobCount - 1) 
      });
    }
    
    return this.jobs.delete(id);
  }

  // Department operations
  async getDepartments(): Promise<Department[]> {
    return Array.from(this.departments.values());
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    return this.departments.get(id);
  }

  async createDepartment(insertDepartment: InsertDepartment): Promise<Department> {
    const id = this.departmentId++;
    const department: Department = { ...insertDepartment, id };
    this.departments.set(id, department);
    return department;
  }

  async updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined> {
    const department = await this.getDepartment(id);
    if (!department) return undefined;
    
    const updatedDepartment = { ...department, ...departmentData };
    this.departments.set(id, updatedDepartment);
    return updatedDepartment;
  }

  // Application operations
  async getApplications(filters?: ApplicationFilters): Promise<Application[]> {
    let applications = Array.from(this.applications.values());
    
    if (filters) {
      if (filters.userId) {
        applications = applications.filter(app => app.userId === filters.userId);
      }
      
      if (filters.jobId) {
        applications = applications.filter(app => app.jobId === filters.jobId);
      }
      
      if (filters.status) {
        applications = applications.filter(app => app.status === filters.status);
      }
    }
    
    // Sort by submission date
    return applications.sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
  }

  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async getUserApplications(userId: number): Promise<Application[]> {
    return this.getApplications({ userId });
  }

  async getJobApplications(jobId: number): Promise<Application[]> {
    return this.getApplications({ jobId });
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.applicationId++;
    const now = new Date();
    const application: Application = { 
      ...insertApplication, 
      id, 
      status: "SUBMITTED",
      submittedAt: now, 
      updatedAt: now 
    };
    this.applications.set(id, application);
    
    // Create notification for the user
    const job = await this.getJob(application.jobId);
    if (job) {
      await this.createNotification({
        userId: application.userId,
        message: `Your application for ${job.title} has been submitted successfully.`,
        relatedTo: "application",
        relatedId: id
      });
    }
    
    return application;
  }

  async updateApplicationStatus(id: number, status: string, notes?: string): Promise<Application | undefined> {
    const application = await this.getApplication(id);
    if (!application) return undefined;
    
    const now = new Date();
    const updatedApplication = { 
      ...application, 
      status, 
      notes: notes || application.notes,
      updatedAt: now 
    };
    this.applications.set(id, updatedApplication);
    
    // Create notification for the user
    const job = await this.getJob(application.jobId);
    if (job) {
      await this.createNotification({
        userId: application.userId,
        message: `Your application status for ${job.title} has been updated to ${status}.`,
        relatedTo: "application",
        relatedId: id
      });
    }
    
    return updatedApplication;
  }

  // UserProfile operations
  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    return Array.from(this.userProfiles.values()).find(
      (profile) => profile.userId === userId,
    );
  }

  async createUserProfile(insertProfile: InsertUserProfile): Promise<UserProfile> {
    const id = this.userProfileId++;
    const profile: UserProfile = { ...insertProfile, id };
    this.userProfiles.set(id, profile);
    return profile;
  }

  async updateUserProfile(userId: number, profileData: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const profile = await this.getUserProfile(userId);
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...profileData };
    this.userProfiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  // Notification operations
  async getUserNotifications(userId: number): Promise<Notification[]> {
    const notifications = Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return notifications;
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationId++;
    const now = new Date();
    const notification: Notification = { 
      ...insertNotification, 
      id, 
      read: false,
      createdAt: now
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    
    notification.read = true;
    this.notifications.set(id, notification);
    return true;
  }

  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    const userNotifications = await this.getUserNotifications(userId);
    
    userNotifications.forEach(notification => {
      notification.read = true;
      this.notifications.set(notification.id, notification);
    });
    
    return true;
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      isAdmin: false
    }).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(userData).where(eq(users.id, id)).returning();
    return user;
  }

  // Job operations
  async getJobs(filters?: JobFilters): Promise<Job[]> {
    let query = db.select().from(jobs);
    
    if (filters) {
      const conditions = [];
      
      if (filters.keyword) {
        const keyword = `%${filters.keyword}%`;
        conditions.push(
          or(
            like(jobs.title, keyword),
            like(jobs.description, keyword),
            like(jobs.qualifications, keyword),
            like(jobs.responsibilities, keyword)
          )
        );
      }
      
      if (filters.departmentId) {
        conditions.push(eq(jobs.departmentId, filters.departmentId));
      }
      
      if (filters.jobType) {
        conditions.push(eq(jobs.jobType, filters.jobType));
      }
      
      if (filters.location) {
        const location = `%${filters.location}%`;
        conditions.push(like(jobs.location, location));
      }
      
      if (filters.experience) {
        conditions.push(eq(jobs.experienceLevel, filters.experience));
      }
      
      if (filters.salaryMin) {
        conditions.push(gte(jobs.salaryMin, filters.salaryMin));
      }
      
      if (filters.salaryMax) {
        conditions.push(lte(jobs.salaryMax, filters.salaryMax));
      }
      
      if (filters.isRemote !== undefined) {
        conditions.push(eq(jobs.isRemote, filters.isRemote));
      }
      
      if (filters.postedAfter) {
        conditions.push(gte(jobs.postedAt, filters.postedAfter));
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      
      if (filters.limit && filters.limit > 0) {
        query = query.limit(filters.limit);
      }
    }
    
    return query.orderBy(desc(jobs.postedAt));
  }

  async getJob(id: number): Promise<Job | undefined> {
    const result = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
    return result[0];
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const defaultValues = {
      salaryMin: null,
      salaryMax: null,
      isActive: true
    };
    
    const [job] = await db.insert(jobs).values({
      ...defaultValues,
      ...insertJob
    }).returning();
    
    // Update department job count
    const department = await this.getDepartment(insertJob.departmentId);
    if (department) {
      await this.updateDepartment(department.id, {
        jobCount: department.jobCount + 1
      });
    }
    
    return job;
  }

  async updateJob(id: number, jobData: Partial<InsertJob>): Promise<Job | undefined> {
    const job = await this.getJob(id);
    if (!job) return undefined;
    
    // If department is changing, update job counts
    if (jobData.departmentId && jobData.departmentId !== job.departmentId) {
      const oldDepartment = await this.getDepartment(job.departmentId);
      const newDepartment = await this.getDepartment(jobData.departmentId);
      
      if (oldDepartment) {
        await this.updateDepartment(oldDepartment.id, {
          jobCount: Math.max(0, oldDepartment.jobCount - 1)
        });
      }
      
      if (newDepartment) {
        await this.updateDepartment(newDepartment.id, {
          jobCount: newDepartment.jobCount + 1
        });
      }
    }
    
    const [updatedJob] = await db.update(jobs).set(jobData).where(eq(jobs.id, id)).returning();
    return updatedJob;
  }

  async deleteJob(id: number): Promise<boolean> {
    const job = await this.getJob(id);
    if (!job) return false;
    
    // Update department job count
    const department = await this.getDepartment(job.departmentId);
    if (department) {
      await this.updateDepartment(department.id, {
        jobCount: Math.max(0, department.jobCount - 1)
      });
    }
    
    const result = await db.delete(jobs).where(eq(jobs.id, id)).returning();
    return result.length > 0;
  }

  // Department operations
  async getDepartments(): Promise<Department[]> {
    return db.select().from(departments);
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    const result = await db.select().from(departments).where(eq(departments.id, id)).limit(1);
    return result[0];
  }

  async createDepartment(insertDepartment: InsertDepartment): Promise<Department> {
    const [department] = await db.insert(departments).values({
      ...insertDepartment,
      jobCount: insertDepartment.jobCount || 0
    }).returning();
    return department;
  }

  async updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined> {
    const [department] = await db.update(departments).set(departmentData).where(eq(departments.id, id)).returning();
    return department;
  }

  // Application operations
  async getApplications(filters?: ApplicationFilters): Promise<Application[]> {
    let query = db.select().from(applications);
    
    if (filters) {
      const conditions = [];
      
      if (filters.userId) {
        conditions.push(eq(applications.userId, filters.userId));
      }
      
      if (filters.jobId) {
        conditions.push(eq(applications.jobId, filters.jobId));
      }
      
      if (filters.status) {
        conditions.push(eq(applications.status, filters.status));
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
    }
    
    return query.orderBy(desc(applications.submittedAt));
  }

  async getApplication(id: number): Promise<Application | undefined> {
    const result = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
    return result[0];
  }

  async getUserApplications(userId: number): Promise<Application[]> {
    return this.getApplications({ userId });
  }

  async getJobApplications(jobId: number): Promise<Application[]> {
    return this.getApplications({ jobId });
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const defaultValues = {
      coverLetter: null,
      notes: null,
      status: "SUBMITTED" as const,
      submittedAt: new Date(),
      updatedAt: new Date()
    };
    
    const [application] = await db.insert(applications).values({
      ...defaultValues,
      ...insertApplication
    }).returning();
    
    // Create notification for the user
    const job = await this.getJob(application.jobId);
    if (job) {
      await this.createNotification({
        userId: application.userId,
        message: `Your application for ${job.title} has been submitted successfully.`,
        relatedTo: "application",
        relatedId: application.id
      });
    }
    
    return application;
  }

  async updateApplicationStatus(id: number, status: string, notes?: string): Promise<Application | undefined> {
    const application = await this.getApplication(id);
    if (!application) return undefined;
    
    // Validate that status is one of the allowed application statuses
    const validStatus = ["SUBMITTED", "UNDER_REVIEW", "SHORTLISTED", "INTERVIEW_SCHEDULED", "SELECTED", "REJECTED"].includes(status)
      ? status as "SUBMITTED" | "UNDER_REVIEW" | "SHORTLISTED" | "INTERVIEW_SCHEDULED" | "SELECTED" | "REJECTED"
      : "SUBMITTED";
    
    const [updatedApplication] = await db.update(applications)
      .set({ 
        status: validStatus, 
        notes: notes || application.notes,
        updatedAt: new Date()
      })
      .where(eq(applications.id, id))
      .returning();
    
    // Create notification for the user
    const job = await this.getJob(application.jobId);
    if (job) {
      await this.createNotification({
        userId: application.userId,
        message: `Your application status for ${job.title} has been updated to ${status}.`,
        relatedTo: "application",
        relatedId: id
      });
    }
    
    return updatedApplication;
  }

  // UserProfile operations
  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
    return result[0];
  }

  async createUserProfile(insertProfile: InsertUserProfile): Promise<UserProfile> {
    const defaultValues = {
      experience: null,
      resumePath: null,
      address: null
    };
    
    const [profile] = await db.insert(userProfiles).values({
      ...defaultValues,
      ...insertProfile
    }).returning();
    
    return profile;
  }

  async updateUserProfile(userId: number, profileData: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const profile = await this.getUserProfile(userId);
    if (!profile) return undefined;
    
    const [updatedProfile] = await db.update(userProfiles)
      .set(profileData)
      .where(eq(userProfiles.userId, userId))
      .returning();
    
    return updatedProfile;
  }

  // Notification operations
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const defaultValues = {
      read: false,
      createdAt: new Date(),
      relatedTo: null,
      relatedId: null
    };
    
    const [notification] = await db.insert(notifications)
      .values({
        ...defaultValues,
        ...insertNotification
      })
      .returning();
    
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    
    return result.length > 0;
  }

  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.userId, userId))
      .returning();
    
    return result.length > 0;
  }
}

// Use database storage instead of memory storage
export const storage = new DatabaseStorage();
