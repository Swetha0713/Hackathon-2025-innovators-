import { Router } from "express";
import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { authenticateUser, requireAdmin } from "./middleware/auth";
import { storage } from "./storage";
import { z } from "zod";
import { getJobRecommendations, getPersonalizedJobDescription } from "./ai";
import authRouter from "./auth";
import { JOB_TYPES, EXPERIENCE_LEVELS, APPLICATION_STATUSES, insertDepartmentSchema } from "@shared/schema";
import { generateFallbackResponse } from "./utils/fallbackChatbot";

// Export the registerRoutes function that creates and returns an HTTP server
export function registerRoutes(app: Express): Server {
  // Create the API router
  const apiRouter = Router();
  
  // Mount auth routes
  apiRouter.use("/auth", authRouter);

  // ✅ Job Update Route
  apiRouter.put("/jobs/:id", authenticateUser, requireAdmin, async (req: Request, res: Response) => {
    try {
      const jobId = Number(req.params.id);
      if (!jobId) {
        return res.status(400).json({ message: "Invalid job ID" });
      }

      // ✅ Validate input
      const jobSchema = z.object({
        title: z.string().min(3),
        description: z.string().min(10),
        departmentId: z.number().optional(),
      });

      const validatedData = jobSchema.parse(req.body);

      // ✅ Check if job exists
      const existingJob = await storage.getJob(jobId);
      if (!existingJob) {
        return res.status(404).json({ message: "Job not found" });
      }

      // ✅ Validate department if provided
      if (validatedData.departmentId) {
        const department = await storage.getDepartment(validatedData.departmentId);
        if (!department) {
          return res.status(400).json({ message: "Department not found" });
        }
      }

      // ✅ Update job
      const updatedJob = await storage.updateJob(jobId, validatedData);
      res.json(updatedJob);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // ✅ Job Deletion Route
  apiRouter.delete("/jobs/:id", authenticateUser, requireAdmin, async (req: Request, res: Response) => {
    try {
      const jobId = Number(req.params.id);
      if (!jobId) {
        return res.status(400).json({ message: "Invalid job ID" });
      }

      const existingJob = await storage.getJob(jobId);
      if (!existingJob) {
        return res.status(404).json({ message: "Job not found" });
      }

      await storage.deleteJob(jobId);
      res.json({ message: "Job deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ✅ Fetch All Departments
  apiRouter.get("/departments", async (req: Request, res: Response) => {
    try {
      const departments = await storage.getDepartments();
      res.json(departments);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ✅ Fetch Single Department
  apiRouter.get("/departments/:id", async (req: Request, res: Response) => {
    try {
      const departmentId = Number(req.params.id);
      if (!departmentId) {
        return res.status(400).json({ message: "Invalid department ID" });
      }

      const department = await storage.getDepartment(departmentId);
      if (!department) {
        return res.status(404).json({ message: "Department not found" });
      }

      res.json(department);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ✅ Create Department
  apiRouter.post("/departments", async (req: Request, res: Response) => {
    try {
      const parsedBody = insertDepartmentSchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ 
          message: "Invalid department data", 
          errors: parsedBody.error.errors 
        });
      }

      const newDepartment = await storage.createDepartment(parsedBody.data);
      res.status(201).json(newDepartment);
    } catch (error) {
      console.error("Department creation error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // ✅ Fetch Constants
  apiRouter.get("/constants", async (req: Request, res: Response) => {
    try {
      const constants = {
        jobTypes: JOB_TYPES,
        experienceLevels: EXPERIENCE_LEVELS,
        applicationStatuses: APPLICATION_STATUSES
      };
      res.json(constants);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Add routes for AI recommendations
  apiRouter.get("/recommendations", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      console.log("User ID:", userId);
      
      const userProfile = await storage.getUserProfile(userId);
      if (!userProfile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      console.log("User Profile:", JSON.stringify(userProfile));
      
      const jobs = await storage.getJobs();
      console.log("Jobs found:", jobs.length);
      
      try {
        const recommendations = getJobRecommendations(userProfile, jobs);
        console.log("Recommendations generated:", recommendations.length);
        
        res.json(recommendations);
      } catch (e) {
        const recError = e as Error;
        console.error("Error generating recommendations:", recError);
        res.status(500).json({ message: "Error generating recommendations", error: recError.message });
      }
    } catch (e) {
      const error = e as Error;
      console.error("Server error in recommendations:", error);
      res.status(500).json({ message: "Server error", error: error.message  });
    }
  });

  apiRouter.get("/jobs/:id/personalized", authenticateUser, async (req: Request, res: Response) => {
    try {
      const jobId = Number(req.params.id);
      if (!jobId) {
        return res.status(400).json({ message: "Invalid job ID" });
      }
      
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      console.log("User ID for personalized job:", userId);
      
      const userProfile = await storage.getUserProfile(userId);
      if (!userProfile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      console.log("User Profile for personalized job:", JSON.stringify(userProfile));
      
      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      console.log("Job for personalization:", JSON.stringify(job));
      
      try {
        const personalizedDescription = getPersonalizedJobDescription(job, userProfile);
        console.log("Personalized description generated, length:", personalizedDescription.length);
        
        res.json(personalizedDescription);
      } catch (e) {
        const descError = e as Error;
        console.error("Error generating personalized description:", descError);
        res.status(500).json({ message: "Error generating personalized description", error: descError.message });
      }
    } catch (e) {
      const error = e as Error;
      console.error("Server error in personalized job description:", error);
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  // User Profile Routes
  apiRouter.get("/profile", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const userProfile = await storage.getUserProfile(userId);
      if (!userProfile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  apiRouter.post("/profile", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if profile already exists
      const existingProfile = await storage.getUserProfile(userId);
      if (existingProfile) {
        // Update existing profile
        const updatedProfile = await storage.updateUserProfile(userId, req.body);
        return res.json(updatedProfile);
      }
      
      // Create new profile
      const profile = { ...req.body, userId };
      const newProfile = await storage.createUserProfile(profile);
      res.status(201).json(newProfile);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  apiRouter.put("/profile", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const existingProfile = await storage.getUserProfile(userId);
      if (!existingProfile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      const updatedProfile = await storage.updateUserProfile(userId, req.body);
      res.json(updatedProfile);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Job Routes
  apiRouter.get("/jobs", async (req: Request, res: Response) => {
    try {
      const filters = req.query;
      const jobs = await storage.getJobs(filters);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  apiRouter.get("/jobs/:id", async (req: Request, res: Response) => {
    try {
      const jobId = Number(req.params.id);
      if (!jobId) {
        return res.status(400).json({ message: "Invalid job ID" });
      }

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  apiRouter.post("/jobs", async (req: Request, res: Response) => {
    try {
      // Parse dates from strings
      const jobData = { ...req.body };
      if (jobData.deadline && typeof jobData.deadline === 'string') {
        jobData.deadline = new Date(jobData.deadline);
      }
      
      const job = await storage.createJob(jobData);
      res.json(job);
    } catch (error) {
      console.error("Job creation error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Application Routes
  apiRouter.post("/applications", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const application = { ...req.body, userId, status: "PENDING" };
      const newApplication = await storage.createApplication(application);
      res.status(201).json(newApplication);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  apiRouter.get("/applications", authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const applications = await storage.getUserApplications(userId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Chatbot endpoint
  apiRouter.post("/chat", async (req: Request, res: Response) => {
    try {
      const { message } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Message is required" });
      }
      
      // Get all jobs to provide comprehensive context to the chatbot for skill matching
      const jobs = await storage.getJobs();
      console.log(`Fetched ${jobs.length} jobs for chatbot context`);
      
      // Use our enhanced fallback chatbot with skill matching
      const response = await generateFallbackResponse(message, jobs);
      res.json({ response });
    } catch (error) {
      console.error("Chatbot error:", error);
      // Return a friendly error message
      res.json({ 
        response: "I'm sorry, I'm having trouble understanding your request right now. Feel free to browse our Jobs page or check back later when our services are fully operational."
      });
    }
  });

  // Mount the API router
  app.use("/api", apiRouter);

  // Create and return the HTTP server
  const httpServer = createServer(app);
  return httpServer;
}