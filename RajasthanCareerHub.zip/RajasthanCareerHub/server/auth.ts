import { Request, Response, Router } from "express";
import { z } from "zod";
import { storage } from "./storage";
import bcrypt from "bcryptjs";

const authRouter = Router();

// Register a new user
authRouter.post("/register", async (req: Request, res: Response) => {
  try {
    // Validate input
    const registerSchema = z.object({
      username: z.string().min(3),
      email: z.string().email(),
      password: z.string().min(6),
      firstName: z.string(),
      lastName: z.string(),
      phone: z.string().optional(),
      isAdmin: z.boolean().optional(),
    });

    const validatedData = registerSchema.parse(req.body);

    // Check if username or email already exists
    const existingUserByUsername = await storage.getUserByUsername(validatedData.username);
    if (existingUserByUsername) {
      return res.status(400).json({ message: "Username already exists" });
    }

    const existingUserByEmail = await storage.getUserByEmail(validatedData.email);
    if (existingUserByEmail) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(validatedData.password, salt);

    // Create user
    const userData = {
      ...validatedData,
      password: hashedPassword,
      isAdmin: validatedData.isAdmin || false,
    };

    const newUser = await storage.createUser(userData);

    // Set session
    req.session.userId = newUser.id;
    req.session.isAdmin = newUser.isAdmin;
    
    // Return user data without password
    const { password, ...userWithoutPassword } = newUser;
    res.status(201).json(userWithoutPassword);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    console.error("Register error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Login user
authRouter.post("/login", async (req: Request, res: Response) => {
  try {
    // Validate input
    const loginSchema = z.object({
      username: z.string(),
      password: z.string(),
    });

    const validatedData = loginSchema.parse(req.body);

    // Check if user exists
    const user = await storage.getUserByUsername(validatedData.username);
    if (!user) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(validatedData.password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Set session
    req.session.userId = user.id;
    req.session.isAdmin = user.isAdmin;
    
    // Return user data without password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Logout user
authRouter.post("/logout", (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: "Logout failed" });
    }
    res.clearCookie("connect.sid");
    res.json({ message: "Logged out successfully" });
  });
});

// Get current user
authRouter.get("/me", async (req: Request, res: Response) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Return user data without password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (error) {
    console.error("Get current user error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

export default authRouter;