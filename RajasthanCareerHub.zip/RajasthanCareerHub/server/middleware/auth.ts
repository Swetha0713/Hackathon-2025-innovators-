import { Request, Response, NextFunction } from "express";

// Extend Express Session
declare module 'express-session' {
  interface SessionData {
    userId?: number;
    isAdmin?: boolean;
  }
}

/**
 * Middleware to check if user is authenticated
 */
export function authenticateUser(req: Request, res: Response, next: NextFunction) {
  // Check if user is authenticated through session
  if (req.session && req.session.userId) {
    // User is authenticated
    next();
  } else {
    // User is not authenticated
    res.status(401).json({ message: "Unauthorized. Please login to continue." });
  }
}

/**
 * Middleware to check if user is an admin
 */
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  // Check if user is authenticated and is an admin
  if (req.session && req.session.userId && req.session.isAdmin) {
    // User is an admin
    next();
  } else {
    // User is not an admin
    res.status(403).json({ message: "Forbidden. Admin access required." });
  }
}